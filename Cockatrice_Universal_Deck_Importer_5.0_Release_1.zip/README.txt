Cockatrice Universal Deck Importer 5.0 Release 1

This is the promoted release label for the previously tested 4.0 Beta 9 build.

No functional changes were made during this rename.

Includes:
- 8 GB RAM optimizations
- Cockatrice .COD load/save
- Commander validation and duplicate checking
- Web/pasted deck imports
- Smart Commander
- Card type grouping
- Scryfall search and beginner Search Help
- Card Database Browser
- Scryfall-style keyword/syntax filtering
- Modeless Card Database Browser
- Rollover card previews
- Scryfall art/printing selector
- Exact printing metadata preservation
- Dark theme
- VBS hidden-console launcher

PACKAGE
=======
Cockatrice_Universal_Deck_Importer_5.0_Release_1.ps1
Cockatrice_Universal_Deck_Importer_5.0_Release_1.vbs
README.txt

No BAT file.
