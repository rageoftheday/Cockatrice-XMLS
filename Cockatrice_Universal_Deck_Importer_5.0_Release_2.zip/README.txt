Cockatrice Universal Deck Importer 5.0 Release 2

PERFORMANCE / 16 GB SYSTEM UPDATE
=================================

This release focuses on responsiveness rather than adding major features.

CARD DATABASE BROWSER
---------------------
- Sorted Cockatrice card names are now cached once per cards.xml load.
- Opening Browse Card Database no longer sorts 30,000+ names every time.
- Blank browser search now renders only the first 1,000 cards.
- The COMPLETE database remains searchable.
- Search result rendering is capped at 1,000 rows to avoid huge WinForms
  ListBox redraw/allocation spikes.
- Browser search debounce increased slightly to reduce repeated Scryfall calls.
- Press Enter to search immediately as before.

EDITOR
------
- Direct Qty / Card Name / Zone edits now debounce the live statistics refresh.
- Multiple rapid edits therefore collapse into one stats recalculation.
- Deck-grid rendering is timed in the performance log.

MEMORY
------
- Removed unconditional double full-GC after cards.xml loading.
- Full GC is only requested if the importer process exceeds ~600 MB.
- Existing 8 GB lazy card-type indexing remains.
- Fixed card-type index reset when changing Cockatrice folder.

PERFORMANCE DIAGNOSTICS
-----------------------
A lightweight log is created beside the script:

    Cockatrice_Importer_Performance.log

It records:
- application startup
- process RAM
- available physical RAM
- cards.xml index load time
- whether the card index was reused
- one-time card-name sorting time
- deck grid rendering time
- Card Database Browser search time/result count

If one PC freezes or lags while another does not, send this log so the slow
stage can be identified directly.

PACKAGE
=======
Cockatrice_Universal_Deck_Importer_5.0_Release_2.ps1
Cockatrice_Universal_Deck_Importer_5.0_Release_2.vbs
README.txt

No BAT file.
