Cockatrice Universal Deck Importer 5.0 Release 11

RECOVERY STARTUP FIX
====================

Release 10 introduced real-time crash recovery, but startup recovery could run
before Cockatrice cards.xml had been loaded. Validation then failed with:
    Cockatrice card database is not loaded.

Release 11 fixes the startup order.

Recovery restore now:
- reads the Cockatrice decks folder saved inside the recovery snapshot
- resolves its parent cards.xml
- auto-detects Cockatrice roots if the saved path is unavailable
- loads the card index before validating recovered cards
- restores the deck only after the database is ready
- keeps the recovery file untouched if Cockatrice cannot be located

All Release 10 real-time recovery remains:
- recovery after meaningful deck changes
- atomic temp-file replacement
- card Qty/Name/Zone
- printing set / collector / UUID
- commander state
- deck name / format / comments / tags

All Release 2-9 image/performance/stability work is retained.

PACKAGE
=======
Cockatrice_Universal_Deck_Importer_5.0_Release_11.ps1
Cockatrice_Universal_Deck_Importer_5.0_Release_11.vbs
README.txt

No BAT file.
