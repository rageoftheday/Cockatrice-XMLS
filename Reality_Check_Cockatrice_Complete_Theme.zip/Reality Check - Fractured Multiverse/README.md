# Reality Check - Fractured Multiverse

Unofficial Cockatrice community theme inspired by the 3.1.2 Reality Check release name and Cockatrice's rooster icon. This is not an official Cockatrice project release.

## Contents
- home.jpg, home-dark.jpg, home-light.jpg - 2560x1190 full-bleed backgrounds
- cardback.png, cardback2.png, cardback3.png - 750x1050 variants
- 8 seamless battlefield zone textures - 512x512
- dark and light style sheets and Qt color palettes
- standard theme icons, game counters and phase indicators retained from the compatible starter theme

## Install
Extract the theme folder into your Cockatrice themes directory. Select it in Settings > Appearance. The standard, dark and light assets are ready. A compatible patched executable may be required for the Home image Fit/HiDPI behavior on affected Cockatrice versions. No EXE is included.

## Visual concept
Cockatrice's rooster-cockatrice watching fractured fantasy card realms; the broken king is replaced by a shattered mana crown. The central area is intentionally dark to accommodate 1-column or 2-column Home buttons.

## Note
Gameplay colors, mana counters, arrows, and phase symbols have been retained for usability.
