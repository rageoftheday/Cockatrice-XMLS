@echo off
setlocal
title ARCHIDEKT / MOXFIELD -> COCKATRICE UPDATER v1.10 RELEASE

set "SCRIPT=%~dp0Update_Deck_to_Cockatrice.ps1"

if not exist "%SCRIPT%" (
    echo ============================================================
    echo  ERROR: Update_Deck_to_Cockatrice.ps1 was not found.
    echo ============================================================
    echo.
    echo Keep the BAT and PS1 together in the same folder.
    echo.
    pause
    exit /b 1
)

powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%SCRIPT%"
set "EXITCODE=%ERRORLEVEL%"

echo.
if not "%EXITCODE%"=="0" echo Updater exited with code %EXITCODE%.
echo.
pause
exit /b %EXITCODE%
