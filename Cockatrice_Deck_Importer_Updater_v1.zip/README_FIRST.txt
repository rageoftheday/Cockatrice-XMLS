ARCHIDEKT / MOXFIELD -> COCKATRICE UPDATER v1.10 RELEASE

STARTUP FIX
===========

Fixed this crash:

  Join-Path : Cannot bind argument to parameter 'Path' because it is null.

Cause:
The Scryfall flavor-name cache path was being built before $ScriptDir
had been initialized.

Fix:
- Resolve $ScriptDir first.
- Then create:
    Scryfall_FlavorName_Aliases.json
  beside the updater script.
- Added a defensive fallback in case $ScriptDir is ever unavailable.

All v1.9 features remain:
- working Moxfield Cockatrice-style loader
- Archidekt support
- persistent deck-folder menu
- card-name normalization
- Scryfall flavor-name alias fixes
- // card-name fixes
- maybeboard/considering prompt
- commander / companion / sideboard -> Cockatrice side
