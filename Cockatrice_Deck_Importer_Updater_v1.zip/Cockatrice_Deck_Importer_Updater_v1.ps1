﻿#requires -Version 5.1
$ErrorActionPreference = 'Stop'

# Card-name normalization state.
$Script:CockatriceCardIndex = $null
$Script:CockatriceCardIndexRoot = $null
$Script:CockatriceLooseMap = @{}
$Script:CockatriceLooseAmbiguous = @{}
$Script:FlavorNameMap = @{}
$Script:FlavorNameAmbiguous = @{}
$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path

# Flavor-name cache lives beside this script.
$Script:FlavorNameCachePath = Join-Path -Path $ScriptDir -ChildPath 'Scryfall_FlavorName_Aliases.json'
$ConfigPath = Join-Path $ScriptDir 'config.json'
$BackupRoot = Join-Path $ScriptDir 'Backups'

function Write-Header {
    Clear-Host
    Write-Host '============================================================'
    Write-Host ' ARCHIDEKT / MOXFIELD -> COCKATRICE UPDATER v1.10 RELEASE'
    Write-Host '============================================================'
    Write-Host ' URL examples:'
    Write-Host '   Archidekt: https://archidekt.com/decks/12345678/example-deck'
    Write-Host '   Moxfield : https://www.moxfield.com/decks/ExampleDeckID'
    Write-Host '============================================================'
    Write-Host
}

function Safe-FileName([string]$Name) {
    foreach ($c in [IO.Path]::GetInvalidFileNameChars()) {
        $Name = $Name.Replace([string]$c, '_')
    }
    $Name = $Name.Trim()
    if ([string]::IsNullOrWhiteSpace($Name)) { $Name = 'Archidekt Deck' }
    return $Name
}

function Get-DeckSourceInfo([string]$Url) {
    $u = $Url.Trim()

    if ($u -match '(?i)archidekt\.com/decks/(\d+)') {
        return [pscustomobject]@{
            Source = 'ARCHIDEKT'
            Id = $Matches[1]
            Url = $u
        }
    }

    if ($u -match '(?i)(?:www\.)?moxfield\.com/decks/([A-Za-z0-9_-]+)') {
        return [pscustomobject]@{
            Source = 'MOXFIELD'
            Id = $Matches[1]
            Url = $u
        }
    }

    throw @"
Unsupported deck URL.

Examples:
  Archidekt: https://archidekt.com/decks/12345678/example-deck
  Moxfield : https://www.moxfield.com/decks/ExampleDeckID
"@
}

function Get-DeckId([string]$Url) {
    return (Get-DeckSourceInfo $Url).Id
}

function Find-CockatriceDeckFolders {
    $script:FoundCockatriceDeckFolders = @()

    function Add-Candidate([string]$Path) {
        if ([string]::IsNullOrWhiteSpace($Path)) { return }
        try {
            $expanded = [Environment]::ExpandEnvironmentVariables($Path)
            if (Test-Path -LiteralPath $expanded -PathType Container) {
                $resolved = (Resolve-Path -LiteralPath $expanded).Path
                if ($script:FoundCockatriceDeckFolders -notcontains $resolved) {
                    $script:FoundCockatriceDeckFolders += $resolved
                }
            }
        } catch {}
    }

    $common = @(
        (Join-Path $env:USERPROFILE 'Desktop\CockatricePortable\data\decks'),
        (Join-Path $env:USERPROFILE 'Downloads\CockatricePortable\data\decks'),
        (Join-Path $env:USERPROFILE 'Documents\Cockatrice\decks'),
        (Join-Path $env:USERPROFILE 'Documents\Cockatrice\Cockatrice\decks'),
        (Join-Path $env:LOCALAPPDATA 'Cockatrice\Cockatrice\decks'),
        (Join-Path $env:APPDATA 'Cockatrice\Cockatrice\decks')
    )
    foreach ($p in $common) { Add-Candidate $p }

    $roots = @(
        [Environment]::GetFolderPath('Desktop'),
        (Join-Path $env:USERPROFILE 'Downloads'),
        (Join-Path $env:USERPROFILE 'Documents')
    ) | Where-Object { $_ -and (Test-Path -LiteralPath $_ -PathType Container) }

    foreach ($root in $roots) {
        try {
            Get-ChildItem -LiteralPath $root -Directory -ErrorAction SilentlyContinue |
                Where-Object { $_.Name -match 'Cockatrice' } |
                ForEach-Object {
                    Add-Candidate (Join-Path $_.FullName 'data\decks')
                    Add-Candidate (Join-Path $_.FullName 'Cockatrice\decks')
                    Add-Candidate (Join-Path $_.FullName 'decks')
                }
        } catch {}
    }

    foreach ($drive in Get-PSDrive -PSProvider FileSystem -ErrorAction SilentlyContinue) {
        try {
            Get-ChildItem -LiteralPath $drive.Root -Directory -ErrorAction SilentlyContinue |
                Where-Object { $_.Name -match 'Cockatrice' } |
                ForEach-Object {
                    Add-Candidate (Join-Path $_.FullName 'data\decks')
                    Add-Candidate (Join-Path $_.FullName 'Cockatrice\decks')
                    Add-Candidate (Join-Path $_.FullName 'decks')
                }
        } catch {}
    }

    return $script:FoundCockatriceDeckFolders
}

function Choose-CockatriceDeckFolder {
    $matches = @(Find-CockatriceDeckFolders)

    if ($matches.Count -eq 1) {
        Write-Host
        Write-Host 'Cockatrice deck folder found automatically:' -ForegroundColor Green
        Write-Host "  $($matches[0])"
        $answer = Read-Host 'Use this folder? [Y/n]'
        if ([string]::IsNullOrWhiteSpace($answer) -or $answer -match '^[Yy]') {
            return $matches[0]
        }
        return Select-DeckFolder $matches[0]
    }

    if ($matches.Count -gt 1) {
        Write-Host
        Write-Host 'Multiple Cockatrice deck folders were found:' -ForegroundColor Cyan
        for ($i = 0; $i -lt $matches.Count; $i++) {
            Write-Host ("  [{0}] {1}" -f ($i + 1), $matches[$i])
        }
        Write-Host '  [B] Browse manually'
        Write-Host

        while ($true) {
            $choice = Read-Host 'Choose deck folder'
            if ($choice -match '^[Bb]$') {
                return Select-DeckFolder $null
            }

            $n = 0
            if ([int]::TryParse($choice, [ref]$n)) {
                if ($n -ge 1 -and $n -le $matches.Count) {
                    return $matches[$n - 1]
                }
            }
            Write-Host 'Choose one of the numbers above or B.' -ForegroundColor Yellow
        }
    }

    Write-Host
    Write-Host 'No Cockatrice deck folder was found automatically.' -ForegroundColor Yellow
    Write-Host 'Choose it manually.'
    return Select-DeckFolder $null
}

function Select-DeckFolder([string]$InitialPath) {
    try {
        Add-Type -AssemblyName System.Windows.Forms
        $dlg = New-Object System.Windows.Forms.FolderBrowserDialog
        $dlg.Description = 'Choose your Cockatrice decks folder'
        $dlg.ShowNewFolderButton = $true
        if ($InitialPath -and (Test-Path $InitialPath -PathType Container)) {
            $dlg.SelectedPath = $InitialPath
        }
        if ($dlg.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) {
            return $dlg.SelectedPath
        }
    } catch {
        # Fall back to text prompt below.
    }

    while ($true) {
        $p = Read-Host 'Cockatrice decks folder'
        $p = [Environment]::ExpandEnvironmentVariables($p.Trim('"'))
        if (Test-Path -LiteralPath $p -PathType Container) { return (Resolve-Path -LiteralPath $p).Path }
        Write-Host 'Folder not found. Try again.' -ForegroundColor Yellow
    }
}

function Save-Config($Config) {
    $Config | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath $ConfigPath -Encoding UTF8
}


function Browse-ForDeckFolder([string]$InitialPath) {
    try {
        Add-Type -AssemblyName System.Windows.Forms

        $dlg = New-Object System.Windows.Forms.FolderBrowserDialog
        $dlg.Description = 'Select the folder where Cockatrice .cod deck files should be stored'
        $dlg.ShowNewFolderButton = $true

        if ($InitialPath -and (Test-Path -LiteralPath $InitialPath -PathType Container)) {
            $dlg.SelectedPath = $InitialPath
        }

        $result = $dlg.ShowDialog()
        if ($result -eq [System.Windows.Forms.DialogResult]::OK) {
            return $dlg.SelectedPath
        }

        return $null
    } catch {
        Write-Host
        Write-Host 'Windows folder browser could not open.' -ForegroundColor Yellow
        Write-Host 'Enter any existing folder path manually.'
        Write-Host 'Example:'
        Write-Host '  C:\Users\Alex\Documents\My Cockatrice Decks'
        Write-Host

        $p = (Read-Host 'Deck folder path').Trim().Trim('"')
        if (Test-Path -LiteralPath $p -PathType Container) {
            return (Resolve-Path -LiteralPath $p).Path
        }

        Write-Host 'Folder not found.' -ForegroundColor Red
        return $null
    }
}


function Find-SmartCockatriceDeckFolders {
    $found = @()

    function Add-Folder([string]$Path) {
        if ([string]::IsNullOrWhiteSpace($Path)) { return }

        try {
            $expanded = [Environment]::ExpandEnvironmentVariables($Path)

            if (Test-Path -LiteralPath $expanded -PathType Container) {
                $resolved = (Resolve-Path -LiteralPath $expanded).Path

                if ($script:SmartFoundFolders -notcontains $resolved) {
                    $script:SmartFoundFolders += $resolved
                }
            }
        } catch {}
    }

    $script:SmartFoundFolders = @()

    # Prefer the two most useful Cockatrice locations as protected smart slots.
    $preferred = @(
        (Join-Path $env:USERPROFILE 'Desktop\CockatricePortable\data\decks'),
        (Join-Path $env:LOCALAPPDATA 'Cockatrice\Cockatrice\decks')
    )

    foreach ($p in $preferred) { Add-Folder $p }

    # If one/both preferred locations are missing, look for alternatives.
    $fallback = @(
        (Join-Path $env:USERPROFILE 'Downloads\CockatricePortable\data\decks'),
        (Join-Path $env:APPDATA 'Cockatrice\Cockatrice\decks'),
        (Join-Path $env:USERPROFILE 'Documents\Cockatrice\decks'),
        (Join-Path $env:USERPROFILE 'Documents\Cockatrice\Cockatrice\decks')
    )

    foreach ($p in $fallback) {
        if ($script:SmartFoundFolders.Count -ge 2) { break }
        Add-Folder $p
    }

    # Look for Cockatrice-named portable folders if we still have fewer than 2.
    if ($script:SmartFoundFolders.Count -lt 2) {
        $roots = @(
            [Environment]::GetFolderPath('Desktop'),
            (Join-Path $env:USERPROFILE 'Downloads'),
            (Join-Path $env:USERPROFILE 'Documents')
        ) | Where-Object { $_ -and (Test-Path -LiteralPath $_ -PathType Container) }

        foreach ($root in $roots) {
            if ($script:SmartFoundFolders.Count -ge 2) { break }

            try {
                Get-ChildItem -LiteralPath $root -Directory -ErrorAction SilentlyContinue |
                    Where-Object { $_.Name -match 'Cockatrice' } |
                    ForEach-Object {
                        if ($script:SmartFoundFolders.Count -lt 2) {
                            Add-Folder (Join-Path $_.FullName 'data\decks')
                        }
                        if ($script:SmartFoundFolders.Count -lt 2) {
                            Add-Folder (Join-Path $_.FullName 'Cockatrice\decks')
                        }
                        if ($script:SmartFoundFolders.Count -lt 2) {
                            Add-Folder (Join-Path $_.FullName 'decks')
                        }
                    }
            } catch {}
        }
    }

    return @($script:SmartFoundFolders | Select-Object -First 2)
}

function Add-SavedDeckFolder($Config, [string]$Folder) {
    if ([string]::IsNullOrWhiteSpace($Folder)) { return }

    if (-not $Config.PSObject.Properties['SavedDeckFolders']) {
        Add-Member -InputObject $Config -MemberType NoteProperty -Name SavedDeckFolders -Value @()
    }

    try {
        $resolved = (Resolve-Path -LiteralPath $Folder).Path
    } catch {
        $resolved = $Folder
    }

    $smart = @(Find-SmartCockatriceDeckFolders)

    # Do not duplicate one of the protected smart folders.
    if ($smart -contains $resolved) { return }

    $saved = @($Config.SavedDeckFolders)
    if ($saved -notcontains $resolved) {
        $Config.SavedDeckFolders = @($saved + $resolved | Select-Object -Unique)
        Save-Config $Config
    }
}

function Remove-SavedDeckFolder($Config, [string]$Folder) {
    if (-not $Config.PSObject.Properties['SavedDeckFolders']) { return }

    $new = @()
    foreach ($p in @($Config.SavedDeckFolders)) {
        if ([string]$p -ne [string]$Folder) {
            $new += [string]$p
        }
    }

    $Config.SavedDeckFolders = @($new)
    Save-Config $Config
}

function Get-DeckFolderMenuEntries($Config) {
    $entries = @()

    $smart = @(Find-SmartCockatriceDeckFolders)

    # Protected smart slots: menu positions 1 and 2 when available.
    foreach ($p in $smart) {
        $entries += [pscustomobject]@{
            Path = [string]$p
            Removable = $false
            Kind = 'SMART'
        }
    }

    # Manually added folders always follow the smart entries.
    # With the normal two smart slots these become [3], [4], [5]...
    foreach ($p in @($Config.SavedDeckFolders)) {
        if ([string]::IsNullOrWhiteSpace([string]$p)) { continue }
        if (-not (Test-Path -LiteralPath ([string]$p) -PathType Container)) { continue }
        if ($smart -contains [string]$p) { continue }

        $entries += [pscustomobject]@{
            Path = [string]$p
            Removable = $true
            Kind = 'SAVED'
        }

        if ($entries.Count -ge 999) { break }
    }

    return @($entries)
}

function Select-SmartCockatriceDeckFolder($Config, [string]$CurrentFolder, [bool]$AllowCancel = $false, [bool]$ForceSelection = $false) {
    while ($true) {
        Write-Header
        Write-Host 'SELECT COCKATRICE DECK FOLDER'
        Write-Host

        $entries = @(Get-DeckFolderMenuEntries $Config)

        if ($entries.Count -gt 0) {
            Write-Host 'Cockatrice deck folders:' -ForegroundColor Cyan
            Write-Host

            for ($i = 0; $i -lt $entries.Count; $i++) {
                $label = ''

                if (-not [string]::IsNullOrWhiteSpace($CurrentFolder) -and
                    [string]$entries[$i].Path -eq [string]$CurrentFolder) {
                    $label = '  [CURRENT]'
                }

                Write-Host ("  [{0}] {1}{2}" -f ($i + 1), $entries[$i].Path, $label)
            }
        } else {
            Write-Host 'No Cockatrice deck folders were found automatically.' -ForegroundColor Yellow
        }

        Write-Host
        Write-Host '  [S] Search / Select another folder'

        $removable = @()
        for ($i = 0; $i -lt $entries.Count; $i++) {
            if ($entries[$i].Removable -and ($i + 1) -ge 3) {
                $removable += ($i + 1)
            }
        }

        if ($removable.Count -gt 0) {
            Write-Host '  [R] Remove saved folder (custom folders 3-999 only)'
        }

        if ($AllowCancel -and -not $ForceSelection) {
            Write-Host '  [Q] Cancel / Back'
        }

        Write-Host
        $choice = (Read-Host 'Choose folder').Trim()

        if ($choice -match '^[Ss]$') {
            $picked = Browse-ForDeckFolder $CurrentFolder

            if (-not [string]::IsNullOrWhiteSpace($picked)) {
                Add-SavedDeckFolder $Config $picked
                return $picked
            }

            continue
        }

        if ($choice -match '^[Rr]$' -and $removable.Count -gt 0) {
            Write-Header
            Write-Host 'REMOVE SAVED DECK FOLDER'
            Write-Host
            Write-Host 'Only custom saved folders can be removed.'
            Write-Host 'Smart folders [1] and [2] are protected.'
            Write-Host

            foreach ($num in $removable) {
                $entry = $entries[$num - 1]
                $currentMark = ''
                if ([string]$entry.Path -eq [string]$CurrentFolder) {
                    $currentMark = '  [CURRENT]'
                }

                Write-Host ("  [{0}] {1}{2}" -f $num, $entry.Path, $currentMark)
            }

            Write-Host
            Write-Host '  [Q] Cancel'
            Write-Host
            $removeChoice = (Read-Host 'Remove folder number (3-999)').Trim()

            if ($removeChoice -match '^[Qq]$') {
                continue
            }

            $rn = 0
            if ([int]::TryParse($removeChoice, [ref]$rn)) {
                if ($rn -ge 3 -and $rn -le 999 -and $removable -contains $rn) {
                    $removePath = [string]$entries[$rn - 1].Path
                    $wasCurrent = ([string]$removePath -eq [string]$CurrentFolder)

                    Remove-SavedDeckFolder $Config $removePath

                    Write-Host
                    Write-Host 'REMOVED:' -ForegroundColor Green
                    Write-Host "  $removePath"

                    if ($wasCurrent) {
                        Write-Host
                        Write-Host 'That folder was CURRENT.' -ForegroundColor Yellow
                        Write-Host 'You must select a new current deck folder before returning to the main menu.'
                        Start-Sleep -Milliseconds 900

                        # Force the user to pick another current folder.
                        return Select-SmartCockatriceDeckFolder $Config $null $false $true
                    }

                    Write-Host
                    Write-Host 'Saved folder removed.'
                    Start-Sleep -Milliseconds 700
                    continue
                }
            }

            Write-Host
            Write-Host 'Invalid removal selection.' -ForegroundColor Yellow
            Start-Sleep -Milliseconds 700
            continue
        }

        if ($AllowCancel -and -not $ForceSelection -and $choice -match '^[Qq]$') {
            return $null
        }

        $n = 0
        if ([int]::TryParse($choice, [ref]$n)) {
            if ($n -ge 1 -and $n -le $entries.Count) {
                return [string]$entries[$n - 1].Path
            }
        }

        Write-Host
        Write-Host 'Invalid choice.' -ForegroundColor Yellow
        Start-Sleep -Milliseconds 700
    }
}

function First-TimeSetup {
    $tempConfig = [pscustomobject]@{
        SavedDeckFolders = @()
    }

    $folder = Select-SmartCockatriceDeckFolder $tempConfig $null $false $true

    $config = [ordered]@{
        CockatriceDeckFolder = $folder
        IncludeMaybeboard = $false
        RecentDecks = @()
        SavedDeckFolders = @($tempConfig.SavedDeckFolders)
        CurrentLinkedUrl = $null
        CurrentLinkedFile = $null
        Created = (Get-Date).ToString('s')
    }

    Save-Config $config

    Write-Host
    Write-Host 'Deck folder saved:' -ForegroundColor Green
    Write-Host "  $folder"
    Start-Sleep -Milliseconds 700

    return [pscustomobject]$config
}

function Load-Config {
    if (-not (Test-Path -LiteralPath $ConfigPath)) { return First-TimeSetup }

    try {
        $c = Get-Content -LiteralPath $ConfigPath -Raw | ConvertFrom-Json

        if (-not $c.PSObject.Properties['RecentDecks']) {
            Add-Member -InputObject $c -MemberType NoteProperty -Name RecentDecks -Value @()
        }
        if (-not $c.PSObject.Properties['SavedDeckFolders']) {
            Add-Member -InputObject $c -MemberType NoteProperty -Name SavedDeckFolders -Value @()
        }
        if (-not $c.PSObject.Properties['CurrentLinkedUrl']) {
            Add-Member -InputObject $c -MemberType NoteProperty -Name CurrentLinkedUrl -Value $null
        }
        if (-not $c.PSObject.Properties['CurrentLinkedFile']) {
            Add-Member -InputObject $c -MemberType NoteProperty -Name CurrentLinkedFile -Value $null
        }
        if (-not $c.PSObject.Properties['IncludeMaybeboard']) {
            Add-Member -InputObject $c -MemberType NoteProperty -Name IncludeMaybeboard -Value $false
        }

        if (-not $c.PSObject.Properties['CockatriceDeckFolder'] -or
            -not (Test-Path -LiteralPath ([string]$c.CockatriceDeckFolder) -PathType Container)) {

            Write-Host 'Saved Cockatrice deck folder no longer exists.' -ForegroundColor Yellow
            $newFolder = Select-SmartCockatriceDeckFolder $c ([string]$c.CockatriceDeckFolder) $false $true
            if ([string]::IsNullOrWhiteSpace($newFolder)) {
                throw 'No replacement deck folder was selected.'
            }
            $c.CockatriceDeckFolder = $newFolder
            Save-Config $c
        }

        return $c
    } catch {
        Write-Host "Config is invalid: $($_.Exception.Message)" -ForegroundColor Yellow
        Write-Host 'Running setup again...'
        Start-Sleep -Seconds 1
        return First-TimeSetup
    }
}

function Get-PropertyValue($Object, [string[]]$Names) {
    if ($null -eq $Object) { return $null }
    foreach ($n in $Names) {
        $p = $Object.PSObject.Properties[$n]
        if ($p) { return $p.Value }
    }
    return $null
}

function Invoke-CockatriceStyleDownload {
    param(
        [Parameter(Mandatory=$true)][string]$Url,
        [ValidateSet('text','json')][string]$As = 'text'
    )

    $curl = Join-Path $env:SystemRoot 'System32\curl.exe'
    $temp = Join-Path ([System.IO.Path]::GetTempPath()) ("CockatriceDeckImport_" + [guid]::NewGuid().ToString('N') + ".tmp")

    try {
        if (Test-Path -LiteralPath $curl -PathType Leaf) {
            # Mirror Cockatrice's intentionally simple request style as closely
            # as practical while using Windows curl rather than PowerShell's
            # older .NET web stack.
            $args = @(
                '--location',
                '--fail',
                '--silent',
                '--show-error',
                '--connect-timeout', '20',
                '--max-time', '60',
                '--user-agent', 'Cockatrice 2.10',
                '--header', 'Accept: */*',
                '--output', $temp,
                $Url
            )

            $output = & $curl @args 2>&1
            $exit = $LASTEXITCODE

            if ($exit -eq 0 -and (Test-Path -LiteralPath $temp) -and (Get-Item -LiteralPath $temp).Length -gt 0) {
                $raw = [System.IO.File]::ReadAllText($temp, [System.Text.Encoding]::UTF8)

                if ($As -eq 'json') {
                    try {
                        return ($raw | ConvertFrom-Json -ErrorAction Stop)
                    }
                    catch {
                        throw "Downloaded data was not valid JSON.`r`n$($_.Exception.Message)"
                    }
                }

                return $raw
            }

            $curlMessage = ($output | Out-String).Trim()
            if (-not $curlMessage) { $curlMessage = "curl.exe exited with code $exit." }
            throw $curlMessage
        }

        # Fallback for older Windows builds without curl.exe.
        $headers = @{
            'User-Agent' = 'Cockatrice 2.10'
            'Accept' = '*/*'
        }

        if ($As -eq 'json') {
            return Invoke-RestMethod -Uri $Url -Headers $headers -Method Get -TimeoutSec 60 -ErrorAction Stop
        }

        $response = Invoke-WebRequest -Uri $Url -Headers $headers -UseBasicParsing -Method Get -ErrorAction Stop
        return [string]$response.Content
    }
    finally {
        Remove-Item -LiteralPath $temp -Force -ErrorAction SilentlyContinue
    }
}

function Get-OnlineDeck([string]$DeckUrl) {
    $info = Get-DeckSourceInfo $DeckUrl

    if ($info.Source -eq 'ARCHIDEKT') {
        $api = "https://archidekt.com/api/decks/$($info.Id)/?format=json"

        Write-Host "Detected source : ARCHIDEKT"
        Write-Host "Downloading deck: $($info.Id)"
        Write-Host "Example format  : https://archidekt.com/decks/12345678/example-deck"

        try {
            $data = Invoke-RestMethod -Uri $api -Method Get -Headers @{
                'Accept' = 'application/json'
                'User-Agent' = 'Universal-Cockatrice-Deck-Updater/5.0'
            } -TimeoutSec 30

            return [pscustomobject]@{
                Source = 'ARCHIDEKT'
                Data = $data
                Url = $DeckUrl
                Id = $info.Id
            }
        } catch {
            throw "Archidekt download failed. Your local .cod was NOT changed.`n$($_.Exception.Message)"
        }
    }

    # Moxfield public decks.
    # Reused from Cockatrice_Universal_Deck_Importer_5.0_Release_11.ps1,
    # which successfully loads the same public Moxfield URLs.
    #
    # Exact Cockatrice-style endpoint first, including trailing slash.
    $cockatriceApi = "https://api.moxfield.com/v2/decks/all/$($info.Id)/"

    Write-Host "Detected source : MOXFIELD"
    Write-Host "Downloading deck: $($info.Id)"
    Write-Host "Example format  : https://www.moxfield.com/decks/ExampleDeckID"

    $deck = $null
    $errors = @()

    # 1) Known-working path from the Universal Deck Importer:
    #    Windows curl.exe + Cockatrice 2.10 User-Agent + Accept */*
    try {
        Write-Host "Trying Cockatrice-style endpoint:"
        Write-Host "  $cockatriceApi"

        $deck = Invoke-CockatriceStyleDownload -Url $cockatriceApi -As json

        if ($deck) {
            Write-Host 'Moxfield download method: Cockatrice-style curl' -ForegroundColor Green
        }
    }
    catch {
        $errors += ("curl/Cockatrice-style: " + $_.Exception.Message)
    }

    # 2) Same compatibility fallback used by the working importer.
    if (-not $deck) {
        $api2 = "https://api2.moxfield.com/v3/decks/all/$($info.Id)"

        try {
            Write-Host "Trying api2 fallback:"
            Write-Host "  $api2"

            $deck = Invoke-CockatriceStyleDownload -Url $api2 -As json

            if ($deck) {
                Write-Host 'Moxfield download method: api2 Cockatrice-style curl' -ForegroundColor Green
            }
        }
        catch {
            $errors += ("api2 fallback: " + $_.Exception.Message)
        }
    }

    # 3) Same final PowerShell-native fallback as the working importer.
    if (-not $deck) {
        try {
            Write-Host 'Trying PowerShell Cockatrice-style fallback...'

            $deck = Invoke-RestMethod `
                -Uri $cockatriceApi `
                -Headers @{
                    'User-Agent' = 'Cockatrice 2.10'
                    'Accept' = '*/*'
                } `
                -Method Get `
                -TimeoutSec 60 `
                -ErrorAction Stop

            if ($deck) {
                Write-Host 'Moxfield download method: PowerShell Cockatrice-style' -ForegroundColor Green
            }
        }
        catch {
            $errors += ("PowerShell fallback: " + $_.Exception.Message)
        }
    }

    if (-not $deck) {
        $detail = ($errors -join "`r`n  - ")

        throw @"
Moxfield blocked all direct import methods.

This updater is now using the SAME Moxfield request method as the
Cockatrice Universal Deck Importer that successfully loads these links.

Tried:
  1. https://api.moxfield.com/v2/decks/all/$($info.Id)/
     with Windows curl.exe
     User-Agent: Cockatrice 2.10
     Accept: */*

  2. https://api2.moxfield.com/v3/decks/all/$($info.Id)
     with the same Cockatrice-style request

  3. PowerShell fallback using Cockatrice 2.10

Your local .cod was NOT changed.

Details:
  - $detail
"@
    }

    return [pscustomobject]@{
        Source = 'MOXFIELD'
        Data = $deck
        Url = $DeckUrl
        Id = $info.Id
    }

}

function Get-ArchidektDeck([string]$DeckUrl) {
    # Compatibility wrapper for older config/code paths.
    $online = Get-OnlineDeck $DeckUrl
    return $online.Data
}

function Get-CategoryInfo($Deck) {
    $map = @{}
    foreach ($cat in @($Deck.categories)) {
        if ($null -eq $cat) { continue }
        $name = [string](Get-PropertyValue $cat @('name'))
        $id = [string](Get-PropertyValue $cat @('id'))
        $included = Get-PropertyValue $cat @('includedInDeck')
        $obj = [pscustomobject]@{
            Name = $name
            Included = if ($null -eq $included) { $true } else { [bool]$included }
        }
        if ($name) { $map[$name.ToLowerInvariant()] = $obj }
        if ($id) { $map["id:$id"] = $obj }
    }
    return $map
}

function Get-EntryCategoryNames($Entry, $CategoryMap) {
    $names = @()

    foreach ($v in @($Entry.categories)) {
        if ($null -eq $v) { continue }

        if ($v -is [string]) {
            $names += [string]$v
            continue
        }
        if ($v -is [int] -or $v -is [long]) {
            $k = "id:$v"
            if ($CategoryMap.ContainsKey($k)) { $names += [string]$CategoryMap[$k].Name }
            continue
        }
        $n = Get-PropertyValue $v @('name')
        if ($n) { $names += [string]$n }
        else {
            $cid = Get-PropertyValue $v @('id')
            if ($null -ne $cid) {
                $k = "id:$cid"
                if ($CategoryMap.ContainsKey($k)) { $names += [string]$CategoryMap[$k].Name }
            }
        }
    }

    $single = Get-PropertyValue $Entry @('category')
    if ($single) {
        if ($single -is [string]) { [void]$names.Add([string]$single) }
        else {
            $n = Get-PropertyValue $single @('name')
            if ($n) { $names += [string]$n }
        }
    }
    return ($names | Select-Object -Unique)
}

function Test-EntryIncluded($Entry, $CategoryNames, $CategoryMap, [bool]$IncludeMaybeboard) {
    if ($IncludeMaybeboard) { return $true }

    # If the response explicitly marks the entry itself as excluded, honor it.
    $entryIncluded = Get-PropertyValue $Entry @('includedInDeck')
    if ($null -ne $entryIncluded -and -not [bool]$entryIncluded) { return $false }

    # Archidekt categories can be declared includedInDeck=false.
    foreach ($name in $CategoryNames) {
        $k = ([string]$name).ToLowerInvariant()
        if ($CategoryMap.ContainsKey($k) -and -not $CategoryMap[$k].Included) { return $false }
    }
    return $true
}

function Get-CockatriceName($Entry) {
    $card = Get-PropertyValue $Entry @('card')
    if ($null -eq $card) { return $null }

    $oracle = Get-PropertyValue $card @('oracleCard')
    $name = $null
    $layout = $null

    if ($oracle) {
        $name = Get-PropertyValue $oracle @('name')
        $layout = Get-PropertyValue $oracle @('layout')
    }
    if (-not $name) { $name = Get-PropertyValue $card @('displayName','name') }
    if (-not $name) { return $null }

    $name = [string]$name
    $layout = ([string]$layout).ToLowerInvariant()

    # Cockatrice stores true two-faced cards under the front face only.
    # Split/adventure/aftermath/room/prepare keep A // B.
    if ($name -like '* // *' -and $layout -in @('transform','modal_dfc','meld')) {
        return ($name -split '\s+//\s+',2)[0]
    }
    return $name
}



# =============================================================================
# Cockatrice card-name normalization
# Reuses the same safety order as the Universal Deck Importer:
# exact -> flavor alias -> // handling -> unique loose match -> unknown.
# =============================================================================

function Get-CockatriceDataRootForNormalization($Config) {
    $candidates = @()

    function Add-Candidate([string]$Path) {
        if ([string]::IsNullOrWhiteSpace($Path)) { return }
        if ($script:NormRootCandidates -notcontains $Path) {
            $script:NormRootCandidates += $Path
        }
    }

    $script:NormRootCandidates = @()

    # 1) Current selected deck folder's parent.
    if ($Config -and $Config.CockatriceDeckFolder) {
        try {
            $deckFolder = [IO.Path]::GetFullPath([string]$Config.CockatriceDeckFolder).TrimEnd('\')
            if ((Split-Path $deckFolder -Leaf) -ieq 'decks') {
                Add-Candidate (Split-Path $deckFolder -Parent)
            }
        } catch {}
    }

    # 2) Smart Cockatrice deck locations already known by this updater.
    try {
        foreach ($deckFolder in @(Find-SmartCockatriceDeckFolders)) {
            if (-not [string]::IsNullOrWhiteSpace([string]$deckFolder)) {
                try {
                    Add-Candidate (Split-Path ([IO.Path]::GetFullPath([string]$deckFolder).TrimEnd('\')) -Parent)
                } catch {}
            }
        }
    } catch {}

    # 3) Common direct data roots.
    if ($env:LOCALAPPDATA) {
        Add-Candidate (Join-Path $env:LOCALAPPDATA 'Cockatrice\Cockatrice')
    }
    if ($env:USERPROFILE) {
        Add-Candidate (Join-Path $env:USERPROFILE 'Desktop\CockatricePortable\data')
        Add-Candidate (Join-Path $env:USERPROFILE 'Downloads\CockatricePortable\data')
        Add-Candidate (Join-Path $env:USERPROFILE 'Documents\CockatricePortable\data')
    }

    foreach ($root in $script:NormRootCandidates) {
        if (Test-Path -LiteralPath (Join-Path $root 'cards.xml') -PathType Leaf) {
            return $root
        }
    }

    return $null
}

function Add-CardNamesFromXml([string]$Path, $Index) {
    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) { return }

    $settings = New-Object System.Xml.XmlReaderSettings
    $settings.IgnoreComments = $true
    $settings.IgnoreWhitespace = $true
    $settings.DtdProcessing = [System.Xml.DtdProcessing]::Prohibit
    $settings.CloseInput = $true

    $reader = [System.Xml.XmlReader]::Create($Path, $settings)

    try {
        while ($reader.Read()) {
            if ($reader.NodeType -ne [System.Xml.XmlNodeType]::Element -or
                $reader.Name -ne 'card') {
                continue
            }

            $cardDepth = $reader.Depth
            $name = ''

            while ($reader.Read()) {
                if ($reader.NodeType -eq [System.Xml.XmlNodeType]::EndElement -and
                    $reader.Depth -eq $cardDepth -and
                    $reader.Name -eq 'card') {
                    break
                }

                if ($reader.NodeType -eq [System.Xml.XmlNodeType]::Element -and
                    $reader.Name -eq 'name' -and
                    -not $name) {
                    $name = $reader.ReadElementContentAsString()
                }
            }

            if (-not [string]::IsNullOrWhiteSpace($name) -and
                -not $Index.ContainsKey($name)) {
                $Index[$name] = $name
            }
        }
    }
    finally {
        $reader.Dispose()
    }
}

function Get-LooseCardKey([string]$Name) {
    if ([string]::IsNullOrWhiteSpace($Name)) { return '' }

    # Deliberately conservative:
    # ignore case, spaces and punctuation; keep letters/numbers.
    return (($Name.ToLowerInvariant().ToCharArray() |
        Where-Object { [char]::IsLetterOrDigit($_) }) -join '')
}

function Load-CockatriceCardIndex($Config) {
    $root = Get-CockatriceDataRootForNormalization $Config
    if (-not $root) {
        return $false
    }

    if ($Script:CockatriceCardIndex -and
        $Script:CockatriceCardIndexRoot -ieq $root) {
        return $true
    }

    Write-Host
    Write-Host 'Loading Cockatrice card-name database for validation...' -ForegroundColor Cyan
    Write-Host "  $root"

    $idx = New-Object 'System.Collections.Generic.Dictionary[string,string]' ([System.StringComparer]::OrdinalIgnoreCase)

    Add-CardNamesFromXml (Join-Path $root 'cards.xml') $idx

    $customsets = Join-Path $root 'customsets'
    if (Test-Path -LiteralPath $customsets -PathType Container) {
        foreach ($file in Get-ChildItem -LiteralPath $customsets -Filter '*.xml' -File -ErrorAction SilentlyContinue) {
            try { Add-CardNamesFromXml $file.FullName $idx } catch {}
        }
    }

    $loose = @{}
    $ambiguous = @{}

    foreach ($canonical in $idx.Keys) {
        $key = Get-LooseCardKey $canonical
        if ([string]::IsNullOrWhiteSpace($key)) { continue }

        if ($ambiguous.ContainsKey($key)) { continue }

        if ($loose.ContainsKey($key)) {
            if ([string]$loose[$key] -ine [string]$canonical) {
                $loose.Remove($key)
                $ambiguous[$key] = $true
            }
        } else {
            $loose[$key] = [string]$canonical
        }
    }

    $Script:CockatriceCardIndex = $idx
    $Script:CockatriceCardIndexRoot = $root
    $Script:CockatriceLooseMap = $loose
    $Script:CockatriceLooseAmbiguous = $ambiguous

    Write-Host ("  Loaded {0:N0} Cockatrice card names." -f $idx.Count) -ForegroundColor Green
    return $true
}

function Load-FlavorNameCache {
    $Script:FlavorNameMap = @{}
    $Script:FlavorNameAmbiguous = @{}

    if (-not (Test-Path -LiteralPath $Script:FlavorNameCachePath -PathType Leaf)) {
        return $false
    }

    try {
        $rows = @(Get-Content -LiteralPath $Script:FlavorNameCachePath -Raw | ConvertFrom-Json)

        foreach ($row in $rows) {
            $flavor = [string]$row.FlavorName
            $canonical = [string]$row.CanonicalName

            if ([string]::IsNullOrWhiteSpace($flavor) -or
                [string]::IsNullOrWhiteSpace($canonical)) {
                continue
            }

            $key = $flavor.ToLowerInvariant()

            if ($Script:FlavorNameAmbiguous.ContainsKey($key)) { continue }

            if ($Script:FlavorNameMap.ContainsKey($key)) {
                if ([string]$Script:FlavorNameMap[$key] -ine $canonical) {
                    $Script:FlavorNameMap.Remove($key)
                    $Script:FlavorNameAmbiguous[$key] = $true
                }
            } else {
                $Script:FlavorNameMap[$key] = $canonical
            }
        }

        return $true
    }
    catch {
        return $false
    }
}

function Update-FlavorNameCacheFromScryfall {
    Write-Host
    Write-Host 'Updating Scryfall flavor-name aliases...' -ForegroundColor Cyan

    $headers = @{
        'User-Agent' = 'Cockatrice-Deck-Updater/1.8'
        'Accept' = 'application/json;q=0.9,*/*;q=0.8'
    }

    # Primary query mirrors the Scryfall search requested by the user.
    $url = 'https://api.scryfall.com/cards/search?q=is%3Aflavor_name&unique=prints&order=name'
    $pairs = @()
    $seen = @{}
    $usedFallbackQuery = $false

    while ($url) {
        try {
            $response = Invoke-RestMethod -Uri $url -Headers $headers -Method Get -TimeoutSec 30 -ErrorAction Stop
        }
        catch {
            # Compatibility fallback used by the Universal Deck Importer.
            if (-not $usedFallbackQuery) {
                $usedFallbackQuery = $true
                $url = 'https://api.scryfall.com/cards/search?q=has%3Aflavorname&unique=prints&order=name'
                continue
            }
            throw
        }

        foreach ($card in @($response.data)) {
            $flavor = [string]$card.flavor_name
            $canonical = [string]$card.name

            if ([string]::IsNullOrWhiteSpace($flavor) -or
                [string]::IsNullOrWhiteSpace($canonical)) {
                continue
            }

            $pairKey = ($flavor.ToLowerInvariant() + [char]31 + $canonical.ToLowerInvariant())

            if (-not $seen.ContainsKey($pairKey)) {
                $seen[$pairKey] = $true
                $pairs += [pscustomobject]@{
                    FlavorName = $flavor
                    CanonicalName = $canonical
                }
            }
        }

        if ($response.has_more -and $response.next_page) {
            $url = [string]$response.next_page
            Start-Sleep -Milliseconds 120
        } else {
            $url = $null
        }
    }

    $pairs |
        Sort-Object FlavorName, CanonicalName |
        ConvertTo-Json -Depth 4 |
        Set-Content -LiteralPath $Script:FlavorNameCachePath -Encoding UTF8

    [void](Load-FlavorNameCache)

    Write-Host ("  Cached {0:N0} flavor-name mappings." -f $pairs.Count) -ForegroundColor Green
}

function Initialize-FlavorNameAliases {
    if ([string]::IsNullOrWhiteSpace($Script:FlavorNameCachePath)) {
        $baseDir = $ScriptDir
        if ([string]::IsNullOrWhiteSpace($baseDir)) {
            if (-not [string]::IsNullOrWhiteSpace($PSScriptRoot)) {
                $baseDir = $PSScriptRoot
            } else {
                $baseDir = (Get-Location).Path
            }
        }

        $Script:FlavorNameCachePath = Join-Path -Path $baseDir -ChildPath 'Scryfall_FlavorName_Aliases.json'
    }
    $loaded = Load-FlavorNameCache
    $refresh = -not $loaded

    if (-not $refresh -and (Test-Path -LiteralPath $Script:FlavorNameCachePath)) {
        try {
            $age = (Get-Date) - (Get-Item -LiteralPath $Script:FlavorNameCachePath).LastWriteTime
            if ($age.TotalDays -ge 30) { $refresh = $true }
        } catch {}
    }

    if ($refresh) {
        try {
            Update-FlavorNameCacheFromScryfall
        }
        catch {
            Write-Host
            Write-Host 'Scryfall flavor-name refresh failed; using any existing cache.' -ForegroundColor Yellow
            [void](Load-FlavorNameCache)
        }
    }
}

function Resolve-CockatriceCardName([string]$Name) {
    $result = [ordered]@{
        Original = $Name
        Name = $Name
        Valid = $false
        Reason = 'Unknown'
    }

    if ([string]::IsNullOrWhiteSpace($Name) -or -not $Script:CockatriceCardIndex) {
        return [pscustomobject]$result
    }

    $typed = $Name.Trim()

    # 1) Exact Cockatrice name ALWAYS wins.
    if ($Script:CockatriceCardIndex.ContainsKey($typed)) {
        $result.Name = [string]$Script:CockatriceCardIndex[$typed]
        $result.Valid = $true
        $result.Reason = 'Exact'
        return [pscustomobject]$result
    }

    # 2) Scryfall flavor / alternate printed name -> canonical real card name.
    $flavorKey = $typed.ToLowerInvariant()

    if (-not $Script:FlavorNameAmbiguous.ContainsKey($flavorKey) -and
        $Script:FlavorNameMap.ContainsKey($flavorKey)) {

        $canonical = [string]$Script:FlavorNameMap[$flavorKey]

        if ($Script:CockatriceCardIndex.ContainsKey($canonical)) {
            $result.Name = [string]$Script:CockatriceCardIndex[$canonical]
            $result.Valid = $true
            $result.Reason = 'Flavor name alias'
            return [pscustomobject]$result
        }
    }

    # 3) "Front // Back":
    # Full exact was already checked above. Only collapse to the front face
    # when the full name is NOT in Cockatrice but the front face IS.
    if ($typed -match '^(?<front>.+?)\s*//\s*(?<back>.+)$') {
        $front = $Matches['front'].Trim()

        if ($front -and $Script:CockatriceCardIndex.ContainsKey($front)) {
            $result.Name = [string]$Script:CockatriceCardIndex[$front]
            $result.Valid = $true
            $result.Reason = 'Front-face canonical name'
            return [pscustomobject]$result
        }
    }

    # 4) Conservative unique punctuation/case-insensitive match.
    $looseKey = Get-LooseCardKey $typed

    if (-not [string]::IsNullOrWhiteSpace($looseKey) -and
        -not $Script:CockatriceLooseAmbiguous.ContainsKey($looseKey) -and
        $Script:CockatriceLooseMap.ContainsKey($looseKey)) {

        $canonical = [string]$Script:CockatriceLooseMap[$looseKey]

        if ($Script:CockatriceCardIndex.ContainsKey($canonical)) {
            $result.Name = [string]$Script:CockatriceCardIndex[$canonical]
            $result.Valid = $true
            $result.Reason = 'Unique punctuation match'
            return [pscustomobject]$result
        }
    }

    return [pscustomobject]$result
}

function Normalize-RemoteDeckCardNames($Remote, $Config) {
    if (-not (Load-CockatriceCardIndex $Config)) {
        Write-Host
        Write-Host 'WARNING: Cockatrice cards.xml was not found.' -ForegroundColor Yellow
        Write-Host 'Card-name normalization was skipped; deck import will continue.'
        return $Remote
    }

    Initialize-FlavorNameAliases

    $newMain = @{}
    $newSide = @{}
    $fixes = @()
    $unknown = @()

    function Add-NormalizedZone($SourceTable, $TargetTable, [string]$ZoneName) {
        foreach ($originalName in @($SourceTable.Keys)) {
            $qty = [int]$SourceTable[$originalName]
            $resolved = Resolve-CockatriceCardName ([string]$originalName)
            $finalName = [string]$resolved.Name

            if ($resolved.Valid) {
                if ($resolved.Reason -ne 'Exact') {
                    $script:NameFixRows += [pscustomobject]@{
                        Zone = $ZoneName
                        Original = [string]$originalName
                        Fixed = $finalName
                        Reason = [string]$resolved.Reason
                    }
                }
            } else {
                $script:UnknownNameRows += [pscustomobject]@{
                    Zone = $ZoneName
                    Name = [string]$originalName
                }
            }

            if ($TargetTable.ContainsKey($finalName)) {
                $TargetTable[$finalName] += $qty
            } else {
                $TargetTable[$finalName] = $qty
            }
        }
    }

    $script:NameFixRows = @()
    $script:UnknownNameRows = @()

    Add-NormalizedZone $Remote.Main $newMain 'MAIN'
    Add-NormalizedZone $Remote.Side $newSide 'SIDE'

    $total = 0
    foreach ($v in $newMain.Values) { $total += [int]$v }
    foreach ($v in $newSide.Values) { $total += [int]$v }

    Write-Host
    Write-Host 'CARD NAME NORMALIZATION' -ForegroundColor Cyan
    Write-Host '------------------------------------------------------------'

    $flavorCount = @($script:NameFixRows | Where-Object { $_.Reason -eq 'Flavor name alias' }).Count
    $frontCount  = @($script:NameFixRows | Where-Object { $_.Reason -eq 'Front-face canonical name' }).Count
    $looseCount  = @($script:NameFixRows | Where-Object { $_.Reason -eq 'Unique punctuation match' }).Count

    Write-Host ("Flavor-name fixes : {0}" -f $flavorCount)
    Write-Host ("// name fixes      : {0}" -f $frontCount)
    Write-Host ("Punctuation fixes  : {0}" -f $looseCount)
    Write-Host ("Unknown names      : {0}" -f $script:UnknownNameRows.Count)

    if ($script:NameFixRows.Count -gt 0) {
        Write-Host
        Write-Host 'Fixed names:' -ForegroundColor Green

        foreach ($row in $script:NameFixRows) {
            Write-Host ("  {0} -> {1}  [{2}]" -f $row.Original, $row.Fixed, $row.Reason)
        }
    }

    if ($script:UnknownNameRows.Count -gt 0) {
        Write-Host
        Write-Host 'Still unknown in local Cockatrice cards.xml:' -ForegroundColor Yellow

        foreach ($row in $script:UnknownNameRows) {
            Write-Host ("  {0}  [{1}]" -f $row.Name, $row.Zone)
        }

        Write-Host
        Write-Host 'Unknown names are preserved exactly instead of being guessed.' -ForegroundColor Yellow
    }

    return [pscustomobject]@{
        Main = $newMain
        Side = $newSide
        Total = $total
        NameFixes = @($script:NameFixRows)
        UnknownNames = @($script:UnknownNameRows)
    }
}

function Get-MoxfieldBoardObject($Deck, [string]$BoardName) {
    if ($null -eq $Deck) { return $null }

    # Older/common API shape: top-level mainboard/sideboard/commanders/etc.
    $p = $Deck.PSObject.Properties[$BoardName]
    if ($p) { return $p.Value }

    # Newer v3 shape: top-level boards object.
    $boardsProp = $Deck.PSObject.Properties['boards']
    if ($boardsProp -and $boardsProp.Value) {
        $bp = $boardsProp.Value.PSObject.Properties[$BoardName]
        if ($bp) { return $bp.Value }
    }

    return $null
}

function Get-MoxfieldBoardEntries($Board) {
    if ($null -eq $Board) { return @() }

    # Most Moxfield responses use board.cards as an object keyed by card id/name.
    $cardsProp = $Board.PSObject.Properties['cards']
    if ($cardsProp -and $cardsProp.Value) {
        $cards = $cardsProp.Value

        if ($cards -is [System.Array]) { return @($cards) }

        $items = @()
        foreach ($prop in $cards.PSObject.Properties) {
            if ($null -ne $prop.Value) { $items += $prop.Value }
        }
        return $items
    }

    # Some shapes are already arrays.
    if ($Board -is [System.Array]) { return @($Board) }

    # Or the board itself may be a dictionary-like object.
    $items = @()
    foreach ($prop in $Board.PSObject.Properties) {
        if ($prop.Name -in @('count','total','name','description')) { continue }
        if ($null -ne $prop.Value -and $prop.Value -isnot [string] -and $prop.Value -isnot [int]) {
            $items += $prop.Value
        }
    }
    return $items
}

function Get-MoxfieldCardName($Entry) {
    if ($null -eq $Entry) { return $null }

    $card = Get-PropertyValue $Entry @('card')
    if ($null -eq $card) { $card = $Entry }

    $name = Get-PropertyValue $card @('name','displayName')
    if (-not $name) {
        $oracle = Get-PropertyValue $card @('oracleCard')
        if ($oracle) { $name = Get-PropertyValue $oracle @('name') }
    }
    if (-not $name) { return $null }

    $name = [string]$name

    # For actual double-faced permanents Cockatrice usually wants the front face.
    $layout = [string](Get-PropertyValue $card @('layout'))
    if ($name -like '* // *' -and $layout.ToLowerInvariant() -in @('transform','modal_dfc','meld')) {
        return ($name -split '\s+//\s+',2)[0]
    }

    return $name
}


function Ask-IncludeMaybeboard([int]$Count) {
    if ($Count -le 0) { return $false }

    Write-Host
    Write-Host ("Maybeboard / Considering cards found: {0}" -f $Count) -ForegroundColor Yellow
    Write-Host
    Write-Host 'Add Maybeboard / Considering cards to Cockatrice SIDEBOARD?'
    Write-Host '  [Y] Yes'
    Write-Host '  [N] No'
    Write-Host

    while ($true) {
        $answer = (Read-Host 'Choice [N]').Trim()

        if ([string]::IsNullOrWhiteSpace($answer)) { return $false }
        if ($answer -match '^[Yy]$') { return $true }
        if ($answer -match '^[Nn]$') { return $false }

        Write-Host 'Choose Y or N.' -ForegroundColor Yellow
    }
}

function Build-MoxfieldRemoteList($Deck, [bool]$IncludeMaybeboard) {
    $main = @{}
    $side = @{}
    $maybeEntries = @()

    function Add-Board([string]$BoardName, [hashtable]$Target) {
        $board = Get-MoxfieldBoardObject $Deck $BoardName
        foreach ($entry in @(Get-MoxfieldBoardEntries $board)) {
            if ($null -eq $entry) { continue }

            $name = Get-MoxfieldCardName $entry
            if ([string]::IsNullOrWhiteSpace($name)) { continue }

            $qty = Get-PropertyValue $entry @('quantity','qty','count')
            if ($null -eq $qty) { $qty = 1 }

            try { $qty = [int]$qty } catch { $qty = 1 }
            if ($qty -le 0) { continue }

            if ($Target.ContainsKey($name)) { $Target[$name] += $qty }
            else { $Target[$name] = $qty }
        }
    }

    function Collect-MaybeBoard([string]$BoardName) {
        $board = Get-MoxfieldBoardObject $Deck $BoardName
        foreach ($entry in @(Get-MoxfieldBoardEntries $board)) {
            if ($null -eq $entry) { continue }

            $name = Get-MoxfieldCardName $entry
            if ([string]::IsNullOrWhiteSpace($name)) { continue }

            $qty = Get-PropertyValue $entry @('quantity','qty','count')
            if ($null -eq $qty) { $qty = 1 }

            try { $qty = [int]$qty } catch { $qty = 1 }
            if ($qty -le 0) { continue }

            $script:MoxMaybeEntries += [pscustomobject]@{
                Name = $name
                Quantity = $qty
            }
        }
    }

    Add-Board 'mainboard' $main
    Add-Board 'sideboard' $side
    Add-Board 'commanders' $side
    Add-Board 'commander' $side
    Add-Board 'companions' $side
    Add-Board 'companion' $side

    $script:MoxMaybeEntries = @()
    Collect-MaybeBoard 'maybeboard'
    Collect-MaybeBoard 'considering'

    $maybeCount = 0
    foreach ($e in $script:MoxMaybeEntries) { $maybeCount += [int]$e.Quantity }

    $includeMaybe = $false
    if ($maybeCount -gt 0) {
        # IncludeMaybeboard=true can still force inclusion for compatibility,
        # otherwise ask the user when a maybe/considering section is present.
        if ($IncludeMaybeboard) {
            $includeMaybe = $true
        } else {
            $includeMaybe = Ask-IncludeMaybeboard $maybeCount
        }
    }

    if ($includeMaybe) {
        foreach ($e in $script:MoxMaybeEntries) {
            if ($side.ContainsKey($e.Name)) { $side[$e.Name] += [int]$e.Quantity }
            else { $side[$e.Name] = [int]$e.Quantity }
        }
    }

    $total = 0
    foreach ($v in $main.Values) { $total += [int]$v }
    foreach ($v in $side.Values) { $total += [int]$v }

    if ($total -eq 0) {
        throw @"
Moxfield returned zero usable cards, so the local .cod was NOT changed.

Possible causes:
  - the deck is private/unlisted and requires login
  - Moxfield changed its response format
  - the URL is not a deck URL

Example:
  https://www.moxfield.com/decks/ExampleDeckID
"@
    }

    return [pscustomobject]@{
        Main = $main
        Side = $side
        Total = $total
    }
}

function Build-UniversalRemoteList($OnlineDeck, [bool]$IncludeMaybeboard, $Config = $null) {
    if ($OnlineDeck.Source -eq 'MOXFIELD') {
        $remote = Build-MoxfieldRemoteList $OnlineDeck.Data $IncludeMaybeboard
    } else {
        $remote = Build-RemoteList $OnlineDeck.Data $IncludeMaybeboard
    }

    if ($Config) {
        return Normalize-RemoteDeckCardNames $remote $Config
    }

    return $remote
}

function Build-RemoteList($Deck, [bool]$IncludeMaybeboard) {
    if ($null -eq $Deck.cards) {
        throw 'Archidekt returned no cards collection. Local deck was NOT changed.'
    }

    $categoryMap = Get-CategoryInfo $Deck
    $main = @{}
    $side = @{}
    $maybe = @{}

    foreach ($entry in @($Deck.cards)) {
        if ($null -eq $entry) { continue }

        $qty = Get-PropertyValue $entry @('quantity','qty')
        if ($null -eq $qty) { $qty = 1 }

        try { $qty = [int]$qty } catch { $qty = 1 }
        if ($qty -le 0) { continue }

        $name = Get-CockatriceName $entry
        if ([string]::IsNullOrWhiteSpace($name)) { continue }

        $cats = Get-EntryCategoryNames $entry $categoryMap

        $isCommander = $false
        $isSide = $false
        $isMaybe = $false

        foreach ($c in $cats) {
            $catName = [string]$c

            if ($catName -match '^(?i)(Commander|Companion)$') {
                $isCommander = $true
            }
            elseif ($catName -match '^(?i)(Sideboard)$') {
                $isSide = $true
            }
            elseif ($catName -match '(?i)(Maybeboard|Maybe Board|Considering|Considering Board)') {
                $isMaybe = $true
            }

            $key = $catName.ToLowerInvariant()
            if ($categoryMap.ContainsKey($key) -and -not $categoryMap[$key].Included) {
                # Archidekt often marks maybe-style categories excluded from deck.
                if ($catName -notmatch '(?i)(Maybeboard|Maybe Board|Considering|Considering Board)') {
                    continue
                }
            }
        }

        if ($isMaybe) {
            if ($maybe.ContainsKey($name)) { $maybe[$name] += $qty }
            else { $maybe[$name] = $qty }
            continue
        }

        $target = if ($isCommander -or $isSide) { $side } else { $main }

        if ($target.ContainsKey($name)) { $target[$name] += $qty }
        else { $target[$name] = $qty }
    }

    $maybeCount = 0
    foreach ($v in $maybe.Values) { $maybeCount += [int]$v }

    if ($maybeCount -gt 0) {
        $includeMaybe = if ($IncludeMaybeboard) { $true } else { Ask-IncludeMaybeboard $maybeCount }

        if ($includeMaybe) {
            foreach ($name in $maybe.Keys) {
                if ($side.ContainsKey($name)) { $side[$name] += [int]$maybe[$name] }
                else { $side[$name] = [int]$maybe[$name] }
            }
        }
    }

    $total = 0
    foreach ($v in $main.Values) { $total += [int]$v }
    foreach ($v in $side.Values) { $total += [int]$v }

    if ($total -eq 0) {
        throw 'Archidekt returned zero usable deck cards. Local deck was NOT changed.'
    }

    return [pscustomobject]@{
        Main = $main
        Side = $side
        Total = $total
    }
}

function Get-ExistingCodCounts([string]$Path) {
    $result = [ordered]@{ Main=@{}; Side=@{}; Total=0 }
    if (-not (Test-Path -LiteralPath $Path)) { return [pscustomobject]$result }

    try {
        [xml]$xml = Get-Content -LiteralPath $Path -Raw
        foreach ($zone in @($xml.cockatrice_deck.zone)) {
            $z = [string]$zone.name
            foreach ($card in @($zone.card)) {
                if ($null -eq $card) { continue }
                $name = [string]$card.name
                $n = [int]$card.number
                if ($z -eq 'side') { $result.Side[$name] = $n }
                else { $result.Main[$name] = $n }
                $result.Total += $n
            }
        }
    } catch {}
    return [pscustomobject]$result
}

function Show-Diff($Old, $New) {
    $all = New-Object System.Collections.Generic.HashSet[string]
    foreach ($k in $Old.Main.Keys) { [void]$all.Add("M|$k") }
    foreach ($k in $Old.Side.Keys) { [void]$all.Add("S|$k") }
    foreach ($k in $New.Main.Keys) { [void]$all.Add("M|$k") }
    foreach ($k in $New.Side.Keys) { [void]$all.Add("S|$k") }

    $changes = 0
    foreach ($item in ($all | Sort-Object)) {
        $parts = $item -split '\|',2
        $zone = $parts[0]; $name = $parts[1]
        $a = if ($zone -eq 'S') { if ($Old.Side.ContainsKey($name)) {[int]$Old.Side[$name]} else {0} }
             else { if ($Old.Main.ContainsKey($name)) {[int]$Old.Main[$name]} else {0} }
        $b = if ($zone -eq 'S') { if ($New.Side.ContainsKey($name)) {[int]$New.Side[$name]} else {0} }
             else { if ($New.Main.ContainsKey($name)) {[int]$New.Main[$name]} else {0} }

        if ($a -ne $b) {
            $changes++
            $tag = if ($zone -eq 'S') { 'SIDE' } else { 'MAIN' }
            if ($a -eq 0) { Write-Host ("  + {0}x {1} [{2}]" -f $b,$name,$tag) -ForegroundColor Green }
            elseif ($b -eq 0) { Write-Host ("  - {0}x {1} [{2}]" -f $a,$name,$tag) -ForegroundColor Red }
            else { Write-Host ("  ~ {0} -> {1}  {2} [{3}]" -f $a,$b,$name,$tag) -ForegroundColor Yellow }
        }
    }
    return $changes
}

function Write-Cod([string]$Path, [string]$DeckName, [string]$SourceUrl, $Remote) {
    $settings = New-Object System.Xml.XmlWriterSettings
    $settings.Indent = $true
    $settings.IndentChars = '    '
    $settings.NewLineChars = "`r`n"
    $settings.NewLineHandling = [System.Xml.NewLineHandling]::Replace
    $settings.Encoding = New-Object System.Text.UTF8Encoding($false)

    $tmp = "$Path.tmp"
    $writer = [System.Xml.XmlWriter]::Create($tmp, $settings)
    try {
        $writer.WriteStartDocument()
        $writer.WriteStartElement('cockatrice_deck')
        $writer.WriteAttributeString('version','1')

        $writer.WriteElementString('deckname',$DeckName)
        $writer.WriteElementString('comments',"Online source: $SourceUrl")

        $writer.WriteStartElement('zone')
        $writer.WriteAttributeString('name','main')
        foreach ($name in ($Remote.Main.Keys | Sort-Object)) {
            $writer.WriteStartElement('card')
            $writer.WriteAttributeString('number',[string]$Remote.Main[$name])
            $writer.WriteAttributeString('name',[string]$name)
            $writer.WriteEndElement()
        }
        $writer.WriteEndElement()

        $writer.WriteStartElement('zone')
        $writer.WriteAttributeString('name','side')
        foreach ($name in ($Remote.Side.Keys | Sort-Object)) {
            $writer.WriteStartElement('card')
            $writer.WriteAttributeString('number',[string]$Remote.Side[$name])
            $writer.WriteAttributeString('name',[string]$name)
            $writer.WriteEndElement()
        }
        $writer.WriteEndElement()

        $writer.WriteEndElement()
        $writer.WriteEndDocument()
    } finally {
        $writer.Dispose()
    }

    # Validate before replacing anything.
    [xml](Get-Content -LiteralPath $tmp -Raw) | Out-Null
    Move-Item -LiteralPath $tmp -Destination $Path -Force
}

function Backup-Deck([string]$Path) {
    if (-not (Test-Path -LiteralPath $Path)) { return $null }
    if (-not (Test-Path -LiteralPath $BackupRoot)) { New-Item -ItemType Directory -Path $BackupRoot | Out-Null }
    $stamp = Get-Date -Format 'yyyyMMdd_HHmmss'
    $base = [IO.Path]::GetFileNameWithoutExtension($Path)
    $backup = Join-Path $BackupRoot ("{0}_{1}.cod" -f $base,$stamp)
    Copy-Item -LiteralPath $Path -Destination $backup -Force
    return $backup
}


function Choose-SaveMode([string]$DefaultDeckName) {
    while ($true) {
        Write-Host
        Write-Host 'Save option:'
        Write-Host '  [1] Update normal Cockatrice save'
        Write-Host '  [2] Save as a NEW deck'
        Write-Host '  [Q] Quit'
        Write-Host
        $choice = Read-Host 'Choice [1]'
        if ([string]::IsNullOrWhiteSpace($choice)) { $choice = '1' }

        switch ($choice.ToUpperInvariant()) {
            '1' { return [pscustomobject]@{ Mode='Update'; DeckName=$DefaultDeckName } }
            '2' {
                while ($true) {
                    Write-Host
                    $newName = (Read-Host 'New deck name').Trim()
                    if (-not [string]::IsNullOrWhiteSpace($newName)) {
                        return [pscustomobject]@{ Mode='SaveAs'; DeckName=$newName }
                    }
                    Write-Host 'Please enter a deck name.' -ForegroundColor Yellow
                }
            }
            'Q' { return [pscustomobject]@{ Mode='Quit'; DeckName=$DefaultDeckName } }
            default { Write-Host 'Choose 1, 2, or Q.' -ForegroundColor Yellow }
        }
    }
}

function Confirm-Overwrite([string]$Path) {
    if (-not (Test-Path -LiteralPath $Path)) { return $true }
    Write-Host
    Write-Host 'A deck already exists with that name:' -ForegroundColor Yellow
    Write-Host "  $Path"
    return ((Read-Host 'Overwrite it? [y/N]') -match '^[Yy]')
}


function Ensure-RecentDecksProperty($Config) {
    if (-not $Config.PSObject.Properties['RecentDecks']) {
        Add-Member -InputObject $Config -MemberType NoteProperty -Name RecentDecks -Value @()
    }
}

function Add-RecentDeck($Config, [string]$Url, [string]$Name) {
    Ensure-RecentDecksProperty $Config

    $existingCockatriceFile = $null
    foreach ($item in @($Config.RecentDecks)) {
        if ($null -ne $item -and [string]$item.Url -eq $Url) {
            if ($item.PSObject.Properties['CockatriceFile']) {
                $existingCockatriceFile = [string]$item.CockatriceFile
            }
            break
        }
    }

    $sourceName = (Get-DeckSourceInfo $Url).Source
    $list = @()

    $list += [pscustomobject]@{
        Url = $Url
        Name = $Name
        Source = $sourceName
        CockatriceFile = $existingCockatriceFile
        LastUsed = (Get-Date).ToString('s')
    }

    foreach ($item in @($Config.RecentDecks)) {
        if ($null -eq $item) { continue }

        $itemUrl = [string]$item.Url
        if ([string]::IsNullOrWhiteSpace($itemUrl)) { continue }
        if ($itemUrl -eq $Url) { continue }

        $mappedFile = $null
        if ($item.PSObject.Properties['CockatriceFile']) {
            $mappedFile = [string]$item.CockatriceFile
        }

        $oldSource = $null
        if ($item.PSObject.Properties['Source']) {
            $oldSource = [string]$item.Source
        }
        if ([string]::IsNullOrWhiteSpace($oldSource)) {
            try { $oldSource = (Get-DeckSourceInfo $itemUrl).Source }
            catch { $oldSource = 'UNKNOWN' }
        }

        $list += [pscustomobject]@{
            Url = $itemUrl
            Name = [string]$item.Name
            Source = $oldSource
            CockatriceFile = $mappedFile
            LastUsed = [string]$item.LastUsed
        }

        if ($list.Count -ge 20) { break }
    }

    $Config.RecentDecks = @($list | Select-Object -First 20)

    # IMPORTANT:
    # Older/newer configs may not contain DeckUrl at all.
    # Add the property if needed instead of assigning to a missing property.
    if ($Config.PSObject.Properties['DeckUrl']) {
        $Config.DeckUrl = $Url
    } else {
        Add-Member -InputObject $Config -MemberType NoteProperty -Name DeckUrl -Value $Url
    }

    Save-Config $Config
}

function Add-NewRecentDeckInteractively($Config) {
    Write-Host
    Write-Host 'ADD / REMEMBER A DECK'
    Write-Host 'Examples:'
    Write-Host '  Archidekt: https://archidekt.com/decks/12345678/example-deck'
    Write-Host '  Moxfield : https://www.moxfield.com/decks/ExampleDeckID'
    Write-Host

    $url = Read-Host 'Paste deck URL'
    $info = Get-DeckSourceInfo $url

    Write-Host
    Write-Host "Detected: $($info.Source)" -ForegroundColor Cyan
    Write-Host 'Checking deck...'

    $online = Get-OnlineDeck $url
    $name = [string](Get-PropertyValue $online.Data @('name'))
    if ([string]::IsNullOrWhiteSpace($name)) { $name = 'Online Deck' }

    # Validate that usable cards exist BEFORE remembering it.
    [void](Build-UniversalRemoteList $online $false $Config)

    Add-RecentDeck $Config $url.Trim() $name

    Write-Host
    Write-Host "Remembered: [$($info.Source)] $name" -ForegroundColor Green
    Write-Host 'Example next step: choose [1] to browse to and link your existing .cod file.' -ForegroundColor Cyan
    Write-Host 'Returning to the menu...' -ForegroundColor Cyan
    Start-Sleep -Milliseconds 1100

    return [pscustomobject]@{
        Url = $url.Trim()
        Name = $name
        Source = $info.Source
    }
}

function Get-CodDeckName([string]$Path) {
    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) {
        return [IO.Path]::GetFileNameWithoutExtension($Path)
    }
    try {
        [xml]$x = Get-Content -LiteralPath $Path -Raw
        $n = [string]$x.cockatrice_deck.deckname
        if (-not [string]::IsNullOrWhiteSpace($n)) { return $n }
    } catch {}
    return [IO.Path]::GetFileNameWithoutExtension($Path)
}

function Set-RecentDeckCockatriceFile($Config, [string]$Url, [string]$Path) {
    Ensure-RecentDecksProperty $Config
    $newList = @()

    foreach ($item in @($Config.RecentDecks)) {
        if ($null -eq $item) { continue }

        $mapped = $null
        if ($item.PSObject.Properties['CockatriceFile']) {
            $mapped = [string]$item.CockatriceFile
        }

        if ([string]$item.Url -eq $Url) {
            $mapped = $Path
        }

        $srcName = $null
        if ($item.PSObject.Properties['Source']) { $srcName = [string]$item.Source }
        if ([string]::IsNullOrWhiteSpace($srcName)) {
            try { $srcName = (Get-DeckSourceInfo ([string]$item.Url)).Source } catch { $srcName = 'UNKNOWN' }
        }

        $newList += [pscustomobject]@{
            Url = [string]$item.Url
            Name = [string]$item.Name
            Source = $srcName
            CockatriceFile = $mapped
            LastUsed = [string]$item.LastUsed
        }
    }

    $Config.RecentDecks = @($newList)
    Save-Config $Config
}



function Get-SourceUrlFromCod([string]$Path) {
    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) { return $null }
    try {
        [xml]$x = Get-Content -LiteralPath $Path -Raw
        $comments = [string]$x.cockatrice_deck.comments
        if ($comments -match '(https?://(?:www\.)?archidekt\.com/decks/[^\s<]+)') {
            return $Matches[1]
        }
        if ($comments -match '(https?://(?:www\.)?moxfield\.com/decks/[^\s<]+)') {
            return $Matches[1]
        }
    } catch {}
    return $null
}

function Set-CurrentLinkedSave($Config, [string]$Url, [string]$Path) {
    if (-not $Config.PSObject.Properties['CurrentLinkedUrl']) {
        Add-Member -InputObject $Config -MemberType NoteProperty -Name CurrentLinkedUrl -Value $Url
    } else {
        $Config.CurrentLinkedUrl = $Url
    }

    if (-not $Config.PSObject.Properties['CurrentLinkedFile']) {
        Add-Member -InputObject $Config -MemberType NoteProperty -Name CurrentLinkedFile -Value $Path
    } else {
        $Config.CurrentLinkedFile = $Path
    }

    Save-Config $Config
}

function Get-CurrentLinkedDisplay($Config) {
    $url = [string]$Config.CurrentLinkedUrl
    $file = [string]$Config.CurrentLinkedFile

    if ([string]::IsNullOrWhiteSpace($url) -or [string]::IsNullOrWhiteSpace($file)) {
        return '[None]'
    }

    $name = $null
    foreach ($d in @($Config.RecentDecks)) {
        if ([string]$d.Url -eq $url) {
            $name = [string]$d.Name
            break
        }
    }
    if ([string]::IsNullOrWhiteSpace($name)) {
        try { $name = (Get-DeckSourceInfo $url).Source } catch { $name = 'Online deck' }
    }

    return ("{0} -> {1}" -f $name, [IO.Path]::GetFileName($file))
}

function Find-RememberedDeckByUrl($Config, [string]$Url) {
    foreach ($d in @($Config.RecentDecks)) {
        if ([string]$d.Url -eq $Url) { return $d }
    }
    return $null
}

function Select-RememberedDeckSimple($Config, [string]$Title = 'SELECT ONLINE DECK') {
    while ($true) {
        Write-Header
        Write-Host $Title
        Write-Host
        Write-Host 'Choose the online source for this Cockatrice save.'
        Write-Host

        $recent = @($Config.RecentDecks)

        if ($recent.Count -gt 0) {
            for ($i=0; $i -lt $recent.Count; $i++) {
                $src = $null
                if ($recent[$i].PSObject.Properties['Source']) { $src = [string]$recent[$i].Source }
                if ([string]::IsNullOrWhiteSpace($src)) {
                    try { $src = (Get-DeckSourceInfo ([string]$recent[$i].Url)).Source } catch { $src = 'UNKNOWN' }
                }
                Write-Host ("  [{0,2}] [{1}] {2}" -f ($i+1), $src, [string]$recent[$i].Name)
            }
            Write-Host
        }

        Write-Host '[P] Paste NEW Archidekt / Moxfield URL'
        Write-Host '[Q] Cancel'
        Write-Host
        Write-Host 'Examples:'
        Write-Host '  Archidekt: https://archidekt.com/decks/12345678/example-deck'
        Write-Host '  Moxfield : https://www.moxfield.com/decks/ExampleDeckID'
        Write-Host

        $c = (Read-Host 'Select number, P, or Q').Trim()

        if ($c -match '^[Qq]$') { return $null }

        if ($c -match '^[Pp]$') {
            $url = (Read-Host 'Paste Archidekt OR Moxfield deck URL').Trim()

            try {
                $info = Get-DeckSourceInfo $url
                Write-Host
                Write-Host ("Detected: {0}" -f $info.Source) -ForegroundColor Cyan
                Write-Host 'Checking deck...'

                $online = Get-OnlineDeck $url
                $name = [string](Get-PropertyValue $online.Data @('name'))
                if ([string]::IsNullOrWhiteSpace($name)) { $name = 'Online Deck' }

                [void](Build-UniversalRemoteList $online $false $Config)
                Add-RecentDeck $Config $url $name

                foreach ($d in @($Config.RecentDecks)) {
                    if ([string]$d.Url -eq $url) { return $d }
                }

                return [pscustomobject]@{ Url=$url; Name=$name; Source=$info.Source }
            } catch {
                Write-Host
                Write-Host 'Could not add that deck URL:' -ForegroundColor Red
                Write-Host $_.Exception.Message -ForegroundColor Red
                Write-Host
                Read-Host 'Press Enter to try again' | Out-Null
            }
            continue
        }

        $num = 0
        if ([int]::TryParse($c, [ref]$num)) {
            if ($num -ge 1 -and $num -le $recent.Count) {
                return $recent[$num-1]
            }
        }

        Write-Host 'Invalid choice.' -ForegroundColor Yellow
        Start-Sleep -Milliseconds 600
    }
}

function Link-CodAsCurrent($Config) {
    # Requirement: open the browser immediately, not another deck menu first.
    try {
        Add-Type -AssemblyName System.Windows.Forms
        $dlg = New-Object System.Windows.Forms.OpenFileDialog
        $dlg.Title = 'Select the Cockatrice .cod file to LINK / load as current'
        $dlg.Filter = 'Cockatrice Deck (*.cod)|*.cod|All Files (*.*)|*.*'
        $dlg.CheckFileExists = $true
        $dlg.Multiselect = $false

        if ($Config.CockatriceDeckFolder -and
            (Test-Path -LiteralPath ([string]$Config.CockatriceDeckFolder) -PathType Container)) {
            $dlg.InitialDirectory = [string]$Config.CockatriceDeckFolder
        }

        if ($dlg.ShowDialog() -ne [System.Windows.Forms.DialogResult]::OK) {
            return $false
        }

        $selected = $dlg.FileName
    } catch {
        Write-Host
        Write-Host 'Windows file browser could not open.' -ForegroundColor Yellow
        Write-Host 'Paste the full .cod path instead.'
        Write-Host 'Example:'
        Write-Host '  C:\Users\Alex\AppData\Local\Cockatrice\Cockatrice\decks\Slimertest.cod'
        Write-Host
        $selected = (Read-Host 'Full .cod path').Trim().Trim('"')
        if (-not (Test-Path -LiteralPath $selected -PathType Leaf)) {
            Write-Host 'File not found.' -ForegroundColor Red
            return $false
        }
    }

    Write-Host
    Write-Host 'Selected Cockatrice save:' -ForegroundColor Cyan
    Write-Host "  $selected"

    # If this file was created by the updater, its comments may already identify the source.
    $sourceUrl = Get-SourceUrlFromCod $selected
    $deckItem = $null

    if ($sourceUrl) {
        Write-Host
        Write-Host 'Source URL found inside the .cod:' -ForegroundColor Green
        Write-Host "  $sourceUrl"

        try {
            $online = Get-OnlineDeck $sourceUrl
            $name = [string](Get-PropertyValue $online.Data @('name'))
            if ([string]::IsNullOrWhiteSpace($name)) { $name = 'Online Deck' }
            Add-RecentDeck $Config $sourceUrl $name
            $deckItem = Find-RememberedDeckByUrl $Config $sourceUrl
        } catch {
            Write-Host 'The saved source URL could not be verified.' -ForegroundColor Yellow
        }
    }

    if ($null -eq $deckItem) {
        Write-Host
        Write-Host 'This .cod does not have a saved online source yet.' -ForegroundColor Yellow
        Write-Host 'Choose an existing source below, or press [P] to paste a NEW Archidekt / Moxfield URL.'
        Start-Sleep -Milliseconds 900

        $deckItem = Select-RememberedDeckSimple $Config 'LINK THIS .COD TO AN ONLINE DECK'
        if ($null -eq $deckItem) {
            Write-Host
            Write-Host 'Link cancelled. Nothing changed.' -ForegroundColor Cyan
            return $false
        }
        $sourceUrl = [string]$deckItem.Url
    }

    # Save permanent mapping and current selection.
    Set-RecentDeckCockatriceFile $Config $sourceUrl $selected
    Set-CurrentLinkedSave $Config $sourceUrl $selected

    Write-Host
    Write-Host 'LINKED AND LOADED AS CURRENT:' -ForegroundColor Green
    Write-Host ("  {0} -> {1}" -f [string]$deckItem.Name, [IO.Path]::GetFileName($selected))
    return $true
}

function Update-CurrentLinkedSave($Config) {
    $url = [string]$Config.CurrentLinkedUrl
    $file = [string]$Config.CurrentLinkedFile

    if ([string]::IsNullOrWhiteSpace($url) -or [string]::IsNullOrWhiteSpace($file)) {
        Write-Host
        Write-Host 'CURRENT LINKED SAVE: [None]' -ForegroundColor Yellow
        Write-Host 'Use [1] Select (Link) / Change .cod file first.'
        return
    }

    if (-not (Test-Path -LiteralPath $file -PathType Leaf)) {
        Write-Host
        Write-Host 'The current linked .cod file is missing:' -ForegroundColor Yellow
        Write-Host "  $file"
        Write-Host 'Use [1] to select it again.'
        return
    }

    $name = ''
    foreach ($d in @($Config.RecentDecks)) {
        if ([string]$d.Url -eq $url) { $name = [string]$d.Name; break }
    }

    [void](Sync-OneDeck $Config $url $name $false)
}


function Get-LinkedSaveList($Config) {
    $linked = @()

    foreach ($d in @($Config.RecentDecks)) {
        if ($null -eq $d) { continue }

        $url = [string]$d.Url
        if ([string]::IsNullOrWhiteSpace($url)) { continue }

        $p = Get-LinkedCockatriceFile $Config $url
        if ([string]::IsNullOrWhiteSpace($p)) { continue }

        $src = $null
        if ($d.PSObject.Properties['Source']) {
            $src = [string]$d.Source
        }
        if ([string]::IsNullOrWhiteSpace($src)) {
            try { $src = (Get-DeckSourceInfo $url).Source } catch { $src = 'UNKNOWN' }
        }

        $linked += [pscustomobject]@{
            Url = $url
            Name = [string]$d.Name
            Source = $src
            File = $p
            FileName = [IO.Path]::GetFileName($p)
        }

        if ($linked.Count -ge 999) { break }
    }

    return @($linked)
}

function Update-SelectedLinkedSave($Config) {
    $linked = @(Get-LinkedSaveList $Config)

    if ($linked.Count -eq 0) {
        Write-Header
        Write-Host 'UPDATE SELECTED LINKED .COD'
        Write-Host
        Write-Host 'No linked .cod files yet.' -ForegroundColor Yellow
        Write-Host
        Write-Host 'Use [1] Select (Link) / Change .cod file first.'
        return
    }

    while ($true) {
        Write-Header
        Write-Host 'UPDATE SELECTED LINKED .COD'
        Write-Host
        Write-Host 'Select which linked Cockatrice save to update:'
        Write-Host

        for ($i = 0; $i -lt $linked.Count; $i++) {
            Write-Host ("  [{0,3}] [{1}] {2} -> {3}" -f ($i + 1), $linked[$i].Source, $linked[$i].Name, $linked[$i].FileName)
        }

        Write-Host
        Write-Host '[Q] Back'
        Write-Host

        $choice = (Read-Host 'Select 1-999 or Q').Trim()

        if ($choice -match '^[Qq]$') { return }

        $n = 0
        if ([int]::TryParse($choice, [ref]$n)) {
            if ($n -ge 1 -and $n -le $linked.Count -and $n -le 999) {
                $item = $linked[$n - 1]

                if (-not (Test-Path -LiteralPath $item.File -PathType Leaf)) {
                    Write-Host
                    Write-Host 'Linked .cod file is missing:' -ForegroundColor Yellow
                    Write-Host "  $($item.File)"
                    Write-Host
                    Read-Host 'Press Enter to return' | Out-Null
                    return
                }

                Set-CurrentLinkedSave $Config $item.Url $item.File

                Write-Host
                Write-Host ("Updating: {0}" -f $item.FileName) -ForegroundColor Cyan
                [void](Sync-OneDeck $Config $item.Url $item.Name $false)
                return
            }
        }

        Write-Host
        Write-Host 'Invalid selection.' -ForegroundColor Yellow
        Start-Sleep -Milliseconds 700
    }
}

function Save-NewDeckDirect($Config) {
    Write-Header
    Write-Host 'CREATE NEW LINKED COCKATRICE DECK'
    Write-Host
    Write-Host 'Step 1 - Name the new Cockatrice deck.'
    Write-Host 'Example: My New Commander Deck'
    Write-Host

    while ($true) {
        $newName = (Read-Host 'New Cockatrice deck name').Trim()
        if (-not [string]::IsNullOrWhiteSpace($newName)) { break }
        Write-Host 'Please enter a name.' -ForegroundColor Yellow
    }

    Write-Host
    Write-Host 'Step 2 - Paste the NEW online deck URL.'
    Write-Host
    Write-Host 'Examples:'
    Write-Host '  Archidekt: https://archidekt.com/decks/12345678/example-deck'
    Write-Host '  Moxfield : https://www.moxfield.com/decks/ExampleDeckID'
    Write-Host

    $url = (Read-Host 'Paste Archidekt OR Moxfield deck URL').Trim()

    $info = Get-DeckSourceInfo $url
    Write-Host
    Write-Host ("Detected: {0}" -f $info.Source) -ForegroundColor Cyan
    Write-Host 'Checking deck...'

    $online = Get-OnlineDeck $url
    $onlineName = [string](Get-PropertyValue $online.Data @('name'))
    if ([string]::IsNullOrWhiteSpace($onlineName)) { $onlineName = 'Online Deck' }

    $remote = Build-UniversalRemoteList $online ([bool]$Config.IncludeMaybeboard) $Config

    $safe = Safe-FileName $newName
    $output = Join-Path ([string]$Config.CockatriceDeckFolder) ($safe + '.cod')

    if (-not (Confirm-Overwrite $output)) {
        Write-Host
        Write-Host 'Cancelled. No files changed.' -ForegroundColor Cyan
        return
    }

    $backup = $null
    if (Test-Path -LiteralPath $output) {
        $backup = Backup-Deck $output
    }

    Write-Cod $output $newName $url $remote

    Add-RecentDeck $Config $url $onlineName
    Set-RecentDeckCockatriceFile $Config $url $output
    Set-CurrentLinkedSave $Config $url $output

    Write-Host
    if ($backup) { Write-Host "Backup : $backup" }
    Write-Host "CREATED: $output" -ForegroundColor Green
    Write-Host
    Write-Host 'AUTO-LINKED AND LOADED AS CURRENT:' -ForegroundColor Green
    Write-Host ("  [{0}] {1} -> {2}" -f $info.Source, $onlineName, [IO.Path]::GetFileName($output))
}

function Update-AllLinkedSaves($Config) {
    $linked = @(Get-LinkedSaveList $Config)

    Write-Header
    Write-Host 'UPDATE ALL LINKED .COD FILES'
    Write-Host

    if ($linked.Count -eq 0) {
        Write-Host 'No linked .cod files yet.' -ForegroundColor Yellow
        Write-Host
        Write-Host 'Use [1] Select (Link) / Change .cod file first.'
        return
    }

    Write-Host 'Linked Cockatrice saves:'
    Write-Host

    for ($i = 0; $i -lt $linked.Count; $i++) {
        Write-Host ("  [{0,3}] [{1}] {2} -> {3}" -f ($i + 1), $linked[$i].Source, $linked[$i].Name, $linked[$i].FileName)
    }

    Write-Host
    $go = (Read-Host 'Update ALL linked .cod files above? [Y/n]').Trim()
    if (-not [string]::IsNullOrWhiteSpace($go) -and $go -notmatch '^[Yy]') {
        Write-Host
        Write-Host 'Cancelled.' -ForegroundColor Cyan
        return
    }

    $results = @()

    foreach ($item in $linked) {
        try {
            if (-not (Test-Path -LiteralPath $item.File -PathType Leaf)) {
                $results += [pscustomobject]@{
                    Deck = $item.Name
                    File = $item.FileName
                    Status = 'Missing .cod'
                }
                continue
            }

            Set-CurrentLinkedSave $Config $item.Url $item.File

            Write-Host
            Write-Host ("Updating: {0}" -f $item.FileName) -ForegroundColor Cyan

            $r = Sync-OneDeck $Config $item.Url $item.Name $false

            $results += [pscustomobject]@{
                Deck = $item.Name
                File = $item.FileName
                Status = [string]$r.Status
            }
        } catch {
            $results += [pscustomobject]@{
                Deck = $item.Name
                File = $item.FileName
                Status = 'FAILED'
            }
        }
    }

    Write-Host
    Write-Host '============================================================'
    Write-Host ' UPDATE ALL SUMMARY'
    Write-Host '============================================================'
    foreach ($r in $results) {
        Write-Host ("{0,-12} {1} -> {2}" -f $r.Status, $r.Deck, $r.File)
    }
}

function Select-CockatriceCodFile([string]$InitialFolder) {
    while ($true) {
        Write-Header
        Write-Host 'SELECT EXISTING COCKATRICE .COD FILE'
        Write-Host
        Write-Host 'Pick the EXACT Cockatrice save you want this online deck to update.'
        Write-Host
        Write-Host 'Example:'
        Write-Host '  Online deck : Example Deck'
        Write-Host '  Cockatrice  : MyDeck.cod'
        Write-Host

        $files = @()

        if ($InitialFolder -and (Test-Path -LiteralPath $InitialFolder -PathType Container)) {
            Write-Host "Cockatrice deck folder:"
            Write-Host "  $InitialFolder"
            Write-Host

            try {
                # Search the selected deck folder and its subfolders.
                $files = @(
                    Get-ChildItem -LiteralPath $InitialFolder -Filter '*.cod' -File -Recurse -ErrorAction SilentlyContinue |
                    Sort-Object Name, FullName
                )
            } catch {
                $files = @()
            }
        } else {
            Write-Host 'Saved Cockatrice deck folder is missing.' -ForegroundColor Yellow
            Write-Host
        }

        if ($files.Count -gt 0) {
            Write-Host "Found $($files.Count) Cockatrice deck file(s):"
            Write-Host

            for ($i = 0; $i -lt $files.Count; $i++) {
                $relative = $files[$i].FullName
                if ($InitialFolder -and $relative.StartsWith($InitialFolder, [System.StringComparison]::OrdinalIgnoreCase)) {
                    $relative = $relative.Substring($InitialFolder.Length).TrimStart('\')
                }

                Write-Host ("  [{0,2}] {1}" -f ($i + 1), $relative)
            }

            Write-Host
            Write-Host '  [B] Browse with Windows file picker'
            Write-Host '  [P] Paste full .cod path manually'
            Write-Host '  [Q] Cancel / go back'
            Write-Host

            $choice = (Read-Host 'Select .cod number, B, P, or Q').Trim()

            if ($choice -match '^[Qq]$') { return $null }

            if ($choice -match '^[Pp]$') {
                Write-Host
                Write-Host 'Example:'
                Write-Host '  C:\Users\Alex\AppData\Local\Cockatrice\Cockatrice\decks\Slimertest.cod'
                Write-Host
                $p = (Read-Host 'Full .cod path').Trim().Trim('"')

                if ((Test-Path -LiteralPath $p -PathType Leaf) -and
                    ([IO.Path]::GetExtension($p) -ieq '.cod')) {
                    return (Resolve-Path -LiteralPath $p).Path
                }

                Write-Host
                Write-Host 'That .cod file was not found.' -ForegroundColor Yellow
                Read-Host 'Press Enter to try again' | Out-Null
                continue
            }

            if ($choice -match '^[Bb]$') {
                # Windows file picker fallback below.
            } else {
                $n = 0
                if ([int]::TryParse($choice, [ref]$n)) {
                    if ($n -ge 1 -and $n -le $files.Count) {
                        return $files[$n - 1].FullName
                    }
                }

                Write-Host
                Write-Host 'Invalid choice.' -ForegroundColor Yellow
                Read-Host 'Press Enter to try again' | Out-Null
                continue
            }
        } else {
            Write-Host 'No .cod files were found automatically.' -ForegroundColor Yellow
            Write-Host
            Write-Host '  [B] Browse with Windows file picker'
            Write-Host '  [P] Paste full .cod path manually'
            Write-Host '  [Q] Cancel / go back'
            Write-Host

            $choice = (Read-Host 'Choice').Trim()
            if ($choice -match '^[Qq]$') { return $null }

            if ($choice -match '^[Pp]$') {
                Write-Host
                Write-Host 'Example:'
                Write-Host '  C:\Users\Alex\AppData\Local\Cockatrice\Cockatrice\decks\Slimertest.cod'
                Write-Host
                $p = (Read-Host 'Full .cod path').Trim().Trim('"')

                if ((Test-Path -LiteralPath $p -PathType Leaf) -and
                    ([IO.Path]::GetExtension($p) -ieq '.cod')) {
                    return (Resolve-Path -LiteralPath $p).Path
                }

                Write-Host
                Write-Host 'That .cod file was not found.' -ForegroundColor Yellow
                Read-Host 'Press Enter to try again' | Out-Null
                continue
            }

            if ($choice -notmatch '^[Bb]$') {
                Write-Host
                Write-Host 'Choose B, P, or Q.' -ForegroundColor Yellow
                Read-Host 'Press Enter to try again' | Out-Null
                continue
            }
        }

        # Windows file picker.
        try {
            Add-Type -AssemblyName System.Windows.Forms

            $dlg = New-Object System.Windows.Forms.OpenFileDialog
            $dlg.Title = 'Select the EXACT Cockatrice .cod file to link'
            $dlg.Filter = 'Cockatrice Deck (*.cod)|*.cod|All Files (*.*)|*.*'
            $dlg.CheckFileExists = $true
            $dlg.Multiselect = $false

            if ($InitialFolder -and (Test-Path -LiteralPath $InitialFolder -PathType Container)) {
                $dlg.InitialDirectory = $InitialFolder
            }

            $result = $dlg.ShowDialog()
            if ($result -eq [System.Windows.Forms.DialogResult]::OK) {
                return $dlg.FileName
            }

            return $null
        } catch {
            Write-Host
            Write-Host 'Windows file picker could not open.' -ForegroundColor Yellow
            Write-Host 'Use [P] on the next screen to paste the .cod path manually.'
            Write-Host
            Read-Host 'Press Enter to continue' | Out-Null
        }
    }
}

function Link-CockatriceFile($Config, $DeckItem) {
    $selected = Select-CockatriceCodFile ([string]$Config.CockatriceDeckFolder)
    if ([string]::IsNullOrWhiteSpace($selected)) {
        Write-Host 'No file selected.' -ForegroundColor Yellow
        return $null
    }

    Set-RecentDeckCockatriceFile $Config ([string]$DeckItem.Url) $selected
    Write-Host
    Write-Host 'Linked successfully:' -ForegroundColor Green
    Write-Host ("  {0} -> {1}" -f [string]$DeckItem.Name, [IO.Path]::GetFileName($selected))
    Start-Sleep -Milliseconds 800
    return $selected
}

function Get-LinkedCockatriceFile($Config, [string]$Url) {
    foreach ($item in @($Config.RecentDecks)) {
        if ($null -ne $item -and [string]$item.Url -eq $Url) {
            if ($item.PSObject.Properties['CockatriceFile']) {
                $p = [string]$item.CockatriceFile
                if (-not [string]::IsNullOrWhiteSpace($p)) { return $p }
            }
        }
    }
    return $null
}

function Choose-DeckAction($Config, $DeckItem) {
    while ($true) {
        $linked = Get-LinkedCockatriceFile $Config ([string]$DeckItem.Url)

        Write-Host
        $src = (Get-DeckSourceInfo ([string]$DeckItem.Url)).Source
        Write-Host ("Online deck : [{0}] {1}" -f $src, [string]$DeckItem.Name)
        if ($linked) {
            Write-Host ("Cockatrice: {0}" -f $linked) -ForegroundColor Green
        } else {
            Write-Host 'Cockatrice: NOT LINKED' -ForegroundColor Yellow
        }

        Write-Host
        Write-Host '  [1] Update linked Cockatrice save'
        Write-Host '  [2] Select / change existing .cod file'
        Write-Host '  [3] Save as a NEW deck'
        Write-Host '  [Q] Back'
        Write-Host
        Write-Host 'Example:'
        Write-Host '  Online deck "slime" can be linked to your own file "Slimertest.cod".'
        Write-Host

        $choice = (Read-Host 'Choice').Trim().ToUpperInvariant()

        switch ($choice) {
            '1' {
                if (-not $linked) {
                    Write-Host
                    Write-Host 'This Archidekt deck is not linked to a Cockatrice file yet.' -ForegroundColor Yellow
                    $newLink = Link-CockatriceFile $Config $DeckItem
                    if (-not $newLink) { continue }
                    $linked = $newLink
                }
                return [pscustomobject]@{
                    Mode = 'Linked'
                    Path = $linked
                    DeckName = (Get-CodDeckName $linked)
                }
            }
            '2' {
                [void](Link-CockatriceFile $Config $DeckItem)
                continue
            }
            '3' {
                while ($true) {
                    Write-Host
                    $newName = (Read-Host 'New Cockatrice deck name').Trim()
                    if (-not [string]::IsNullOrWhiteSpace($newName)) {
                        $safe = Safe-FileName $newName
                        $path = Join-Path ([string]$Config.CockatriceDeckFolder) ($safe + '.cod')
                        return [pscustomobject]@{
                            Mode = 'SaveAs'
                            Path = $path
                            DeckName = $newName
                        }
                    }
                    Write-Host 'Please enter a deck name.' -ForegroundColor Yellow
                }
            }
            'Q' {
                return [pscustomobject]@{ Mode='Back'; Path=$null; DeckName=$null }
            }
            default {
                Write-Host 'Choose 1, 2, 3, or Q.' -ForegroundColor Yellow
            }
        }
    }
}


function Select-RememberedDeck($Config, [string]$PromptText = 'Select deck') {
    Ensure-RecentDecksProperty $Config

    while ($true) {
        Write-Header
        Write-Host 'REMEMBERED ARCHIDEKT DECKS'
        Write-Host

        $recent = @($Config.RecentDecks)
        if ($recent.Count -eq 0) {
            Write-Host 'No remembered decks yet.' -ForegroundColor Yellow
            Write-Host
            Write-Host '[N] Add / remember another deck'
            Write-Host '[Q] Back'
            Write-Host
            $choice = (Read-Host 'Choice').Trim()
            if ($choice -match '^[Nn]$') {
                [void](Add-NewRecentDeckInteractively $Config)
                continue
            }
            if ($choice -match '^[Qq]$') { return $null }
            continue
        }

        for ($i=0; $i -lt $recent.Count; $i++) {
            $name = [string]$recent[$i].Name
            if ([string]::IsNullOrWhiteSpace($name)) { $name = '(Unnamed deck)' }

            $mapped = $null
            if ($recent[$i].PSObject.Properties['CockatriceFile']) {
                $mapped = [string]$recent[$i].CockatriceFile
            }

            $srcName = $null
            if ($recent[$i].PSObject.Properties['Source']) { $srcName = [string]$recent[$i].Source }
            if ([string]::IsNullOrWhiteSpace($srcName)) {
                try { $srcName = (Get-DeckSourceInfo ([string]$recent[$i].Url)).Source } catch { $srcName = 'UNKNOWN' }
            }

            if (-not [string]::IsNullOrWhiteSpace($mapped)) {
                Write-Host ("  [{0,2}] [{1}] {2}  ->  {3}" -f ($i+1), $srcName, $name, [IO.Path]::GetFileName($mapped))
            } else {
                Write-Host ("  [{0,2}] [{1}] {2}  ->  [not linked]" -f ($i+1), $srcName, $name) -ForegroundColor Yellow
            }
        }

        Write-Host
        Write-Host '  [N] Add / remember another deck'
        Write-Host '  [Q] Back'
        Write-Host

        $choice = (Read-Host $PromptText).Trim()
        if ($choice -match '^[Nn]$') {
            [void](Add-NewRecentDeckInteractively $Config)
            continue
        }
        if ($choice -match '^[Qq]$') { return $null }

        $n = 0
        if ([int]::TryParse($choice, [ref]$n)) {
            if ($n -ge 1 -and $n -le $recent.Count) {
                return $recent[$n-1]
            }
        }

        Write-Host 'Invalid choice.' -ForegroundColor Yellow
        Start-Sleep -Milliseconds 700
    }
}


function Change-CockatriceDeckFolder($Config) {
    $newFolder = Select-SmartCockatriceDeckFolder $Config ([string]$Config.CockatriceDeckFolder) $true $false

    if ([string]::IsNullOrWhiteSpace($newFolder)) {
        return
    }

    $Config.CockatriceDeckFolder = $newFolder
    Save-Config $Config

    Write-Host
    Write-Host 'CURRENT DECK FOLDER:' -ForegroundColor Green
    Write-Host "  $newFolder"
}

function Show-MainActionMenu($Config) {
    while ($true) {
        Write-Header

        $current = Get-CurrentLinkedDisplay $Config
        $linkedPreview = @(Get-LinkedSaveList $Config)

        Write-Host ("CURRENT LINKED SAVE: {0}" -f $current) -ForegroundColor Cyan
        Write-Host ("DECK FOLDER        : {0}" -f [string]$Config.CockatriceDeckFolder) -ForegroundColor DarkCyan
        Write-Host

        Write-Host '[1] Existing .cod -> Link / Change Source'
        Write-Host '[2] Update CURRENT linked save'
        Write-Host '[3] Update another linked .cod'
        Write-Host '[4] Create NEW linked Cockatrice deck'
        Write-Host '[5] Change Cockatrice deck folder'
        Write-Host '[A] Update ALL linked .cod files'

        if ($linkedPreview.Count -eq 0) {
            Write-Host '      [No linked .cod files]' -ForegroundColor Yellow
        } else {
            for ($i = 0; $i -lt $linkedPreview.Count; $i++) {
                Write-Host ("      {0}. {1}" -f ($i + 1), $linkedPreview[$i].FileName)
            }
        }

        Write-Host '[Q] Quit'
        Write-Host
        Write-Host 'HOW TO USE:'
        Write-Host '  1 = pick an EXISTING .cod, then choose/paste its online source'
        Write-Host '  2 = update the CURRENT linked save'
        Write-Host '  3 = choose another linked .cod and update it'
        Write-Host '  4 = name a NEW .cod, paste a NEW deck URL, create + auto-link it'
        Write-Host '  5 = choose a different folder for future .cod files'
        Write-Host '  A = update every linked .cod shown above'
        Write-Host

        $choice = (Read-Host 'Choice').Trim().ToUpperInvariant()
        if ($choice -in @('1','2','3','4','5','A','Q')) { return $choice }

        Write-Host 'Choose 1, 2, 3, 4, 5, A, or Q.' -ForegroundColor Yellow
        Start-Sleep -Milliseconds 600
    }
}

function Get-RecentDeckMenu($Config) {
    Ensure-RecentDecksProperty $Config

    # Ensure the saved/default URL appears in the recent list.
    if ($Config.DeckUrl) {
        $exists = $false
        foreach ($d in @($Config.RecentDecks)) {
            if ([string]$d.Url -eq [string]$Config.DeckUrl) { $exists = $true; break }
        }
        if (-not $exists) {
            try {
                $deck = Get-ArchidektDeck ([string]$Config.DeckUrl)
                $name = [string](Get-PropertyValue $deck @('name'))
                if ([string]::IsNullOrWhiteSpace($name)) { $name = 'Archidekt Deck' }
                Add-RecentDeck $Config ([string]$Config.DeckUrl) $name
            } catch {
                # Keep menu usable even if the old/default URL is temporarily unavailable.
            }
        }
    }

    while ($true) {
        Write-Header
        Write-Host 'REMEMBERED ARCHIDEKT DECKS'
        Write-Host

        $recent = @($Config.RecentDecks)
        if ($recent.Count -eq 0) {
            Write-Host 'No remembered decks yet.'
        } else {
            for ($i=0; $i -lt $recent.Count; $i++) {
                $name = [string]$recent[$i].Name
                if ([string]::IsNullOrWhiteSpace($name)) { $name = '(Unnamed deck)' }

                $mapped = $null
                if ($recent[$i].PSObject.Properties['CockatriceFile']) {
                    $mapped = [string]$recent[$i].CockatriceFile
                }

                if (-not [string]::IsNullOrWhiteSpace($mapped)) {
                    Write-Host ("  [{0,2}] {1}  ->  {2}" -f ($i+1), $name, [IO.Path]::GetFileName($mapped))
                } else {
                    Write-Host ("  [{0,2}] {1}  ->  [not linked]" -f ($i+1), $name) -ForegroundColor Yellow
                }
            }
        }

        Write-Host
        Write-Host '  [A] Update ALL remembered decks'
        Write-Host '  [N] Add / remember another deck'
        Write-Host '  [Q] Quit'
        Write-Host

        $choice = (Read-Host 'Select deck number, A, N, or Q').Trim()

        if ($choice -match '^[Qq]$') {
            return [pscustomobject]@{ Mode='Quit'; Decks=@() }
        }
        if ($choice -match '^[Nn]$') {
            [void](Add-NewRecentDeckInteractively $Config)
            continue
        }
        if ($choice -match '^[Aa]$') {
            $recent = @($Config.RecentDecks)
            if ($recent.Count -eq 0) {
                Write-Host 'There are no remembered decks to update.' -ForegroundColor Yellow
                Start-Sleep -Seconds 1
                continue
            }
            return [pscustomobject]@{ Mode='All'; Decks=$recent }
        }

        $n = 0
        if ([int]::TryParse($choice, [ref]$n)) {
            if ($n -ge 1 -and $n -le $recent.Count) {
                return [pscustomobject]@{ Mode='One'; Decks=@($recent[$n-1]) }
            }
        }

        Write-Host 'Invalid choice.' -ForegroundColor Yellow
        Start-Sleep -Milliseconds 800
    }
}

function Sync-OneDeck($Config, [string]$DeckUrl, [string]$RememberedName, [bool]$Interactive) {
    Write-Host
    Write-Host '------------------------------------------------------------'
    Write-Host "Archidekt : $DeckUrl"
    Write-Host "Cockatrice: $($Config.CockatriceDeckFolder)"
    Write-Host '------------------------------------------------------------'

    $online = Get-OnlineDeck $DeckUrl
    $deck = $online.Data
    $deckName = [string](Get-PropertyValue $deck @('name'))
    if ([string]::IsNullOrWhiteSpace($deckName)) {
        if ($RememberedName) { $deckName = $RememberedName } else { $deckName = 'Archidekt Deck' }
    }

    Add-RecentDeck $Config $DeckUrl $deckName
    $remote = Build-UniversalRemoteList $online ([bool]$Config.IncludeMaybeboard) $Config

    $deckItem = $null
    foreach ($d in @($Config.RecentDecks)) {
        if ([string]$d.Url -eq $DeckUrl) { $deckItem = $d; break }
    }
    if ($null -eq $deckItem) {
        $deckItem = [pscustomobject]@{ Url=$DeckUrl; Name=$deckName; CockatriceFile=$null }
    }

    $action = $null

    if ($Interactive) {
        $action = Choose-DeckAction $Config $deckItem
        if ($action.Mode -eq 'Back') {
            return [pscustomobject]@{ Deck=$deckName; Status='Skipped'; Changed=$false }
        }
    } else {
        $linked = Get-LinkedCockatriceFile $Config $DeckUrl
        if ([string]::IsNullOrWhiteSpace($linked)) {
            Write-Host "SKIPPED: $deckName is not linked to a Cockatrice .cod file." -ForegroundColor Yellow
            return [pscustomobject]@{ Deck=$deckName; Status='Not linked'; Changed=$false }
        }

        if (-not (Test-Path -LiteralPath $linked -PathType Leaf)) {
            Write-Host "SKIPPED: linked .cod no longer exists: $linked" -ForegroundColor Yellow
            return [pscustomobject]@{ Deck=$deckName; Status='Missing .cod'; Changed=$false }
        }

        $action = [pscustomobject]@{
            Mode = 'Linked'
            Path = $linked
            DeckName = (Get-CodDeckName $linked)
        }
    }

    $output = [string]$action.Path
    $outputDeckName = [string]$action.DeckName

    if ($action.Mode -eq 'SaveAs' -and -not (Confirm-Overwrite $output)) {
        Write-Host 'Save As cancelled. No files changed.' -ForegroundColor Cyan
        return [pscustomobject]@{ Deck=$deckName; Status='Skipped'; Changed=$false }
    }

    Write-Host
    Write-Host "Archidekt deck : $deckName"
    Write-Host "Cockatrice file: $output"
    Write-Host "Cockatrice name: $outputDeckName"
    Write-Host "Cards          : $($remote.Total)"
    Write-Host
    Write-Host 'Changes:'

    $old = Get-ExistingCodCounts $output
    $changeCount = Show-Diff $old $remote

    if ($changeCount -eq 0 -and (Test-Path -LiteralPath $output) -and $action.Mode -eq 'Linked') {
        Write-Host
        Write-Host 'NO CHANGE' -ForegroundColor Cyan
        return [pscustomobject]@{ Deck=$deckName; Status='No change'; Changed=$false }
    }

    $backup = $null
    if (Test-Path -LiteralPath $output) {
        $backup = Backup-Deck $output
    }

    Write-Cod $output $outputDeckName $DeckUrl $remote

    if ($backup) { Write-Host "Backup     : $backup" }

    if ($action.Mode -eq 'SaveAs') {
        Write-Host "SAVED NEW  : $output" -ForegroundColor Green
    } else {
        Write-Host "UPDATED    : $output" -ForegroundColor Green
    }

    return [pscustomobject]@{ Deck=$deckName; Status='Updated'; Changed=$true }
}

function Main {
    Write-Header
    $config = Load-Config
    Ensure-RecentDecksProperty $config

    # Migrate current selection from an older one-link config where possible.
    if ([string]::IsNullOrWhiteSpace([string]$config.CurrentLinkedUrl) -or
        [string]::IsNullOrWhiteSpace([string]$config.CurrentLinkedFile)) {

        foreach ($d in @($config.RecentDecks)) {
            $p = Get-LinkedCockatriceFile $config ([string]$d.Url)
            if (-not [string]::IsNullOrWhiteSpace($p)) {
                Set-CurrentLinkedSave $config ([string]$d.Url) $p
                break
            }
        }
    }

    while ($true) {
        $action = Show-MainActionMenu $config

        switch ($action) {
            '1' {
                [void](Link-CodAsCurrent $config)
                Write-Host
                Read-Host 'Press Enter to return to the main menu' | Out-Null
                continue
            }

            '2' {
                Write-Header
                Write-Host ("CURRENT LINKED SAVE: {0}" -f (Get-CurrentLinkedDisplay $config)) -ForegroundColor Cyan
                Update-CurrentLinkedSave $config
                Write-Host
                Read-Host 'Press Enter to return to the main menu' | Out-Null
                continue
            }

            '3' {
                Update-SelectedLinkedSave $config
                Write-Host
                Read-Host 'Press Enter to return to the main menu' | Out-Null
                continue
            }

            '4' {
                Save-NewDeckDirect $config
                Write-Host
                Read-Host 'Press Enter to return to the main menu' | Out-Null
                continue
            }

            '5' {
                Change-CockatriceDeckFolder $config
                Write-Host
                Read-Host 'Press Enter to return to the main menu' | Out-Null
                continue
            }

            'A' {
                Update-AllLinkedSaves $config
                Write-Host
                Read-Host 'Press Enter to return to the main menu' | Out-Null
                continue
            }

            'Q' {
                Write-Host
                Write-Host 'Goodbye.'
                return
            }
        }
    }
}

try {
    Main
    exit 0
} catch {
    Write-Host
    Write-Host '============================================================' -ForegroundColor Red
    Write-Host ' UPDATE FAILED - your existing .cod was not intentionally replaced.' -ForegroundColor Red
    Write-Host '============================================================' -ForegroundColor Red
    Write-Host
    Write-Host $_.Exception.Message -ForegroundColor Red
    exit 1
}
