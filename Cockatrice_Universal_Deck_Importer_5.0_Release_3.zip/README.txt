Cockatrice Universal Deck Importer 5.0 Release 3

STABILITY FIX
=============

Choose Card Art
---------------
- Fixed an error path when Choose Art was clicked without a selected row.
- A missing selection is now a normal informational warning, not an exception.
- Choose Art now accepts the DataGridView CurrentRow as a fallback when a
  current card/cell exists but SelectedRows is empty.
- An empty/new row also returns safely instead of creating an error log.
- Genuine art-selector exceptions are still logged for diagnosis.

Release 2 performance improvements are retained:
- cached sorted card-name list
- 1,000-row browser rendering cap
- debounced editor stats/search work
- reduced forced garbage collection
- Cockatrice_Importer_Performance.log diagnostics

PACKAGE
=======
Cockatrice_Universal_Deck_Importer_5.0_Release_3.ps1
Cockatrice_Universal_Deck_Importer_5.0_Release_3.vbs
README.txt

No BAT file.
