﻿
# Application folder resolver
# Works both as a normal .ps1 and when compiled with PS2EXE.
$Script:AppRoot = $null

try {
    if (-not [string]::IsNullOrWhiteSpace($PSScriptRoot)) {
        $Script:AppRoot = $PSScriptRoot
    }
}
catch {}

if ([string]::IsNullOrWhiteSpace($Script:AppRoot)) {
    try {
        $exePath = [System.Diagnostics.Process]::GetCurrentProcess().MainModule.FileName
        if (-not [string]::IsNullOrWhiteSpace($exePath)) {
            $Script:AppRoot = Split-Path -Parent $exePath
        }
    }
    catch {}
}

if ([string]::IsNullOrWhiteSpace($Script:AppRoot)) {
    try {
        $Script:AppRoot = (Get-Location).Path
    }
    catch {
        $Script:AppRoot = [Environment]::GetFolderPath('Desktop')
    }
}

#requires -Version 5.1
<#
===============================================================================
 COCKATRICE UNIVERSAL DECK IMPORTER 3.1.4
===============================================================================
Standalone Windows PowerShell GUI for importing public deck URLs or pasted
decklists into Cockatrice .cod files.

Release channel: 1.0 Release Beta

Supported direct public URL imports:
  - Archidekt: https://archidekt.com/decks/...
  - Moxfield:  https://moxfield.com/decks/...

For Deckstats, TappedOut, and other sites:
  - Use the site's Copy / Export decklist feature
  - Paste the exported text into this importer

Supported pasted/exported text includes:
  - One card per line:
      1 Sol Ring
      4 Snow-Covered Forest
  - x syntax:
      1x Sol Ring
  - Set/collector suffixes:
      1 Sol Ring (CMM) 396
      1 Sol Ring [CMM:396]
  - Section headings:
      Commander
      Mainboard
      Sideboard
      Maybeboard
  - Giant one-line lists:
      1 Sol Ring 1 Arcane Signet 1 Command Tower 4 Forest ...

Validation:
  - Uses the selected Cockatrice cards.xml as the authority.
  - Also recognizes card names from customsets XML files.
  - Shows unresolved names before saving.
  - Reopens the .cod after saving and verifies the saved quantities/card names.

The importer does not alter cards.xml, tokens.xml, or the AIO updater.
===============================================================================
#>

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
[System.Windows.Forms.Application]::EnableVisualStyles()

$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'

$ScriptFolder = $Script:AppRoot
$SettingsPath = Join-Path $ScriptFolder 'Cockatrice_Deck_Importer.settings.json'

$Script:CardIndex = $null
$Script:CardIndexRoot = $null
$Script:SortedCardNames = $null
$Script:BrowserResultLimit = 1000
$Script:PerfLogPath = Join-Path $ScriptFolder 'Cockatrice_Importer_Performance.log'
$Script:StatsRefreshTimer = $null

$Script:CardTypeIndex = New-Object 'System.Collections.Generic.Dictionary[string,byte]' ([System.StringComparer]::OrdinalIgnoreCase)
$Script:FlavorNameMap = New-Object 'System.Collections.Generic.Dictionary[string,string]' ([System.StringComparer]::OrdinalIgnoreCase)
$Script:FlavorNameAmbiguous = New-Object 'System.Collections.Generic.HashSet[string]' ([System.StringComparer]::OrdinalIgnoreCase)
$Script:FlavorNameCachePath = Join-Path $ScriptFolder 'Scryfall_FlavorName_Aliases.json'
$Script:Analysis = $null
$Script:HoverPreviewDelay = 150
$Script:HoverPreviewPendingName = ''
$Script:HoverPreviewPendingUUID = ''
$Script:HoverPreviewImageUrlCache = @{}
$Script:HoverPreviewLastKey = ''
$Script:HoverPreviewVisible = $false

$Script:LastSavedPath = $null
$Script:ImportedDeckName = $null
$Script:ImportedFormat = $null
$Script:ImportedCommanders = @()
$Script:SelectedCommanderNames = @()
$Script:CommanderMode = 'Regular Commander'
$Script:PrimaryCommander = ''
$Script:SecondaryCommander = ''
$Script:CompanionCard = ''
$Script:ColorIdentityCache = @{}
$Script:AllowOffColorCards = @{}
$Script:AutosavePath = Join-Path $Script:AppRoot 'Cockatrice_DeckImporter_Autosave.json'
$Script:LastAutosaveHash = ''
$Script:DeckFilterText = ''
$Script:DeckStatsCache = $null
$Script:IsBusyLoading = $false
$Script:LegendaryCommanderCache = $null
$Script:LegendaryCommanderCacheRoot = ''


$Script:EditorMode = $false
$Script:OriginalImportText = ''
$Script:LoadedCodPath = $null
$Script:OriginalLoadedSnapshot = $null
$Script:LivePreviewLastCard = ''
$Script:LivePreviewRequestId = 0

# =============================================================================
# General helpers
# =============================================================================

function Msg-Error([string]$Message) {
    [System.Windows.Forms.MessageBox]::Show(
        $Message,
        'Cockatrice Universal Deck Importer 5.0 Release 3',
        [System.Windows.Forms.MessageBoxButtons]::OK,
        [System.Windows.Forms.MessageBoxIcon]::Error
    ) | Out-Null
}

function Msg-Info([string]$Message) {
    [System.Windows.Forms.MessageBox]::Show(
        $Message,
        'Cockatrice Universal Deck Importer 5.0 Release 3',
        [System.Windows.Forms.MessageBoxButtons]::OK,
        [System.Windows.Forms.MessageBoxIcon]::Information
    ) | Out-Null
}


function Get-DetailedErrorText {
    param(
        [Parameter(Mandatory=$true)]$ErrorRecord,
        [string]$Context = 'Operation'
    )

    $ex = $ErrorRecord.Exception

    $line = ''
    $column = ''
    $command = ''
    $scriptName = ''
    $stack = ''
    $category = ''
    $fqid = ''

    try { $line = [string]$ErrorRecord.InvocationInfo.ScriptLineNumber } catch {}
    try { $column = [string]$ErrorRecord.InvocationInfo.OffsetInLine } catch {}
    try { $command = [string]$ErrorRecord.InvocationInfo.MyCommand } catch {}
    try { $scriptName = [string]$ErrorRecord.InvocationInfo.ScriptName } catch {}
    try { $stack = [string]$ErrorRecord.ScriptStackTrace } catch {}
    try { $category = [string]$ErrorRecord.CategoryInfo } catch {}
    try { $fqid = [string]$ErrorRecord.FullyQualifiedErrorId } catch {}

    $inner = ''
    try {
        if ($ex.InnerException) {
            $inner = $ex.InnerException.GetType().FullName + ': ' + $ex.InnerException.Message
        }
    } catch {}

    $out = New-Object System.Text.StringBuilder

    [void]$out.AppendLine('============================================================')
    [void]$out.AppendLine(' COCKATRICE UNIVERSAL DECK IMPORTER - ERROR DETAILS')
    [void]$out.AppendLine('============================================================')
    [void]$out.AppendLine('')
    [void]$out.AppendLine("Context        : $Context")
    [void]$out.AppendLine("Time           : $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')")
    [void]$out.AppendLine("Message        : $($ex.Message)")
    [void]$out.AppendLine("Exception Type : $($ex.GetType().FullName)")
    if ($inner)      { [void]$out.AppendLine("Inner Exception: $inner") }
    if ($scriptName) { [void]$out.AppendLine("Script         : $scriptName") }
    if ($line)       { [void]$out.AppendLine("Line           : $line") }
    if ($column)     { [void]$out.AppendLine("Column         : $column") }
    if ($command)    { [void]$out.AppendLine("Command        : $command") }
    if ($fqid)       { [void]$out.AppendLine("Error ID       : $fqid") }
    if ($category)   { [void]$out.AppendLine("Category       : $category") }

    try {
        if ($ErrorRecord.InvocationInfo.Line) {
            [void]$out.AppendLine('')
            [void]$out.AppendLine('SOURCE LINE')
            [void]$out.AppendLine('-----------')
            [void]$out.AppendLine([string]$ErrorRecord.InvocationInfo.Line)
        }
    } catch {}

    if ($stack) {
        [void]$out.AppendLine('')
        [void]$out.AppendLine('SCRIPT STACK')
        [void]$out.AppendLine('------------')
        [void]$out.AppendLine($stack)
    }

    [void]$out.AppendLine('')
    [void]$out.AppendLine('FULL ERROR RECORD')
    [void]$out.AppendLine('-----------------')
    try {
        [void]$out.AppendLine(($ErrorRecord | Format-List * -Force | Out-String).TrimEnd())
    }
    catch {
        [void]$out.AppendLine([string]$ErrorRecord)
    }

    return $out.ToString()
}

function Show-DetailedError {
    param(
        [Parameter(Mandatory=$true)]$ErrorRecord,
        [string]$Context = 'Operation'
    )

    $details = Get-DetailedErrorText -ErrorRecord $ErrorRecord -Context $Context

    try {
        if ($txtResults) {
            $txtResults.Text = $details
            $txtResults.SelectionStart = 0
            $txtResults.SelectionLength = 0
        }
    } catch {}

    $logPath = ''
    try {
        $errorFolder = Join-Path $ScriptFolder 'Logs'
        if (-not (Test-Path -LiteralPath $errorFolder -PathType Container)) {
            New-Item -ItemType Directory -Path $errorFolder -Force | Out-Null
        }

        $logPath = Join-Path $errorFolder (
            'Deck_Importer_Error_' + (Get-Date -Format 'yyyyMMdd_HHmmss') + '.txt'
        )

        [System.IO.File]::WriteAllText(
            $logPath,
            $details,
            (New-Object System.Text.UTF8Encoding($false))
        )
    } catch {}

    $short = "$($ErrorRecord.Exception.Message)`r`n`r`nLine: $($ErrorRecord.InvocationInfo.ScriptLineNumber)"
    $short += "`r`n`r`nFull details are shown in the Smart Checker pane."
    if ($logPath) {
        $short += "`r`n`r`nError log:`r`n$logPath"
    }

    [System.Windows.Forms.MessageBox]::Show(
        $short,
        'Cockatrice Universal Deck Importer 5.0 Release 3 - Error',
        [System.Windows.Forms.MessageBoxButtons]::OK,
        [System.Windows.Forms.MessageBoxIcon]::Error
    ) | Out-Null
}

function Get-SafeFileName([string]$Name) {
    if ([string]::IsNullOrWhiteSpace($Name)) { return 'Imported Deck' }
    foreach ($c in [System.IO.Path]::GetInvalidFileNameChars()) {
        $Name = $Name.Replace([string]$c, '_')
    }
    $Name = $Name.Trim().TrimEnd('.')
    if ([string]::IsNullOrWhiteSpace($Name)) { return 'Imported Deck' }
    return $Name
}

function Get-Sha256([string]$Path) {
    return (Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash
}

function Escape-Display([string]$s) {
    if ($null -eq $s) { return '' }
    return $s.Replace("`r",' ').Replace("`n",' ')
}

function Save-Settings([string]$DeckFolder) {
    try {
        if ([string]::IsNullOrWhiteSpace($DeckFolder)) {
            $DeckFolder = $cmbDest.Text
        }

        [ordered]@{
            Version = 2
            DeckFolder = $DeckFolder
            HoverPreviewDelay = [int]$Script:HoverPreviewDelay
            Saved = (Get-Date).ToString('o')
        } | ConvertTo-Json -Depth 4 |
            Set-Content -LiteralPath $SettingsPath -Encoding UTF8
    }
    catch {}
}

# =============================================================================
# Cockatrice folder detection
# =============================================================================

function Get-DetectedDataRoots {
    $found = New-Object 'System.Collections.Generic.HashSet[string]' ([System.StringComparer]::OrdinalIgnoreCase)

    function Add-Root([string]$Path) {
        if ([string]::IsNullOrWhiteSpace($Path)) { return }
        try {
            $full = [System.IO.Path]::GetFullPath($Path)
            if (Test-Path -LiteralPath (Join-Path $full 'cards.xml') -PathType Leaf) {
                [void]$found.Add($full)
            }
        }
        catch {}
    }

    if ($env:LOCALAPPDATA) {
        Add-Root (Join-Path $env:LOCALAPPDATA 'Cockatrice\Cockatrice')
    }

    if ($env:USERPROFILE) {
        Add-Root (Join-Path $env:USERPROFILE 'Desktop\CockatricePortable\data')
        Add-Root (Join-Path $env:USERPROFILE 'Documents\CockatricePortable\data')

        foreach ($parent in @(
            (Join-Path $env:USERPROFILE 'Desktop'),
            (Join-Path $env:USERPROFILE 'Documents'),
            (Join-Path $env:USERPROFILE 'Downloads')
        )) {
            if (-not (Test-Path -LiteralPath $parent -PathType Container)) { continue }

            Get-ChildItem -LiteralPath $parent -Directory -ErrorAction SilentlyContinue |
                Where-Object { $_.Name -match '(?i)Cockatrice' } |
                ForEach-Object {
                    Add-Root $_.FullName
                    Add-Root (Join-Path $_.FullName 'data')
                }
        }
    }

    # Reuse the AIO updater's saved target if this is kept beside it.
    foreach ($settingsFile in @(
        (Join-Path $ScriptFolder 'Cockatrice_AIO.settings.json'),
        $(if ($env:APPDATA) { Join-Path $env:APPDATA 'Cockatrice_AIO.settings.json' } else { $null })
    )) {
        if (-not $settingsFile) { continue }
        if (-not (Test-Path -LiteralPath $settingsFile -PathType Leaf)) { continue }

        try {
            $j = Get-Content -LiteralPath $settingsFile -Raw | ConvertFrom-Json
            if ($j.DataRoot) {
                Add-Root ([string]$j.DataRoot)
            }
            if ($j.RelativeDataRoot) {
                Add-Root (Join-Path $ScriptFolder ([string]$j.RelativeDataRoot))
            }
        }
        catch {}
    }

    return @($found)
}

function Get-DeckFolders {
    $found = New-Object 'System.Collections.Generic.HashSet[string]' ([System.StringComparer]::OrdinalIgnoreCase)

    foreach ($root in @(Get-DetectedDataRoots)) {
        [void]$found.Add((Join-Path $root 'decks'))
    }

    if (Test-Path -LiteralPath $SettingsPath -PathType Leaf) {
        try {
            $j = Get-Content -LiteralPath $SettingsPath -Raw | ConvertFrom-Json
            if ($j.DeckFolder) { [void]$found.Add([string]$j.DeckFolder) }
        }
        catch {}
    }

    return @($found)
}

function Get-DataRootFromDeckFolder([string]$DeckFolder) {
    if ([string]::IsNullOrWhiteSpace($DeckFolder)) { return $null }

    try {
        $full = [System.IO.Path]::GetFullPath($DeckFolder).TrimEnd('\')
        if ((Split-Path $full -Leaf) -ieq 'decks') {
            $root = Split-Path $full -Parent
            if (Test-Path -LiteralPath (Join-Path $root 'cards.xml') -PathType Leaf) {
                return $root
            }
        }
    }
    catch {}

    return $null
}


# =============================================================================
# Scryfall flavor / alternate printing names
# =============================================================================

function Load-FlavorNameCache {
    $Script:FlavorNameMap.Clear()
    $Script:FlavorNameAmbiguous.Clear()

    if (-not (Test-Path -LiteralPath $Script:FlavorNameCachePath -PathType Leaf)) {
        return $false
    }

    try {
        $rows = @(Get-Content -LiteralPath $Script:FlavorNameCachePath -Raw | ConvertFrom-Json)

        foreach ($row in $rows) {
            $flavor = [string]$row.FlavorName
            $canonical = [string]$row.CanonicalName

            if ([string]::IsNullOrWhiteSpace($flavor) -or
                [string]::IsNullOrWhiteSpace($canonical)) {
                continue
            }

            if ($Script:FlavorNameAmbiguous.Contains($flavor)) {
                continue
            }

            if ($Script:FlavorNameMap.ContainsKey($flavor)) {
                if ($Script:FlavorNameMap[$flavor] -ine $canonical) {
                    [void]$Script:FlavorNameMap.Remove($flavor)
                    [void]$Script:FlavorNameAmbiguous.Add($flavor)
                }
            }
            else {
                $Script:FlavorNameMap[$flavor] = $canonical
            }
        }

        return $true
    }
    catch {
        return $false
    }
}

function Update-FlavorNameCacheFromScryfall {
    param($StatusLabel)

    $headers = @{
        'User-Agent' = 'CockatriceUniversalDeckImporter/3.1.4'
        'Accept' = 'application/json'
    }

    $url = 'https://api.scryfall.com/cards/search?q=has%3Aflavorname&unique=prints&order=name'
    $pairs = New-Object System.Collections.Generic.List[object]
    $seen = New-Object 'System.Collections.Generic.HashSet[string]' ([System.StringComparer]::OrdinalIgnoreCase)

    while ($url) {
        if ($StatusLabel) {
            $StatusLabel.Text = "Updating flavor-name aliases... $($pairs.Count.ToString('N0'))"
            [System.Windows.Forms.Application]::DoEvents()
        }

        $response = Invoke-RestMethod `
            -Uri $url `
            -Headers $headers `
            -Method Get `
            -ErrorAction Stop

        foreach ($card in @($response.data)) {
            $flavor = [string]$card.flavor_name
            $canonical = [string]$card.name

            if ([string]::IsNullOrWhiteSpace($flavor) -or
                [string]::IsNullOrWhiteSpace($canonical)) {
                continue
            }

            $pairKey = $flavor + [char]31 + $canonical
            if ($seen.Add($pairKey)) {
                $pairs.Add([pscustomobject]@{
                    FlavorName = $flavor
                    CanonicalName = $canonical
                })
            }
        }

        if ($response.has_more -and $response.next_page) {
            $url = [string]$response.next_page
            Start-Sleep -Milliseconds 100
        }
        else {
            $url = $null
        }
    }

    $pairs |
        Sort-Object FlavorName, CanonicalName |
        ConvertTo-Json -Depth 4 |
        Set-Content -LiteralPath $Script:FlavorNameCachePath -Encoding UTF8

    [void](Load-FlavorNameCache)
}

function Initialize-FlavorNameAliases {
    param($StatusLabel)

    $loaded = Load-FlavorNameCache
    $refresh = -not $loaded

    if (-not $refresh -and (Test-Path -LiteralPath $Script:FlavorNameCachePath)) {
        try {
            $age = (Get-Date) - (Get-Item -LiteralPath $Script:FlavorNameCachePath).LastWriteTime
            if ($age.TotalDays -ge 30) {
                $refresh = $true
            }
        }
        catch {}
    }

    if ($refresh) {
        try {
            Update-FlavorNameCacheFromScryfall -StatusLabel $StatusLabel
        }
        catch {
            [void](Load-FlavorNameCache)
        }
    }
}

function Resolve-FlavorNameAlias {
    param([string]$Name)

    if ([string]::IsNullOrWhiteSpace($Name)) { return $null }

    $key = $Name.Trim()

    if ($Script:FlavorNameAmbiguous.Contains($key)) {
        return $null
    }

    if ($Script:FlavorNameMap.ContainsKey($key)) {
        return $Script:FlavorNameMap[$key]
    }

    return $null
}


function Save-FlavorNameCacheFromMemory {
    try {
        $rows = New-Object System.Collections.Generic.List[object]

        foreach ($key in $Script:FlavorNameMap.Keys) {
            if ($Script:FlavorNameAmbiguous.Contains($key)) { continue }

            $rows.Add([pscustomobject]@{
                FlavorName = [string]$key
                CanonicalName = [string]$Script:FlavorNameMap[$key]
            })
        }

        $rows |
            Sort-Object FlavorName, CanonicalName |
            ConvertTo-Json -Depth 4 |
            Set-Content -LiteralPath $Script:FlavorNameCachePath -Encoding UTF8
    }
    catch {}
}

function Resolve-FlavorNameAliasLive {
    param([string]$Name)

    if ([string]::IsNullOrWhiteSpace($Name)) { return $null }

    $typed = $Name.Trim()

    $cached = Resolve-FlavorNameAlias -Name $typed
    if ($cached) { return $cached }

    if ($Script:FlavorNameAmbiguous.Contains($typed)) {
        return $null
    }

    try {
        $quoted = '"' + ($typed -replace '"','\"') + '"'
        $cards = @(Invoke-ScryfallCardSearch -Query ('has:flavorname ' + $quoted))

        $exact = @(
            $cards | Where-Object {
                $_.PSObject.Properties['flavor_name'] -and
                ([string]$_.flavor_name -ieq $typed)
            }
        )

        $canonicalNames = @(
            $exact |
                ForEach-Object { [string]$_.name } |
                Where-Object { $_ } |
                Select-Object -Unique
        )

        if ($canonicalNames.Count -eq 1) {
            $canonical = [string]$canonicalNames[0]
            $Script:FlavorNameMap[$typed] = $canonical
            Save-FlavorNameCacheFromMemory
            return $canonical
        }

        if ($canonicalNames.Count -gt 1) {
            [void]$Script:FlavorNameAmbiguous.Add($typed)
        }
    }
    catch {}

    return $null
}

# =============================================================================
# Cockatrice card database index
# =============================================================================

function Add-NamesFromXml {
    param(
        [Parameter(Mandatory=$true)][string]$Path,
        [Parameter(Mandatory=$true)]$Index,
        $StatusLabel
    )

    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) { return 0 }

    $settings = New-Object System.Xml.XmlReaderSettings
    $settings.IgnoreComments = $true
    $settings.IgnoreWhitespace = $true
    $settings.DtdProcessing = [System.Xml.DtdProcessing]::Prohibit
    $settings.CloseInput = $true

    $reader = [System.Xml.XmlReader]::Create($Path, $settings)
    $count = 0

    try {
        while ($reader.Read()) {
            if ($reader.NodeType -ne [System.Xml.XmlNodeType]::Element -or
                $reader.Name -ne 'card') {
                continue
            }

            $cardDepth = $reader.Depth
            $name = ''

            while ($reader.Read()) {
                if ($reader.NodeType -eq [System.Xml.XmlNodeType]::EndElement -and
                    $reader.Depth -eq $cardDepth -and
                    $reader.Name -eq 'card') {
                    break
                }

                if ($reader.NodeType -eq [System.Xml.XmlNodeType]::Element -and
                    $reader.Name -eq 'name') {
                    if (-not $name) {
                        $name = $reader.ReadElementContentAsString()
                    }
                }
            }

            if (-not [string]::IsNullOrWhiteSpace($name) -and
                -not $Index.ContainsKey($name)) {
                $Index[$name] = $name
            }

            $count++

            if ($StatusLabel -and ($count % 3000 -eq 0)) {
                $StatusLabel.Text = "Indexing Cockatrice card names... $($count.ToString('N0'))"
                [System.Windows.Forms.Application]::DoEvents()
            }
        }
    }
    finally {
        $reader.Dispose()
    }

    return $count
}

function Get-CardTypeSortOrder {
    param([string]$Category)

    switch ($Category) {
        'Creature'     { return 10 }
        'Artifact'     { return 20 }
        'Enchantment'  { return 30 }
        'Planeswalker' { return 40 }
        'Battle'       { return 50 }
        'Instant'      { return 60 }
        'Sorcery'      { return 70 }
        'Land'         { return 80 }
        default        { return 90 }
    }
}

function Get-TypeCodeFromFlags {
    param(
        [bool]$Creature,
        [bool]$Planeswalker,
        [bool]$Battle,
        [bool]$Artifact,
        [bool]$Enchantment,
        [bool]$Instant,
        [bool]$Sorcery,
        [bool]$Land
    )

    if ($Creature)     { return [byte]1 }
    if ($Planeswalker) { return [byte]4 }
    if ($Battle)       { return [byte]5 }
    if ($Artifact)     { return [byte]2 }
    if ($Enchantment)  { return [byte]3 }
    if ($Instant)      { return [byte]6 }
    if ($Sorcery)      { return [byte]7 }
    if ($Land)         { return [byte]8 }
    return [byte]9
}

function Add-NeededCardTypesFromXml {
    param(
        [Parameter(Mandatory=$true)][string]$Path,
        [Parameter(Mandatory=$true)]$Wanted,
        $StatusLabel
    )

    if ($Wanted.Count -eq 0) { return }
    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) { return }

    $settings = New-Object System.Xml.XmlReaderSettings
    $settings.IgnoreComments = $true
    $settings.IgnoreWhitespace = $true
    $settings.DtdProcessing = [System.Xml.DtdProcessing]::Prohibit
    $settings.CloseInput = $true

    $reader = [System.Xml.XmlReader]::Create($Path, $settings)
    $seen = 0

    try {
        while ($reader.Read() -and $Wanted.Count -gt 0) {
            if ($reader.NodeType -ne [System.Xml.XmlNodeType]::Element -or
                $reader.Name -ne 'card') {
                continue
            }

            $cardDepth = $reader.Depth
            $name = ''

            $hasCreature = $false
            $hasPlaneswalker = $false
            $hasBattle = $false
            $hasArtifact = $false
            $hasEnchantment = $false
            $hasInstant = $false
            $hasSorcery = $false
            $hasLand = $false

            while ($reader.Read()) {
                if ($reader.NodeType -eq [System.Xml.XmlNodeType]::EndElement -and
                    $reader.Depth -eq $cardDepth -and
                    $reader.Name -eq 'card') {
                    break
                }

                if ($reader.NodeType -ne [System.Xml.XmlNodeType]::Element) {
                    continue
                }

                $nodeName = $reader.Name.ToLowerInvariant()

                if ($nodeName -eq 'name') {
                    if (-not $name) {
                        $name = $reader.ReadElementContentAsString()
                    }
                    continue
                }

                if ($nodeName -eq 'type' -or
                    $nodeName -eq 'maintype' -or
                    $nodeName -eq 'supertype' -or
                    $nodeName -eq 'subtype') {

                    $v = $reader.ReadElementContentAsString()
                    if ($v) {
                        if (-not $hasCreature -and $v -match '(?i)(^|\W)Creature(\W|$)') { $hasCreature = $true }
                        if (-not $hasPlaneswalker -and $v -match '(?i)(^|\W)Planeswalker(\W|$)') { $hasPlaneswalker = $true }
                        if (-not $hasBattle -and $v -match '(?i)(^|\W)Battle(\W|$)') { $hasBattle = $true }
                        if (-not $hasArtifact -and $v -match '(?i)(^|\W)Artifact(\W|$)') { $hasArtifact = $true }
                        if (-not $hasEnchantment -and $v -match '(?i)(^|\W)Enchantment(\W|$)') { $hasEnchantment = $true }
                        if (-not $hasInstant -and $v -match '(?i)(^|\W)Instant(\W|$)') { $hasInstant = $true }
                        if (-not $hasSorcery -and $v -match '(?i)(^|\W)Sorcery(\W|$)') { $hasSorcery = $true }
                        if (-not $hasLand -and $v -match '(?i)(^|\W)Land(\W|$)') { $hasLand = $true }
                    }
                }
            }

            if ($name -and $Wanted.Contains($name)) {
                $Script:CardTypeIndex[$name] = Get-TypeCodeFromFlags `
                    -Creature $hasCreature `
                    -Planeswalker $hasPlaneswalker `
                    -Battle $hasBattle `
                    -Artifact $hasArtifact `
                    -Enchantment $hasEnchantment `
                    -Instant $hasInstant `
                    -Sorcery $hasSorcery `
                    -Land $hasLand

                [void]$Wanted.Remove($name)
            }

            $seen++
            if ($StatusLabel -and ($seen % 4000 -eq 0)) {
                $StatusLabel.Text = "Reading card types for this deck..."
                [System.Windows.Forms.Application]::DoEvents()
            }
        }
    }
    finally {
        $reader.Dispose()
    }
}

function Ensure-CardTypesForEntries {
    param($Entries)

    if (-not $Entries -or -not $Script:CardIndexRoot) { return }

    $wanted = New-Object 'System.Collections.Generic.HashSet[string]' ([System.StringComparer]::OrdinalIgnoreCase)

    foreach ($e in @(Merge-Entries $Entries)) {
        $name = [string]$e.Name
        if ([string]::IsNullOrWhiteSpace($name)) { continue }

        if (-not $Script:CardTypeIndex.ContainsKey($name)) {
            [void]$wanted.Add($name)
        }
    }

    if ($wanted.Count -eq 0) { return }

    $cardsXml = Join-Path $Script:CardIndexRoot 'cards.xml'
    Add-NeededCardTypesFromXml -Path $cardsXml -Wanted $wanted -StatusLabel $status

    if ($wanted.Count -gt 0) {
        $customsets = Join-Path $Script:CardIndexRoot 'customsets'
        if (Test-Path -LiteralPath $customsets -PathType Container) {
            foreach ($file in Get-ChildItem -LiteralPath $customsets -Filter '*.xml' -File -ErrorAction SilentlyContinue) {
                if ($wanted.Count -eq 0) { break }
                try {
                    Add-NeededCardTypesFromXml -Path $file.FullName -Wanted $wanted -StatusLabel $null
                }
                catch {}
            }
        }
    }

    # Anything still unresolved gets Other so we don't repeatedly rescan it.
    foreach ($name in @($wanted)) {
        $Script:CardTypeIndex[$name] = [byte]9
    }
}

function Get-CardTypeCategory {
    param([string]$CardName)

    if ([string]::IsNullOrWhiteSpace($CardName)) { return 'Other' }

    [byte]$code = 9
    if ($Script:CardTypeIndex.ContainsKey($CardName)) {
        $code = [byte]$Script:CardTypeIndex[$CardName]
    }

    switch ($code) {
        1 { return 'Creature' }
        2 { return 'Artifact' }
        3 { return 'Enchantment' }
        4 { return 'Planeswalker' }
        5 { return 'Battle' }
        6 { return 'Instant' }
        7 { return 'Sorcery' }
        8 { return 'Land' }
        default { return 'Other' }
    }
}


function Get-AvailablePhysicalMemoryMB {
    try {
        Add-Type -AssemblyName Microsoft.VisualBasic -ErrorAction SilentlyContinue
        $info = New-Object Microsoft.VisualBasic.Devices.ComputerInfo
        return [Math]::Round(($info.AvailablePhysicalMemory / 1MB),0)
    }
    catch {
        return 0
    }
}

function Write-PerformanceLog {
    param(
        [string]$Stage,
        [double]$Milliseconds = 0,
        [string]$Details = ''
    )

    try {
        $procMB = Get-ProcessMemoryMB
        $availMB = Get-AvailablePhysicalMemoryMB

        $line = '{0} | {1} | {2:N0} ms | Process {3:N0} MB | Available {4:N0} MB' -f `
            (Get-Date -Format 'yyyy-MM-dd HH:mm:ss.fff'),
            $Stage,
            $Milliseconds,
            $procMB,
            $availMB

        if ($Details) {
            $line += ' | ' + $Details
        }

        [System.IO.File]::AppendAllText(
            $Script:PerfLogPath,
            $line + [Environment]::NewLine,
            [System.Text.Encoding]::UTF8
        )
    }
    catch {}
}

function Queue-DeckStatsRefresh {
    if (-not $Script:StatsRefreshTimer) {
        $Script:StatsRefreshTimer = New-Object System.Windows.Forms.Timer
        $Script:StatsRefreshTimer.Interval = 180
        $Script:StatsRefreshTimer.Add_Tick({
            $Script:StatsRefreshTimer.Stop()
            try {
                Update-DeckStatsPanel
            }
            catch {}
        })
    }

    $Script:StatsRefreshTimer.Stop()
    $Script:StatsRefreshTimer.Start()
}

function Get-ProcessMemoryMB {
    try {
        $proc = [System.Diagnostics.Process]::GetCurrentProcess()
        return [Math]::Round(($proc.WorkingSet64 / 1MB), 0)
    }
    catch {
        return 0
    }
}

function Load-CardIndex {
    param(
        [Parameter(Mandatory=$true)][string]$DataRoot,
        [Parameter(Mandatory=$true)]$StatusLabel
    )

    # Reuse the full name index once loaded for this Cockatrice installation.
    if ($Script:CardIndex -and $Script:CardIndexRoot -ieq $DataRoot) {
        Write-PerformanceLog -Stage 'Card index reused' -Details ("Cards={0:N0}" -f $Script:CardIndex.Count)
        return
    }

    $loadStopwatch = [System.Diagnostics.Stopwatch]::StartNew()

    $cardsXml = Join-Path $DataRoot 'cards.xml'
    if (-not (Test-Path -LiteralPath $cardsXml -PathType Leaf)) {
        throw "cards.xml was not found:`r`n$cardsXml"
    }

    $StatusLabel.Text = 'Loading Cockatrice card names...'
    [System.Windows.Forms.Application]::DoEvents()

    $idx = New-Object 'System.Collections.Generic.Dictionary[string,string]' ([System.StringComparer]::OrdinalIgnoreCase)

    [void](Add-NamesFromXml `
        -Path $cardsXml `
        -Index $idx `
        -StatusLabel $StatusLabel)

    $customsets = Join-Path $DataRoot 'customsets'
    if (Test-Path -LiteralPath $customsets -PathType Container) {
        foreach ($file in Get-ChildItem -LiteralPath $customsets -Filter '*.xml' -File -ErrorAction SilentlyContinue) {
            try {
                [void](Add-NamesFromXml `
                    -Path $file.FullName `
                    -Index $idx `
                    -StatusLabel $null)
            }
            catch {}
        }
    }

    $Script:CardIndex = $idx
    $Script:CardIndexRoot = $DataRoot

    # Sort once per Cockatrice database load, then reuse in every browser
    # window instead of sorting 30k+ names each time.
    $sortWatch = [System.Diagnostics.Stopwatch]::StartNew()
    $Script:SortedCardNames = [string[]]@($idx.Keys | Sort-Object)
    $sortWatch.Stop()
    Write-PerformanceLog -Stage 'Card name sort cache built' `
        -Milliseconds $sortWatch.Elapsed.TotalMilliseconds `
        -Details ("Cards={0:N0}" -f $Script:SortedCardNames.Count)

    # Type data is only retained for cards that actually appear in decks.
    $Script:CardTypeIndex.Clear()

    # Do not bulk-fetch all flavor-name printings while loading a deck.
    [void](Load-FlavorNameCache)

    # Forced full GC can itself freeze slower systems. Only request it if
    # this process is actually using a substantial amount of memory.
    try {
        if ((Get-ProcessMemoryMB) -gt 600) {
            [GC]::Collect()
        }
    }
    catch {}

    $loadStopwatch.Stop()
    $memMB = Get-ProcessMemoryMB
    $StatusLabel.Text = "Loaded $($idx.Count.ToString('N0')) Cockatrice card names. RAM: ~$memMB MB"

    Write-PerformanceLog -Stage 'Card index loaded' `
        -Milliseconds $loadStopwatch.Elapsed.TotalMilliseconds `
        -Details ("Cards={0:N0}; Root={1}" -f $idx.Count,$DataRoot)
}


function Get-CardSuggestionKey {
    param([string]$Name)

    if ([string]::IsNullOrWhiteSpace($Name)) { return '' }
    return ([regex]::Replace($Name.ToLowerInvariant(), '[^\p{L}\p{N}]', ''))
}

function Get-BoundedEditDistance {
    param(
        [string]$A,
        [string]$B,
        [int]$MaxDistance = 3
    )

    if ($null -eq $A) { $A = '' }
    if ($null -eq $B) { $B = '' }

    if ([Math]::Abs($A.Length - $B.Length) -gt $MaxDistance) {
        return ($MaxDistance + 1)
    }

    if ($A -ceq $B) { return 0 }

    $previous = New-Object 'int[]' ($B.Length + 1)
    $current = New-Object 'int[]' ($B.Length + 1)

    for ($j = 0; $j -le $B.Length; $j++) {
        $previous[$j] = $j
    }

    for ($i = 1; $i -le $A.Length; $i++) {
        $current[0] = $i
        $rowMin = $current[0]

        for ($j = 1; $j -le $B.Length; $j++) {
            $cost = if ($A[$i - 1] -ceq $B[$j - 1]) { 0 } else { 1 }

            $value = [Math]::Min(
                ($previous[$j] + 1),
                [Math]::Min(
                    ($current[$j - 1] + 1),
                    ($previous[$j - 1] + $cost)
                )
            )

            # Adjacent transposition (e.g. "Rign" -> "Ring")
            if ($i -gt 1 -and $j -gt 1 -and
                $A[$i - 1] -ceq $B[$j - 2] -and
                $A[$i - 2] -ceq $B[$j - 1]) {
                $transposed = $previous[$j - 2] + 1
                if ($transposed -lt $value) {
                    $value = $transposed
                }
            }

            $current[$j] = $value
            if ($value -lt $rowMin) {
                $rowMin = $value
            }
        }

        if ($rowMin -gt $MaxDistance) {
            return ($MaxDistance + 1)
        }

        $tmp = $previous
        $previous = $current
        $current = $tmp
    }

    return $previous[$B.Length]
}

function Find-CardSuggestions([string]$BadName) {
    if (-not $Script:CardIndex) { return @() }

    $raw = $BadName.Trim()
    if ($raw.Length -lt 2) { return @() }

    $badKey = Get-CardSuggestionKey $raw
    if (-not $badKey) { return @() }

    $strong = New-Object System.Collections.Generic.List[string]

    # Fast candidates first.
    foreach ($name in $Script:CardIndex.Keys) {
        $key = Get-CardSuggestionKey $name
        if (-not $key) { continue }

        $lengthDelta = [Math]::Abs($key.Length - $badKey.Length)

        if ($lengthDelta -le 4 -and
            ($key.StartsWith($badKey, [System.StringComparison]::OrdinalIgnoreCase) -or
             $badKey.StartsWith($key, [System.StringComparison]::OrdinalIgnoreCase))) {
            $strong.Add($name)
            if ($strong.Count -ge 3) { break }
        }
    }

    if ($strong.Count -gt 0) {
        return @($strong)
    }

    $maxDistance = if ($badKey.Length -le 5) {
        1
    }
    elseif ($badKey.Length -le 10) {
        2
    }
    elseif ($badKey.Length -le 18) {
        3
    }
    else {
        4
    }

    $ranked = New-Object System.Collections.Generic.List[object]

    foreach ($name in $Script:CardIndex.Keys) {
        $key = Get-CardSuggestionKey $name
        if (-not $key) { continue }

        if ([Math]::Abs($key.Length - $badKey.Length) -gt $maxDistance) {
            continue
        }

        # Cheap prefilter to keep typo search responsive.
        if ($badKey.Length -ge 4 -and $key.Length -ge 4) {
            $firstSame = ($badKey[0] -ceq $key[0])
            $lastSame = ($badKey[$badKey.Length - 1] -ceq $key[$key.Length - 1])

            if (-not $firstSame -and -not $lastSame) {
                continue
            }
        }

        $distance = Get-BoundedEditDistance -A $badKey -B $key -MaxDistance $maxDistance

        if ($distance -le $maxDistance) {
            $ranked.Add([pscustomobject]@{
                Name = $name
                Distance = $distance
                LengthDelta = [Math]::Abs($key.Length - $badKey.Length)
            })
        }
    }

    return @(
        $ranked |
            Sort-Object Distance, LengthDelta, Name |
            Select-Object -First 3 -ExpandProperty Name
    )
}


# =============================================================================
# Deck entry / parsing helpers
# =============================================================================

function New-Entry {
    param(
        [int]$Qty,
        [string]$Name,
        [string]$Zone='main',
        [string]$Source='Text',
        [string]$PrintingSet='',
        [string]$PrintingCollector='',
        [string]$PrintingUUID=''
    )

    return [pscustomobject]@{
        Qty               = $Qty
        Name              = $Name.Trim()
        Zone              = $Zone
        Source            = $Source
        Valid             = $false
        Suggestion        = ''
        PrintingSet       = $PrintingSet
        PrintingCollector = $PrintingCollector
        PrintingUUID      = $PrintingUUID
    }
}

function Clean-ExportedCardName([string]$Name) {
    if ([string]::IsNullOrWhiteSpace($Name)) { return '' }

    $s = $Name.Trim()

    # Common online export decorations.
    $s = $s -replace '\s+\*CMDR\*\s*$', ''
    $s = $s -replace '\s+\*COMMANDER\*\s*$', ''
    $s = $s -replace '\s+\*F\*\s*$', ''
    $s = $s -replace '\s+\*E\*\s*$', ''
    $s = $s -replace '\s+\(F\)\s*$', ''
    $s = $s -replace '\s+\[Foil\]\s*$', ''

    # (SET) 123 / [SET:123] / [SET]
    $s = $s -replace '\s+\([A-Za-z0-9_\-]{2,12}\)\s+[A-Za-z0-9\-★]+\s*$', ''
    $s = $s -replace '\s+\[[A-Za-z0-9_\-]{2,12}:[A-Za-z0-9\-★]+\]\s*$', ''
    $s = $s -replace '\s+\[[A-Za-z0-9_\-]{2,12}\]\s*$', ''

    return $s.Trim()
}

function Get-HeadingZone([string]$Line) {
    $s = $Line.Trim().TrimEnd(':').Trim()
    $s = $s -replace '\s*\(\s*\d+\s*\)\s*$', ''

    if ($s -match '(?i)^(commander|commanders|command zone)$') { return 'commander' }
    if ($s -match '(?i)^(side|sideboard|side board|companion|companions)$') { return 'side' }
    if ($s -match '(?i)^(maybe|maybeboard|considering|acquireboard)$') { return 'maybe' }

    # Category headings from sites are still main deck unless explicitly side/maybe.
    if ($s -match '(?i)^(main|mainboard|maindeck|main deck|deck|decklist|cards|creature|creatures|artifact|artifacts|enchantment|enchantments|instant|instants|sorcery|sorceries|land|lands|planeswalker|planeswalkers|battle|battles|ramp|draw|removal|other|other spells)$') {
        return 'main'
    }

    return $null
}

function Parse-OneCardPerLine {
    param([string[]]$Lines, [bool]$IncludeMaybe)

    $entries = New-Object System.Collections.Generic.List[object]
    $ignored = New-Object System.Collections.Generic.List[string]
    $zone = 'main'

    foreach ($raw in $Lines) {
        $line = $raw.Trim()
        if ([string]::IsNullOrWhiteSpace($line)) { continue }

        $line = $line -replace '^[\-\*\u2022]\s+', ''

        $heading = Get-HeadingZone $line
        if ($heading) {
            $zone = $heading
            continue
        }

        if ($line -match '(?i)^SB\s*:\s*(.+)$') {
            $zoneForCard = 'side'
            $line = $Matches[1].Trim()
        }
        elseif ($line -match '(?i)^CMD\s*:\s*(.+)$') {
            $zoneForCard = 'commander'
            $line = $Matches[1].Trim()
        }
        else {
            $zoneForCard = $zone
        }

        if ($line -match '^(?<qty>\d+)\s*[xX]?\s+(?<name>.+?)\s*$') {
            $qty = [int]$Matches['qty']
            $name = Clean-ExportedCardName $Matches['name']

            if ($zoneForCard -eq 'maybe' -and -not $IncludeMaybe) { continue }
            if ($zoneForCard -eq 'maybe') { $zoneForCard = 'side' }

            if ($qty -gt 0 -and $name) {
                $entries.Add((New-Entry -Qty $qty -Name $name -Zone $zoneForCard))
            }
        }
        elseif ($line -match '^(?<name>.+?)\s*[,;]\s*(?<qty>\d+)\s*$') {
            $qty = [int]$Matches['qty']
            $name = Clean-ExportedCardName $Matches['name']
            if ($qty -gt 0 -and $name) {
                $entries.Add((New-Entry -Qty $qty -Name $name -Zone $zoneForCard))
            }
        }
        elseif ($zoneForCard -in @('commander','side')) {
            $name = Clean-ExportedCardName $line
            if ($name) { $entries.Add((New-Entry -Qty 1 -Name $name -Zone $zoneForCard)) }
        }
        else {
            $ignored.Add($raw)
        }
    }

    return [pscustomobject]@{ Entries=$entries.ToArray(); Ignored=$ignored.ToArray() }
}

function Parse-GiantSingleLine {
    param([string]$Text)

    $entries = New-Object System.Collections.Generic.List[object]

    # Split at " quantity + space " boundaries while preserving card names such
    # as "100-Year Storm" because the number there is followed by a hyphen.
    $pattern = '(?<!\S)(?<qty>\d+)\s+[xX]?\s*(?<name>.*?)(?=(?:\s+\d+\s+(?:[xX]\s+)?)|$)'
    $matches = [regex]::Matches($Text.Trim(), $pattern)

    foreach ($m in $matches) {
        $qty = [int]$m.Groups['qty'].Value
        $name = Clean-ExportedCardName $m.Groups['name'].Value
        if ($qty -gt 0 -and $name) {
            $entries.Add((New-Entry -Qty $qty -Name $name -Zone 'main'))
        }
    }

    return $entries.ToArray()
}


function Parse-MoxfieldMtgoExport {
    param(
        [string]$Text,
        [bool]$IncludeMaybe
    )

    if ([string]::IsNullOrWhiteSpace($Text)) { return $null }

    $lines = @($Text -split "`r?`n")

    # This fallback specifically targets Moxfield's "Copy for MTGO" layout:
    #
    #   1 Card
    #   ...
    #
    #   SIDEBOARD:
    #   1 Card
    #   ...
    #
    #   1 Commander Name
    #
    # The trailing singleton after a blank line is treated as a commander
    # candidate, not blindly forced unless the structure is unambiguous.

    $sideIndex = -1
    for ($i=0; $i -lt $lines.Count; $i++) {
        if ($lines[$i].Trim() -match '(?i)^SIDEBOARD\s*:$') {
            $sideIndex = $i
            break
        }
    }

    if ($sideIndex -lt 0) { return $null }

    $entries = New-Object System.Collections.Generic.List[object]

    # Mainboard before SIDEBOARD:
    for ($i=0; $i -lt $sideIndex; $i++) {
        $line = $lines[$i].Trim()
        if (-not $line) { continue }

        if ($line -match '^(?<qty>\d+)\s*[xX]?\s+(?<name>.+?)\s*$') {
            $qty = [int]$Matches['qty']
            $name = Clean-ExportedCardName $Matches['name']
            if ($qty -gt 0 -and $name) {
                $entries.Add((New-Entry -Qty $qty -Name $name -Zone 'main' -Source 'Moxfield MTGO text'))
            }
        }
    }

    # Split post-sideboard content into non-empty groups so a trailing group
    # can be distinguished from the actual sideboard.
    $groups = New-Object System.Collections.Generic.List[object]
    $current = New-Object System.Collections.Generic.List[string]

    for ($i=$sideIndex+1; $i -lt $lines.Count; $i++) {
        $line = $lines[$i].Trim()

        if (-not $line) {
            if ($current.Count -gt 0) {
                $groups.Add($current.ToArray())
                $current = New-Object System.Collections.Generic.List[string]
            }
            continue
        }

        $current.Add($line)
    }

    if ($current.Count -gt 0) {
        $groups.Add($current.ToArray())
    }

    if ($groups.Count -eq 0) {
        return [pscustomobject]@{
            Entries = $entries.ToArray()
            Ignored = @()
            SuggestedCommanders = @()
            Source = 'Moxfield MTGO text'
        }
    }

    # First group after SIDEBOARD is the actual sideboard.
    foreach ($line in @($groups[0])) {
        if ($line -match '^(?<qty>\d+)\s*[xX]?\s+(?<name>.+?)\s*$') {
            $qty = [int]$Matches['qty']
            $name = Clean-ExportedCardName $Matches['name']
            if ($qty -gt 0 -and $name) {
                $entries.Add((New-Entry -Qty $qty -Name $name -Zone 'side' -Source 'Moxfield MTGO text'))
            }
        }
    }

    $suggested = New-Object System.Collections.Generic.List[string]

    # A single trailing group containing exactly one "1 Card" line is the
    # pattern Moxfield currently emits for Commander in Copy-for-MTGO.
    if ($groups.Count -ge 2) {
        $tail = @($groups[$groups.Count-1])

        if ($tail.Count -eq 1 -and $tail[0] -match '^1\s+[xX]?\s*(?<name>.+?)\s*$') {
            $commanderName = Clean-ExportedCardName $Matches['name']

            if ($commanderName) {
                $entries.Add((New-Entry -Qty 1 -Name $commanderName -Zone 'commander' -Source 'Moxfield MTGO text'))
                $suggested.Add($commanderName)
            }
        }
        else {
            # Preserve any additional groups as sideboard rather than guessing.
            for ($g=1; $g -lt $groups.Count; $g++) {
                foreach ($line in @($groups[$g])) {
                    if ($line -match '^(?<qty>\d+)\s*[xX]?\s+(?<name>.+?)\s*$') {
                        $qty = [int]$Matches['qty']
                        $name = Clean-ExportedCardName $Matches['name']
                        if ($qty -gt 0 -and $name) {
                            $entries.Add((New-Entry -Qty $qty -Name $name -Zone 'side' -Source 'Moxfield MTGO text'))
                        }
                    }
                }
            }
        }
    }

    return [pscustomobject]@{
        Entries = $entries.ToArray()
        Ignored = @()
        SuggestedCommanders = $suggested.ToArray()
        Source = 'Moxfield MTGO text'
    }
}

function Parse-PastedText {
    param([string]$Text, [bool]$IncludeMaybe)

    if ([string]::IsNullOrWhiteSpace($Text)) {
        return [pscustomobject]@{ Entries=@(); Ignored=@(); SuggestedCommanders=@(); Source='Pasted text' }
    }

    $mox = Parse-MoxfieldMtgoExport -Text $Text -IncludeMaybe $IncludeMaybe
    if ($mox) {
        return $mox
    }

    $lines = @($Text -split "`r?`n")

    # First use normal line parsing.
    $normal = Parse-OneCardPerLine -Lines $lines -IncludeMaybe $IncludeMaybe

    # A long line with multiple "1 Card" chunks is reparsed as a giant list.
    if ($lines.Count -le 3 -and $Text.Length -gt 80) {
        $giant = @(Parse-GiantSingleLine -Text (($lines -join ' ').Trim()))
        if ($giant.Count -gt $normal.Entries.Count) {
            return [pscustomobject]@{ Entries=$giant; Ignored=@(); SuggestedCommanders=@(); Source='Pasted text' }
        }
    }

    return [pscustomobject]@{
        Entries = @($normal.Entries)
        Ignored = @($normal.Ignored)
        SuggestedCommanders = @()
        Source = 'Pasted text'
    }
}

# =============================================================================
# Direct URL imports
# =============================================================================


function Invoke-CockatriceStyleDownload {
    param(
        [Parameter(Mandatory=$true)][string]$Url,
        [ValidateSet('text','json')][string]$As = 'text'
    )

    $curl = Join-Path $env:SystemRoot 'System32\curl.exe'
    $temp = Join-Path ([System.IO.Path]::GetTempPath()) ("CockatriceDeckImport_" + [guid]::NewGuid().ToString('N') + ".tmp")

    try {
        if (Test-Path -LiteralPath $curl -PathType Leaf) {
            # Mirror Cockatrice's intentionally simple request style as closely
            # as practical while using Windows curl rather than PowerShell's
            # older .NET web stack.
            $args = @(
                '--location',
                '--fail',
                '--silent',
                '--show-error',
                '--connect-timeout', '20',
                '--max-time', '60',
                '--user-agent', 'Cockatrice 2.10',
                '--header', 'Accept: */*',
                '--output', $temp,
                $Url
            )

            $output = & $curl @args 2>&1
            $exit = $LASTEXITCODE

            if ($exit -eq 0 -and (Test-Path -LiteralPath $temp) -and (Get-Item -LiteralPath $temp).Length -gt 0) {
                $raw = [System.IO.File]::ReadAllText($temp, [System.Text.Encoding]::UTF8)

                if ($As -eq 'json') {
                    try {
                        return ($raw | ConvertFrom-Json -ErrorAction Stop)
                    }
                    catch {
                        throw "Downloaded data was not valid JSON.`r`n$($_.Exception.Message)"
                    }
                }

                return $raw
            }

            $curlMessage = ($output | Out-String).Trim()
            if (-not $curlMessage) { $curlMessage = "curl.exe exited with code $exit." }
            throw $curlMessage
        }

        # Fallback for older Windows builds without curl.exe.
        $headers = @{
            'User-Agent' = 'Cockatrice 2.10'
            'Accept' = '*/*'
        }

        if ($As -eq 'json') {
            return Invoke-RestMethod -Uri $Url -Headers $headers -Method Get -ErrorAction Stop
        }

        $response = Invoke-WebRequest -Uri $Url -Headers $headers -UseBasicParsing -Method Get -ErrorAction Stop
        return [string]$response.Content
    }
    finally {
        Remove-Item -LiteralPath $temp -Force -ErrorAction SilentlyContinue
    }
}

function Convert-CockatricePlainExport {
    param(
        [Parameter(Mandatory=$true)][string]$Text,
        [Parameter(Mandatory=$true)][string]$SourceName,
        [bool]$IncludeMaybe = $false
    )

    # Our existing plain-text parser already supports the syntax Cockatrice's
    # DeckList::loadFromStream_Plain accepts: quantities, SIDEBOARD headings,
    # and SB: prefixes. Keep the source label so validation output is useful.
    $parsed = Parse-PastedText -Text $Text -IncludeMaybe $IncludeMaybe

    foreach ($e in @($parsed.Entries)) {
        $e.Source = $SourceName
    }

    return [pscustomobject]@{
        Name = "$SourceName Deck"
        Format = ''
        Entries = @($parsed.Entries)
        Source = $SourceName
        SuggestedCommanders = @($parsed.SuggestedCommanders)
    }
}

function Get-DeckstatsDeck {
    param([string]$Url)

    # Deckstats currently serves at least two public URL shapes:
    #
    # Classic/canonical:
    #   https://deckstats.net/decks/<OWNER_ID>/<DECK_ID>-<slug>/en
    #
    # Short/alias:
    #   https://deckstats.net/decks/<DECK_ID>-<slug>
    #
    # Cockatrice's current C++ matcher only recognizes the first shape, but
    # Deckstats itself accepts the second shape as well. Support both.

    $canonicalMatch = [regex]::Match(
        $Url,
        '(?i)^https?://(?:www\.)?deckstats\.net/decks/(?<owner>\d+)/(?<deck>[a-zA-Z0-9_-]+)(?:/[a-z]{2})?/?(?:[?#].*)?$'
    )

    $shortMatch = [regex]::Match(
        $Url,
        '(?i)^https?://(?:www\.)?deckstats\.net/decks/(?<deck>\d+[a-zA-Z0-9_-]*)(?:/[a-z]{2})?/?(?:[?#].*)?$'
    )

    $pageUrl = $null
    $api = $null
    $deckPart = $null

    if ($canonicalMatch.Success) {
        $owner = $canonicalMatch.Groups['owner'].Value
        $deckPart = $canonicalMatch.Groups['deck'].Value
        $pageUrl = "https://deckstats.net/decks/${owner}/${deckPart}"
        $api = "${pageUrl}?include_comments=1&export_mtgarena=1"
    }
    elseif ($shortMatch.Success) {
        $deckPart = $shortMatch.Groups['deck'].Value
        $pageUrl = "https://deckstats.net/decks/${deckPart}"
        $api = "${pageUrl}?include_comments=1&export_mtgarena=1"
    }
    else {
        throw @"
Deckstats URL was not recognized.

Accepted examples:

  https://deckstats.net/decks/4464146-Commander-Choco-Seeker-of-Paradise

or the older owner/deck form:

  https://deckstats.net/decks/172270/4164560-choco-seeker-of-paradise
"@
    }

    function Try-DeckstatsExport([string]$ExportUrl) {
        $text = Invoke-CockatriceStyleDownload -Url $ExportUrl -As text

        if ([string]::IsNullOrWhiteSpace($text)) {
            return $null
        }

        $parsed = Convert-CockatricePlainExport -Text $text -SourceName 'Deckstats'

        if ($parsed.Entries -and @($parsed.Entries).Count -gt 0) {
            return [pscustomobject]@{
                Result = $parsed
                Raw = $text
            }
        }

        return [pscustomobject]@{
            Result = $null
            Raw = $text
        }
    }

    $first = $null

    try {
        $first = Try-DeckstatsExport $api
    }
    catch {
        throw "Deckstats could not be downloaded.`r`nURL tried: $api`r`n$($_.Exception.Message)"
    }

    if ($first -and $first.Result) {
        $first.Result.Name = $deckPart
        return $first.Result
    }

    # Short Deckstats URLs may return the normal HTML page even with export
    # parameters. If that happens, fetch the page and look for Deckstats'
    # canonical owner/deck URL in <link rel=canonical>, og:url, or embedded HTML.
    if ($shortMatch.Success) {
        $html = $null

        try {
            $html = Invoke-CockatriceStyleDownload -Url $pageUrl -As text
        }
        catch {}

        if ($html) {
            $patterns = @(
                '(?i)https?://(?:www\.)?deckstats\.net/decks/(?<owner>\d+)/(?<deck>[a-zA-Z0-9_-]+)',
                '(?i)/decks/(?<owner>\d+)/(?<deck>[a-zA-Z0-9_-]+)'
            )

            foreach ($pattern in $patterns) {
                $m = [regex]::Match($html, $pattern)

                if ($m.Success) {
                    $owner = $m.Groups['owner'].Value
                    $canonicalDeck = $m.Groups['deck'].Value

                    # Avoid accidentally treating the short ID itself as owner.
                    if ($owner -and $canonicalDeck) {
                        $canonicalApi = "https://deckstats.net/decks/${owner}/${canonicalDeck}?include_comments=1&export_mtgarena=1"

                        try {
                            $second = Try-DeckstatsExport $canonicalApi

                            if ($second -and $second.Result) {
                                $second.Result.Name = $canonicalDeck
                                return $second.Result
                            }
                        }
                        catch {}
                    }
                }
            }
        }
    }

    $sample = ''
    if ($first -and $first.Raw) {
        $sample = [string]$first.Raw
        if ($sample.Length -gt 1000) {
            $sample = $sample.Substring(0,1000)
        }
    }

    throw @"
Deckstats responded, but no deck cards could be parsed.

Original URL:
  $Url

Export URL tried:
  $api

The importer also attempted to resolve a canonical owner/deck URL when this was
a short Deckstats link.

Beginning of Deckstats response:
$sample
"@
}

function Get-TappedOutDeck {
    param([string]$Url)

    # Mirrors Cockatrice DeckLinkToApiTransformer:
    # tappedout.net/mtg-decks/<slug>/?fmt=txt
    if ($Url -notmatch '(?i)tappedout\.net/(?:mtg-decks/)?(?<slug>[^/?#]+)') {
        throw 'Could not determine the TappedOut deck slug from the URL.'
    }

    $slug = $Matches['slug']
    $api = "https://tappedout.net/mtg-decks/${slug}/?fmt=txt"

    try {
        $text = Invoke-CockatriceStyleDownload -Url $api -As text
    }
    catch {
        throw "TappedOut could not be downloaded.`r`n$($_.Exception.Message)"
    }

    if ([string]::IsNullOrWhiteSpace($text)) {
        throw 'TappedOut returned an empty deck export.'
    }

    $result = Convert-CockatricePlainExport -Text $text -SourceName 'TappedOut'
    $result.Name = $slug
    return $result
}

function Get-MoxfieldDeck {
    param([string]$Url)

    if ($Url -notmatch '(?i)moxfield\.com/decks/(?<id>[A-Za-z0-9_\-]+)') {
        throw 'Could not determine the Moxfield public deck ID from the URL.'
    }

    $id = $Matches['id']

    # This is the exact endpoint Cockatrice currently constructs.
    $cockatriceApi = "https://api.moxfield.com/v2/decks/all/$id/"

    $deck = $null
    $errors = New-Object System.Collections.Generic.List[string]

    # 1) Windows curl.exe first: different HTTP stack from Windows PowerShell.
    try {
        $deck = Invoke-CockatriceStyleDownload -Url $cockatriceApi -As json
    }
    catch {
        $errors.Add("curl/Cockatrice-style: " + $_.Exception.Message)
    }

    # 2) Current api2 endpoint as secondary compatibility attempt.
    if (-not $deck) {
        try {
            $deck = Invoke-CockatriceStyleDownload `
                -Url "https://api2.moxfield.com/v3/decks/all/$id" `
                -As json
        }
        catch {
            $errors.Add("api2 fallback: " + $_.Exception.Message)
        }
    }

    # 3) Final PowerShell-native attempt with Cockatrice's simple User-Agent.
    if (-not $deck) {
        try {
            $deck = Invoke-RestMethod `
                -Uri $cockatriceApi `
                -Headers @{ 'User-Agent'='Cockatrice 2.10'; 'Accept'='*/*' } `
                -Method Get `
                -ErrorAction Stop
        }
        catch {
            $errors.Add("PowerShell fallback: " + $_.Exception.Message)
        }
    }

    if (-not $deck) {
        $detail = ($errors -join "`r`n  - ")
        throw @"
Moxfield blocked all direct import methods.

Tried:
  1. Windows curl.exe using Cockatrice-style request
  2. Moxfield api2 compatibility endpoint
  3. PowerShell fallback using Cockatrice User-Agent

The deck can still be public; Moxfield may reject non-Qt/non-browser clients.

Fallback:
  Moxfield -> Copy for MTGO -> paste here -> Load Web Deck

Deck ID: $id

Details:
  - $detail
"@
    }

    $entries = New-Object System.Collections.Generic.List[object]

    function Add-MoxBoard {
        param(
            $Board,
            [string]$Zone
        )

        if ($null -eq $Board) { return }

        # v3 commonly wraps card maps under .cards.
        $sourceBoard = $Board
        if ($Board.PSObject.Properties['cards'] -and $Board.cards) {
            $sourceBoard = $Board.cards
        }

        foreach ($prop in $sourceBoard.PSObject.Properties) {
            $item = $prop.Value
            if ($null -eq $item) { continue }

            $qty = 1
            if ($item.PSObject.Properties['quantity'] -and $item.quantity) {
                $qty = [int]$item.quantity
            }

            $name = $null

            if ($item.PSObject.Properties['card'] -and
                $item.card -and
                $item.card.PSObject.Properties['name'] -and
                $item.card.name) {

                $name = [string]$item.card.name
            }
            elseif ($item.PSObject.Properties['name'] -and $item.name) {
                $name = [string]$item.name
            }
            elseif ($prop.Name) {
                $name = [string]$prop.Name
            }

            if ($name) {
                $entries.Add((New-Entry -Qty $qty -Name $name -Zone $Zone -Source 'Moxfield'))
            }
        }
    }

    # Support both current v3 {"boards":{...}} shape and older v2 top-level shape.
    if ($deck.PSObject.Properties['boards'] -and $deck.boards) {
        $boards = $deck.boards

        if ($boards.PSObject.Properties['mainboard']) {
            Add-MoxBoard -Board $boards.mainboard -Zone 'main'
        }
        if ($boards.PSObject.Properties['commanders']) {
            Add-MoxBoard -Board $boards.commanders -Zone 'commander'
        }
        if ($boards.PSObject.Properties['sideboard']) {
            Add-MoxBoard -Board $boards.sideboard -Zone 'side'
        }
        if ($boards.PSObject.Properties['companions']) {
            Add-MoxBoard -Board $boards.companions -Zone 'side'
        }
        if ($boards.PSObject.Properties['signatureSpells']) {
            Add-MoxBoard -Board $boards.signatureSpells -Zone 'commander'
        }
    }
    else {
        if ($deck.PSObject.Properties['mainboard']) {
            Add-MoxBoard -Board $deck.mainboard -Zone 'main'
        }
        if ($deck.PSObject.Properties['commanders']) {
            Add-MoxBoard -Board $deck.commanders -Zone 'commander'
        }
        if ($deck.PSObject.Properties['sideboard']) {
            Add-MoxBoard -Board $deck.sideboard -Zone 'side'
        }
        if ($deck.PSObject.Properties['companions']) {
            Add-MoxBoard -Board $deck.companions -Zone 'side'
        }
        if ($deck.PSObject.Properties['signatureSpells']) {
            Add-MoxBoard -Board $deck.signatureSpells -Zone 'commander'
        }
    }

    if ($entries.Count -eq 0) {
        throw 'Moxfield returned deck data, but no cards could be read from it.'
    }

    $name = if ($deck.PSObject.Properties['name'] -and $deck.name) {
        [string]$deck.name
    } else {
        'Moxfield Deck'
    }

    $format = if ($deck.PSObject.Properties['format'] -and $deck.format) {
        [string]$deck.format
    } else {
        ''
    }

    $bracket = $null
    foreach ($field in @('userBracket','bracket','autoBracket')) {
        if ($deck.PSObject.Properties[$field] -and $deck.$field) {
            $bracket = [string]$deck.$field
            break
        }
    }

    return [pscustomobject]@{
        Name = $name
        Format = $format
        Bracket = $bracket
        Entries = $entries.ToArray()
        Source = 'Moxfield'
    }
}

function Get-ArchidektNameFromCardObject($Obj) {
    if ($null -eq $Obj) { return $null }

    foreach ($path in @(
        @('card','oracleCard','name'),
        @('card','name'),
        @('oracleCard','name')
    )) {
        $cur = $Obj
        $ok = $true
        foreach ($part in $path) {
            if ($null -eq $cur) { $ok = $false; break }
            $p = $cur.PSObject.Properties[$part]
            if (-not $p) { $ok = $false; break }
            $cur = $p.Value
        }
        if ($ok -and $cur) { return [string]$cur }
    }

    return $null
}

function Get-ArchidektDeck {
    param([string]$Url)

    if ($Url -notmatch '(?i)archidekt\.com/decks/(?<id>\d+)') {
        throw 'Could not determine the Archidekt deck number from the URL.'
    }

    $id = $Matches['id']
    # Exact Cockatrice URL transformation.
    $api = "https://archidekt.com/api/decks/$id/?format=json"
    try {
        $deck = Invoke-CockatriceStyleDownload -Url $api -As json
    }
    catch {
        throw "Archidekt could not be read.`r`n$($_.Exception.Message)"
    }

    $entries = New-Object System.Collections.Generic.List[object]

    foreach ($item in @($deck.cards)) {
        $name = Get-ArchidektNameFromCardObject $item
        if (-not $name) { continue }

        $qty = 1
        if ($item.quantity) { $qty = [int]$item.quantity }

        $zone = 'main'
        $cats = @()
        if ($item.categories) { $cats = @($item.categories | ForEach-Object { [string]$_ }) }

        if ($cats -match '(?i)^Commander$|^Commanders$') { $zone = 'commander' }
        elseif ($cats -match '(?i)^Sideboard$|^Side$') { $zone = 'side' }
        elseif ($cats -match '(?i)^Maybeboard$|^Maybe$') { continue }

        $entries.Add((New-Entry -Qty $qty -Name $name -Zone $zone -Source 'Archidekt'))
    }

    # Some versions of the response expose commander IDs/categories separately;
    # normalize cards whose category name includes Commander.
    if ($deck.commander) {
        foreach ($commander in @($deck.commander)) {
            $cn = Get-ArchidektNameFromCardObject $commander
            if ($cn) {
                foreach ($e in @($entries | Where-Object { $_.Name -ieq $cn })) {
                    $e.Zone = 'commander'
                }
            }
        }
    }

    $name = if ($deck.name) { [string]$deck.name } else { "Archidekt Deck $id" }
    $format = ''
    if ($deck.deckFormat) { $format = [string]$deck.deckFormat }
    elseif ($deck.format) { $format = [string]$deck.format }

    return [pscustomobject]@{
        Name = $name
        Format = $format
        Entries = $entries.ToArray()
        Source = 'Archidekt'
    }
}

function Import-DeckUrl([string]$Url) {
    if ($Url -match '(?i)moxfield\.com/decks/') {
        return Get-MoxfieldDeck -Url $Url
    }

    if ($Url -match '(?i)archidekt\.com/decks/') {
        return Get-ArchidektDeck -Url $Url
    }

    if ($Url -match '(?i)deckstats\.net/') {
        throw @"
Deckstats direct-link import is not enabled in this build.

Deckstats changed its public URL/export behavior and the direct link is not
reliable enough to advertise as supported.

Use:
  Deckstats -> Export / Copy decklist
  Paste the exported text into this importer
  Click Load Web Deck

Supported direct URLs:
  - Moxfield
  - Archidekt
"@
    }

    if ($Url -match '(?i)tappedout\.net/') {
        throw @"
TappedOut direct-link import is not enabled in this build.

Use:
  TappedOut -> Export / Copy decklist
  Paste the exported text into this importer
  Click Load Web Deck

Supported direct URLs:
  - Moxfield
  - Archidekt
"@
    }

    throw @"
Direct URL import is currently supported for:

  - Moxfield
  - Archidekt

For Deckstats, TappedOut, or another deck website:
  1. Use that site's Copy / Export decklist option
  2. Paste the exported text into this importer
  3. Click Load Web Deck
"@
}


# =============================================================================
# Cockatrice printing metadata
# =============================================================================

function Get-PreferredPrinting {
    param(
        [Parameter(Mandatory=$true)][string]$DataRoot,
        [Parameter(Mandatory=$true)][string]$CardName,
        [string]$PreferredSet = '',
        [string]$PreferredCollector = ''
    )

    $files = New-Object System.Collections.Generic.List[string]
    $mainXml = Join-Path $DataRoot 'cards.xml'
    if (Test-Path -LiteralPath $mainXml -PathType Leaf) { $files.Add($mainXml) }

    $customsets = Join-Path $DataRoot 'customsets'
    if (Test-Path -LiteralPath $customsets -PathType Container) {
        foreach ($f in Get-ChildItem -LiteralPath $customsets -Filter '*.xml' -File -ErrorAction SilentlyContinue) {
            $files.Add($f.FullName)
        }
    }

    $candidates = New-Object System.Collections.Generic.List[object]

    foreach ($path in $files) {
        $settings = New-Object System.Xml.XmlReaderSettings
        $settings.IgnoreComments = $true
        $settings.IgnoreWhitespace = $true
        $settings.DtdProcessing = [System.Xml.DtdProcessing]::Prohibit

        $reader = $null
        try {
            $reader = [System.Xml.XmlReader]::Create($path, $settings)

            while ($reader.Read()) {
                if ($reader.NodeType -ne [System.Xml.XmlNodeType]::Element -or $reader.Name -ne 'card') {
                    continue
                }

                $sub = $reader.ReadSubtree()
                $name = $null
                $sets = New-Object System.Collections.Generic.List[object]

                try {
                    while ($sub.Read()) {
                        if ($sub.NodeType -ne [System.Xml.XmlNodeType]::Element) { continue }

                        if ($sub.Name -eq 'name' -and -not $name) {
                            $name = $sub.ReadElementContentAsString()
                            continue
                        }

                        if ($sub.Name -eq 'set' -and $name -and $name -ieq $CardName) {
                            $setCode = $sub.ReadElementContentAsString()
                            # ReadElementContentAsString advances beyond the node, so
                            # attributes must be captured before calling it. This
                            # branch is retained only for schema compatibility.
                        }
                    }
                }
                finally {
                    $sub.Dispose()
                }

                if ($name -and $name -ieq $CardName) {
                    # Re-read this one card block with XElement so attributes on
                    # <set> are easy to capture. Card blocks are tiny even when
                    # the overall cards.xml is very large.
                    break
                }
            }
        }
        catch { }
        finally {
            if ($reader) { $reader.Dispose() }
        }

        # Targeted raw-text extraction avoids loading the entire cards.xml DOM.
        try {
            $textReader = [System.IO.StreamReader]::new($path, [System.Text.Encoding]::UTF8, $true, 65536)
            try {
                $inside = $false
                $block = New-Object System.Text.StringBuilder
                while (($line = $textReader.ReadLine()) -ne $null) {
                    if (-not $inside) {
                        if ($line -match '<card(?:\s[^>]*)?>') {
                            $inside = $true
                            [void]$block.Clear()
                            [void]$block.AppendLine($line)
                        }
                        continue
                    }

                    [void]$block.AppendLine($line)
                    if ($line -notmatch '</card>') { continue }

                    $cardText = $block.ToString()
                    $inside = $false

                    $nm = [regex]::Match($cardText, '<name>(?<n>.*?)</name>', [System.Text.RegularExpressions.RegexOptions]::Singleline)
                    if (-not $nm.Success) { continue }

                    $decodedName = [System.Net.WebUtility]::HtmlDecode($nm.Groups['n'].Value)
                    if ($decodedName -ine $CardName) { continue }

                    $setMatches = [regex]::Matches(
                        $cardText,
                        '<set(?<attrs>[^>]*)>(?<code>.*?)</set>',
                        [System.Text.RegularExpressions.RegexOptions]::Singleline
                    )

                    foreach ($sm in $setMatches) {
                        $attrs = $sm.Groups['attrs'].Value
                        $code = [System.Net.WebUtility]::HtmlDecode($sm.Groups['code'].Value.Trim())

                        function Attr([string]$n) {
                            $m = [regex]::Match($attrs, '\b' + [regex]::Escape($n) + '\s*=\s*"(?<v>[^"]*)"')
                            if ($m.Success) { return [System.Net.WebUtility]::HtmlDecode($m.Groups['v'].Value) }
                            return ''
                        }

                        $uuid = Attr 'uuid'
                        $num = Attr 'num'
                        $online = Attr 'isOnlineOnly'

                        $score = 0
                        if ($uuid) { $score += 100 }
                        if (-not $online -or $online -notmatch '^(?i:true|1)$') { $score += 20 }
                        if ($PreferredSet -and $code -ieq $PreferredSet) { $score += 1000 }
                        if ($PreferredCollector -and $num -ieq $PreferredCollector) { $score += 500 }

                        $candidates.Add([pscustomobject]@{
                            SetCode = $code
                            CollectorNumber = $num
                            UUID = $uuid
                            Score = $score
                            Source = $path
                        })
                    }

                    break
                }
            }
            finally {
                $textReader.Dispose()
            }
        }
        catch { }
    }

    if ($candidates.Count -eq 0) { return $null }
    return ($candidates | Sort-Object Score -Descending | Select-Object -First 1)
}

function Split-Tags {
    param([string]$Text)

    if ([string]::IsNullOrWhiteSpace($Text)) { return @() }

    return @(
        $Text -split '[;\r\n]+' |
            ForEach-Object { $_.Trim() } |
            Where-Object { $_ } |
            Select-Object -Unique
    )
}

# =============================================================================
# Validation / merging
# =============================================================================

function Validate-Entries($Entries) {
    if (-not $Script:CardIndex) {
        throw 'Cockatrice card database is not loaded. Select a valid Cockatrice decks folder containing a parent cards.xml, then try again.'
    }

    foreach ($e in $Entries) {
        $name = Clean-ExportedCardName $e.Name

        # Ensure these optional fields exist for preview/reporting.
        if (-not $e.PSObject.Properties['OriginalName']) {
            $e | Add-Member -NotePropertyName OriginalName -NotePropertyValue ''
        }
        if (-not $e.PSObject.Properties['AutoCorrected']) {
            $e | Add-Member -NotePropertyName AutoCorrected -NotePropertyValue $false
        }
        if (-not $e.PSObject.Properties['CorrectionReason']) {
            $e | Add-Member -NotePropertyName CorrectionReason -NotePropertyValue ''
        }

        $e.OriginalName = ''
        $e.AutoCorrected = $false
        $e.CorrectionReason = ''

        # 1) Exact Cockatrice name always wins.
        if ($Script:CardIndex.ContainsKey($name)) {
            $e.Name = $Script:CardIndex[$name]
            $e.Valid = $true
            $e.Suggestion = ''
            continue
        }

        # 2) Flavor / alternate printing names map to the canonical real card.
        $flavorCanonical = Resolve-FlavorNameAliasLive -Name $name
        if ($flavorCanonical -and $Script:CardIndex.ContainsKey($flavorCanonical)) {
            $e.OriginalName = $name
            $e.Name = $Script:CardIndex[$flavorCanonical]
            $e.Valid = $true
            $e.Suggestion = ''
            $e.AutoCorrected = $true
            $e.CorrectionReason = 'Flavor name alias'
            continue
        }

        # 3) Online services such as Moxfield can provide transform/MDFC names as:
        #
        #      Front Face // Back Face
        #
        # Cockatrice's own online loader writes many of these to .cod using only
        # the canonical front-face name.  Only collapse the name when the full
        # imported name does NOT exist but the front-face name DOES exist.
        #
        # This intentionally preserves true Cockatrice names containing " // "
        # when the complete name is present in cards.xml.
        if ($name -match '^(?<front>.+?)\s*//\s*(?<back>.+)$') {
            $frontName = $Matches['front'].Trim()

            if ($frontName -and $Script:CardIndex.ContainsKey($frontName)) {
                $e.OriginalName = $name
                $e.Name = $Script:CardIndex[$frontName]
                $e.Valid = $true
                $e.Suggestion = ''
                $e.AutoCorrected = $true
                $e.CorrectionReason = 'Front-face canonical name'
                continue
            }
        }

        $e.Name = $name
        $e.Valid = $false
        $suggestions = @(Find-CardSuggestions $name)
        $e.Suggestion = $suggestions -join ' | '
    }
}

function Merge-Entries($Entries) {
    $dict = New-Object 'System.Collections.Generic.Dictionary[string,object]' ([System.StringComparer]::OrdinalIgnoreCase)

    foreach ($e in $Entries) {
        $key = $e.Zone + [char]31 + $e.Name
        if ($dict.ContainsKey($key)) {
            $dict[$key].Qty += [int]$e.Qty
        }
        else {
            $dict[$key] = [pscustomobject]@{
                Qty = [int]$e.Qty
                Name = [string]$e.Name
                Zone = [string]$e.Zone
                Valid = [bool]$e.Valid
                Suggestion = [string]$e.Suggestion
                PrintingSet = if ($e.PSObject.Properties['PrintingSet']) { [string]$e.PrintingSet } else { '' }
                PrintingCollector = if ($e.PSObject.Properties['PrintingCollector']) { [string]$e.PrintingCollector } else { '' }
                PrintingUUID = if ($e.PSObject.Properties['PrintingUUID']) { [string]$e.PrintingUUID } else { '' }
            }
        }
    }

    return @($dict.Values | Sort-Object Zone, Name)
}


function Get-LooseCardKey {
    param([string]$Name)

    if ([string]::IsNullOrWhiteSpace($Name)) { return '' }

    # Commander helper only:
    # ignore punctuation/spacing/case, but preserve letters and digits.
    # This lets:
    #   Ognis the Dragon's Lash
    # safely match:
    #   Ognis, the Dragon's Lash
    return ([regex]::Replace($Name.ToLowerInvariant(), '[^\p{L}\p{N}]', ''))
}

function Resolve-CardNameSmart {
    param([string]$InputName)

    if ([string]::IsNullOrWhiteSpace($InputName)) { return $null }

    $trimmed = $InputName.Trim()

    # Exact Cockatrice spelling always wins.
    if ($Script:CardIndex.ContainsKey($trimmed)) {
        return $Script:CardIndex[$trimmed]
    }

    # Flavor/alternate printing name -> canonical real card name.
    $flavorCanonical = Resolve-FlavorNameAliasLive -Name $trimmed
    if ($flavorCanonical -and $Script:CardIndex.ContainsKey($flavorCanonical)) {
        return $Script:CardIndex[$flavorCanonical]
    }

    # Safe punctuation-insensitive fallback.
    $key = Get-LooseCardKey $trimmed
    if (-not $key) { return $null }

    $matches = New-Object System.Collections.Generic.List[string]
    foreach ($canonical in $Script:CardIndex.Keys) {
        if ((Get-LooseCardKey $canonical) -eq $key) {
            $matches.Add($canonical)
            if ($matches.Count -gt 1) { break }
        }
    }

    # Auto-correct only when there is exactly one possible Cockatrice card.
    if ($matches.Count -eq 1) {
        return $matches[0]
    }

    return $null
}

function Apply-CommanderField {
    param($Entries, [string]$CommanderText)

    # IMPORTANT: commas are valid card-name punctuation.
    # Multiple commanders must be separated with semicolon or new line.
    $names = @(
        $CommanderText -split '[;\r\n]+' |
            ForEach-Object { $_.Trim() } |
            Where-Object { $_ }
    )

    if ($names.Count -eq 0) { return @($Entries) }

    foreach ($typedName in $names) {
        $canonical = Resolve-CardNameSmart -InputName $typedName

        # If no safe canonical match exists, retain the typed name so validation
        # reports it clearly instead of silently guessing.
        if (-not $canonical) {
            $canonical = $typedName
        }

        # First try exact canonical match in parsed deck.
        $matches = @($Entries | Where-Object { $_.Name -ieq $canonical })

        # If an imported list itself lost punctuation, try the same safe loose key
        # against parsed entries before adding anything new.
        if ($matches.Count -eq 0) {
            $wantedKey = Get-LooseCardKey $canonical
            $looseMatches = @(
                $Entries | Where-Object {
                    (Get-LooseCardKey $_.Name) -eq $wantedKey
                }
            )

            if ($looseMatches.Count -eq 1) {
                $looseMatches[0].Name = $canonical
                $matches = @($looseMatches[0])
            }
        }

        if ($matches.Count -gt 0) {
            # Move the existing deck copy to Commander. Do NOT add another card.
            foreach ($e in $matches) {
                $e.Name = $canonical
                $e.Zone = 'commander'
            }
        }
        else {
            # Commander is genuinely absent from parsed deck, so add one.
            $new = New-Entry -Qty 1 -Name $canonical -Zone 'commander' -Source 'Commander field'

            if ($Script:CardIndex.ContainsKey($canonical)) {
                $new.Name = $Script:CardIndex[$canonical]
                $new.Valid = $true
            }

            $Entries += $new
        }
    }

    return @($Entries)
}

# =============================================================================
# Cockatrice COD creation / verification
# =============================================================================

function Write-CardPrintingAttributes {
    param(
        [Parameter(Mandatory=$true)]$Writer,
        $Entry,
        [string]$DataRoot,
        [switch]$CommanderFallback
    )

    $setCode = ''
    $collector = ''
    $uuid = ''

    if ($Entry.PSObject.Properties['PrintingSet']) { $setCode = [string]$Entry.PrintingSet }
    if ($Entry.PSObject.Properties['PrintingCollector']) { $collector = [string]$Entry.PrintingCollector }
    if ($Entry.PSObject.Properties['PrintingUUID']) { $uuid = [string]$Entry.PrintingUUID }

    # Existing/selected printing metadata always wins.
    # Only commanders fall back to Cockatrice's preferred printing because
    # bannerCard/providerId historically used that behavior in this app.
    if ($CommanderFallback -and -not $uuid -and -not $setCode -and -not $collector) {
        try {
            $preferred = Get-PreferredPrinting -DataRoot $DataRoot -CardName ([string]$Entry.Name)
            if ($preferred) {
                $setCode = [string]$preferred.SetCode
                $collector = [string]$preferred.CollectorNumber
                $uuid = [string]$preferred.UUID
            }
        }
        catch {}
    }

    if ($setCode) { $Writer.WriteAttributeString('setShortName', $setCode) }
    if ($collector) { $Writer.WriteAttributeString('collectorNumber', $collector) }
    if ($uuid) { $Writer.WriteAttributeString('uuid', $uuid) }

    return [pscustomobject]@{
        SetCode = $setCode
        CollectorNumber = $collector
        UUID = $uuid
    }
}

function Write-Cod {
    param(
        [Parameter(Mandatory=$true)][string]$Path,
        [Parameter(Mandatory=$true)][string]$DeckName,
        [string]$Format,
        [string]$Comments,
        [string[]]$Tags,
        [Parameter(Mandatory=$true)]$Entries,
        [Parameter(Mandatory=$true)][string]$DataRoot
    )

    $merged = @(Merge-Entries $Entries)
    $commanders = @($merged | Where-Object { $_.Zone -eq 'commander' })
    $primaryCommander = if ($commanders.Count -gt 0) { $commanders[0] } else { $null }

    $settings = New-Object System.Xml.XmlWriterSettings
    $settings.Indent = $true
    $settings.IndentChars = '    '
    $settings.Encoding = New-Object System.Text.UTF8Encoding($false)
    $settings.NewLineChars = "`r`n"

    $writer = [System.Xml.XmlWriter]::Create($Path, $settings)
    try {
        $writer.WriteStartDocument()
        $writer.WriteStartElement('cockatrice_deck')
        $writer.WriteAttributeString('version','1')

        $writer.WriteElementString(
            'lastLoadedTimestamp',
            (Get-Date).ToString('ddd MMM dd HH:mm:ss yyyy', [System.Globalization.CultureInfo]::InvariantCulture)
        )

        $writer.WriteElementString('deckname', $DeckName)

        $formatOut = if ([string]::IsNullOrWhiteSpace($Format)) { '' } else { $Format.Trim().ToLowerInvariant() }
        $writer.WriteElementString('format', $formatOut)

        if ($primaryCommander) {
            $bannerUUID = ''
            if ($primaryCommander.PSObject.Properties['PrintingUUID']) {
                $bannerUUID = [string]$primaryCommander.PrintingUUID
            }

            if (-not $bannerUUID) {
                try {
                    $fallback = Get-PreferredPrinting -DataRoot $DataRoot -CardName $primaryCommander.Name
                    if ($fallback) { $bannerUUID = [string]$fallback.UUID }
                }
                catch {}
            }

            $writer.WriteStartElement('bannerCard')
            if ($bannerUUID) {
                $writer.WriteAttributeString('providerId', $bannerUUID)
            }
            $writer.WriteString([string]$primaryCommander.Name)
            $writer.WriteEndElement()
        }

        $writer.WriteElementString('comments', $Comments)

        $writer.WriteStartElement('tags')
        foreach ($tag in @($Tags)) {
            if (-not [string]::IsNullOrWhiteSpace($tag)) {
                $writer.WriteElementString('tag', $tag.Trim())
            }
        }
        $writer.WriteEndElement()

        $writer.WriteStartElement('zone')
        $writer.WriteAttributeString('name','main')
        foreach ($e in ($merged | Where-Object { $_.Zone -eq 'main' } | Sort-Object Name)) {
            $writer.WriteStartElement('card')
            $writer.WriteAttributeString('number', [string]$e.Qty)
            $writer.WriteAttributeString('name', [string]$e.Name)
            [void](Write-CardPrintingAttributes -Writer $writer -Entry $e -DataRoot $DataRoot)
            $writer.WriteEndElement()
        }
        $writer.WriteEndElement()

        $writer.WriteStartElement('zone')
        $writer.WriteAttributeString('name','side')

        foreach ($e in ($merged | Where-Object { $_.Zone -in @('commander','side') } |
            Sort-Object @{Expression={ if ($_.Zone -eq 'commander') {0}else{1} }}, Name)) {

            $writer.WriteStartElement('card')
            $writer.WriteAttributeString('number', [string]$e.Qty)
            $writer.WriteAttributeString('name', [string]$e.Name)

            if ($e.Zone -eq 'commander') {
                [void](Write-CardPrintingAttributes -Writer $writer -Entry $e -DataRoot $DataRoot -CommanderFallback)
            }
            else {
                [void](Write-CardPrintingAttributes -Writer $writer -Entry $e -DataRoot $DataRoot)
            }

            $writer.WriteEndElement()
        }

        $writer.WriteEndElement()
        $writer.WriteEndElement()
        $writer.WriteEndDocument()
    }
    finally {
        $writer.Dispose()
    }
}


function Verify-CodPrintingMetadata {
    param(
        [Parameter(Mandatory=$true)][string]$Path,
        [Parameter(Mandatory=$true)]$ExpectedEntries
    )

    $problems = New-Object System.Collections.Generic.List[string]

    try {
        [xml]$doc = Get-Content -LiteralPath $Path -Raw

        $savedCards = New-Object System.Collections.Generic.List[object]
        foreach ($zone in @($doc.cockatrice_deck.zone)) {
            $zoneName = [string]$zone.name
            foreach ($card in @($zone.card)) {
                $logicalZone = if ($zoneName -eq 'side') { 'side' } else { $zoneName }
                $savedCards.Add([pscustomobject]@{
                    Name = [string]$card.name
                    Zone = $logicalZone
                    PrintingSet = [string]$card.setShortName
                    PrintingCollector = [string]$card.collectorNumber
                    PrintingUUID = [string]$card.uuid
                })
            }
        }

        foreach ($e in @($ExpectedEntries)) {
            $expectedSet = if ($e.PSObject.Properties['PrintingSet']) { [string]$e.PrintingSet } else { '' }
            $expectedCollector = if ($e.PSObject.Properties['PrintingCollector']) { [string]$e.PrintingCollector } else { '' }
            $expectedUUID = if ($e.PSObject.Properties['PrintingUUID']) { [string]$e.PrintingUUID } else { '' }

            # Only verify cards where the user/import explicitly selected a printing.
            if (-not $expectedSet -and -not $expectedCollector -and -not $expectedUUID) {
                continue
            }

            $savedZone = if ([string]$e.Zone -eq 'commander') { 'side' } else { [string]$e.Zone }
            $match = @($savedCards | Where-Object {
                $_.Name -ieq [string]$e.Name -and $_.Zone -ieq $savedZone
            } | Select-Object -First 1)

            if ($match.Count -eq 0) {
                $problems.Add("Could not verify selected art for missing saved card: $($e.Name)")
                continue
            }

            $m = $match[0]
            if ($expectedSet -and $m.PrintingSet -ne $expectedSet) {
                $problems.Add("Art set mismatch for $($e.Name): expected '$expectedSet', saved '$($m.PrintingSet)'")
            }
            if ($expectedCollector -and $m.PrintingCollector -ne $expectedCollector) {
                $problems.Add("Art collector mismatch for $($e.Name): expected '$expectedCollector', saved '$($m.PrintingCollector)'")
            }
            if ($expectedUUID -and $m.PrintingUUID -ne $expectedUUID) {
                $problems.Add("Art UUID mismatch for $($e.Name): expected '$expectedUUID', saved '$($m.PrintingUUID)'")
            }
        }
    }
    catch {
        $problems.Add("Printing metadata verification failed: $($_.Exception.Message)")
    }

    return $problems.ToArray()
}

function Verify-Cod {
    param(
        [Parameter(Mandatory=$true)][string]$Path,
        [Parameter(Mandatory=$true)]$ExpectedEntries
    )

    [xml]$xml = Get-Content -LiteralPath $Path -Raw
    $expected = @(Merge-Entries $ExpectedEntries)

    $commanders = @($expected | Where-Object Zone -eq 'commander')

    $actual = New-Object 'System.Collections.Generic.Dictionary[string,int]' ([System.StringComparer]::OrdinalIgnoreCase)

    foreach ($zone in @($xml.cockatrice_deck.zone)) {
        $physicalZone = [string]$zone.name

        foreach ($card in @($zone.card)) {
            $name = [string]$card.name
            $qty = [int]$card.number

            $logicalZone = $physicalZone
            if ($physicalZone -eq 'side' -and
                @($commanders | Where-Object { $_.Name -ieq $name }).Count -gt 0) {
                $logicalZone = 'commander'
            }

            $key = $logicalZone + [char]31 + $name
            if ($actual.ContainsKey($key)) { $actual[$key] += $qty }
            else { $actual[$key] = $qty }
        }
    }

    $problems = New-Object System.Collections.Generic.List[string]

    foreach ($e in $expected) {
        $key = $e.Zone + [char]31 + $e.Name
        $have = if ($actual.ContainsKey($key)) { $actual[$key] } else { 0 }

        if ($have -ne [int]$e.Qty) {
            $problems.Add("$($e.Name) [$($e.Zone)]: expected $($e.Qty), saved $have")
        }
    }

    $expectedTotal = 0
    foreach ($e in $expected) { $expectedTotal += [int]$e.Qty }

    $actualTotal = 0
    foreach ($v in $actual.Values) { $actualTotal += $v }

    return [pscustomobject]@{
        Pass = ($problems.Count -eq 0 -and $expectedTotal -eq $actualTotal)
        ExpectedTotal = $expectedTotal
        ActualTotal = $actualTotal
        Problems = @($problems)
    }
}


# =============================================================================
# Cockatrice tag manager
# =============================================================================

$Script:KnownCockatriceTags = @(
    '🏃 Aggro',
    '🧙 Control',
    '⚔️ Midrange',
    '🌀 Combo',
    '🔨 Mill',
    '🔒 Stax',
    '🗺️ Landfall',
    '🛡️ Pillowfort',
    '🌱 Ramp',
    '⚡ Storm',
    '💀 Aristocrats',
    '☠️ Reanimator',
    '😈 Sacrifice',
    '🔥 Burn',
    '☀️ Lifegain',
    '🔮 Spellslinger',
    '👥 Tokens',
    '🎭 Blink',
    '⌛ Time Manipulation',
    '🌎 Domain',
    '🟡 Proliferate',
    '📜 Saga',
    '🎲 Chaos',
    '🪄 Auras',
    '🔫 Pingers',
    '👑 Monarch',
    '🚀 Vehicles',
    '💉 Infect',
    '🩸 Madness',
    '🌀 Morph',
    '⚔️ Creature',
    '💎 Artifact',
    '🟡 Enchantment',
    '📖 Sorcery',
    '⚡ Instant',
    '🌌 Planeswalker',
    '🌍 Land',
    '🪄 Aura',
    '🐉 Kindred',
    '🧙 Humans',
    '⚔️ Soldiers',
    '🛡️ Knights',
    '🎸 Bards',
    '🧝 Elves',
    '🌲 Dryads',
    '😇 Angels',
    '🎩 Wizards',
    '🧛 Vampires',
    '🦴 Skeletons',
    '💀 Zombies',
    '😈 Demons',
    '👾 Eldrazi',
    '🐉 Dragons',
    '🐟 Merfolk',
    '🐱 Cats',
    '🐺 Wolves',
    '🐺 Werewolves',
    '🦇 Bats',
    '🐀 Rats',
    '🦅 Birds',
    '🦗 Insects',
    '🍄 Fungus',
    '🐚 Sea Creatures',
    '🐗 Boars',
    '🦊 Foxes',
    '🦄 Unicorns',
    '🐘 Elephants',
    '🐻 Bears',
    '🦏 Rhinos',
    '🦂 Scorpions'
)

function Get-PlainTagName {
    param([string]$Tag)
    if ([string]::IsNullOrWhiteSpace($Tag)) { return '' }

    # Strip leading emoji/symbol prefix while preserving normal custom tags.
    $s = $Tag.Trim()
    $m = [regex]::Match($s, '^[^\p{L}\p{N}]*\s*(?<name>.+)$')
    if ($m.Success) { return $m.Groups['name'].Value.Trim() }
    return $s
}

function Get-CardMetadataForNames {
    param(
        [Parameter(Mandatory=$true)][string]$DataRoot,
        [Parameter(Mandatory=$true)][string[]]$Names
    )

    $wanted = New-Object 'System.Collections.Generic.HashSet[string]' ([System.StringComparer]::OrdinalIgnoreCase)
    foreach ($n in $Names) {
        if (-not [string]::IsNullOrWhiteSpace($n)) { [void]$wanted.Add($n.Trim()) }
    }

    $result = New-Object 'System.Collections.Generic.Dictionary[string,object]' ([System.StringComparer]::OrdinalIgnoreCase)
    if ($wanted.Count -eq 0) { return $result }

    $files = New-Object System.Collections.Generic.List[string]
    $mainXml = Join-Path $DataRoot 'cards.xml'
    if (Test-Path -LiteralPath $mainXml -PathType Leaf) { $files.Add($mainXml) }

    $customsets = Join-Path $DataRoot 'customsets'
    if (Test-Path -LiteralPath $customsets -PathType Container) {
        foreach ($f in Get-ChildItem -LiteralPath $customsets -Filter '*.xml' -File -ErrorAction SilentlyContinue) {
            $files.Add($f.FullName)
        }
    }

    foreach ($path in $files) {
        if ($result.Count -ge $wanted.Count) { break }

        $settings = New-Object System.Xml.XmlReaderSettings
        $settings.IgnoreComments = $true
        $settings.IgnoreWhitespace = $true
        $settings.DtdProcessing = [System.Xml.DtdProcessing]::Prohibit

        $reader = $null
        try {
            $reader = [System.Xml.XmlReader]::Create($path, $settings)
            while ($reader.Read()) {
                if ($reader.NodeType -ne [System.Xml.XmlNodeType]::Element -or $reader.Name -ne 'card') {
                    continue
                }

                $sub = $reader.ReadSubtree()
                $name = ''
                $type = ''
                $text = ''
                $maintype = ''
                $subtype = ''

                try {
                    while ($sub.Read()) {
                        if ($sub.NodeType -ne [System.Xml.XmlNodeType]::Element) { continue }

                        switch ($sub.Name) {
                            'name' {
                                if (-not $name) { $name = $sub.ReadElementContentAsString() }
                            }
                            'type' {
                                if (-not $type) { $type = $sub.ReadElementContentAsString() }
                            }
                            'maintype' {
                                if (-not $maintype) { $maintype = $sub.ReadElementContentAsString() }
                            }
                            'subtype' {
                                if (-not $subtype) { $subtype = $sub.ReadElementContentAsString() }
                            }
                            'text' {
                                if (-not $text) { $text = $sub.ReadElementContentAsString() }
                            }
                        }
                    }
                }
                finally {
                    $sub.Dispose()
                }

                if ($name -and $wanted.Contains($name) -and -not $result.ContainsKey($name)) {
                    $result[$name] = [pscustomobject]@{
                        Name = $name
                        Type = $type
                        MainType = $maintype
                        SubType = $subtype
                        Text = $text
                    }
                }
            }
        }
        catch { }
        finally {
            if ($reader) { $reader.Dispose() }
        }
    }

    return $result
}

function Get-SmartTagSuggestions {
    param(
        [Parameter(Mandatory=$true)][string]$DataRoot,
        [Parameter(Mandatory=$true)]$Entries
    )

    $merged = @(Merge-Entries $Entries)
    $names = @($merged | Select-Object -ExpandProperty Name -Unique)
    $meta = Get-CardMetadataForNames -DataRoot $DataRoot -Names $names

    $scores = @{}

    function Add-Score([string]$Tag, [int]$Amount) {
        if (-not $scores.ContainsKey($Tag)) { $scores[$Tag] = 0 }
        $scores[$Tag] += $Amount
    }

    $creatureSubtypes = @{}
    $typeCounts = @{
        Creature=0; Artifact=0; Enchantment=0; Sorcery=0; Instant=0; Planeswalker=0; Land=0
    }

    foreach ($e in $merged) {
        if (-not $meta.ContainsKey($e.Name)) { continue }
        $m = $meta[$e.Name]
        $qty = [int]$e.Qty
        $typeBlob = ("$($m.Type) $($m.MainType)").Trim()
        $text = [string]$m.Text
        $sub = [string]$m.SubType

        foreach ($t in @('Creature','Artifact','Enchantment','Sorcery','Instant','Planeswalker','Land')) {
            if ($typeBlob -match "(?i)\b$([regex]::Escape($t))\b") {
                $typeCounts[$t] += $qty
            }
        }

        if ($typeBlob -match '(?i)\bAura\b' -or $sub -match '(?i)\bAura\b') {
            Add-Score '🪄 Aura' (2 * $qty)
            Add-Score '🪄 Auras' (2 * $qty)
        }

        if ($text -match '(?i)\bcreate\b.*\btoken\b|\btoken copy\b|\btokens?\b') {
            Add-Score '👥 Tokens' (2 * $qty)
        }
        if ($text -match '(?i)\bproliferate\b') { Add-Score '🟡 Proliferate' (5 * $qty) }
        if ($text -match '(?i)\bmonarch\b') { Add-Score '👑 Monarch' (5 * $qty) }
        if ($text -match '(?i)\blandfall\b') { Add-Score '🗺️ Landfall' (5 * $qty) }
        if ($text -match '(?i)\bmadness\b') { Add-Score '🩸 Madness' (5 * $qty) }
        if ($text -match '(?i)\bmorph\b|\bmanifest\b|\bdisguise\b|\bcloak\b') { Add-Score '🌀 Morph' (3 * $qty) }
        if ($text -match '(?i)\bmill\b') { Add-Score '🔨 Mill' (3 * $qty) }
        if ($text -match '(?i)\bgain\b.{0,20}\blife\b|\blifelink\b') { Add-Score '☀️ Lifegain' (2 * $qty) }
        if ($text -match '(?i)\bdiscard\b' -and $text -match '(?i)\byour\b') { Add-Score '🩸 Madness' $qty }
        if ($text -match '(?i)\bsacrifice\b') {
            Add-Score '😈 Sacrifice' (2 * $qty)
            Add-Score '💀 Aristocrats' $qty
        }
        if ($text -match '(?i)\breturn\b.*\bgraveyard\b.*\bbattlefield\b|\breanimate\b') {
            Add-Score '☠️ Reanimator' (3 * $qty)
        }
        if ($text -match '(?i)\bwhenever\b.*\binstant\b|\bwhenever\b.*\bsorcery\b|\bcast\b.*\binstant\b.*\bsorcery\b') {
            Add-Score '🔮 Spellslinger' (2 * $qty)
        }
        if ($text -match '(?i)\badditional turn\b|\bextra turn\b') {
            Add-Score '⌛ Time Manipulation' (5 * $qty)
        }
        if ($text -match '(?i)\brandom\b|\bcoin flip\b|\broll a d20\b|\broll\b.*\bdie\b') {
            Add-Score '🎲 Chaos' (2 * $qty)
        }
        if ($text -match '(?i)\bvehicle\b|\bcrew\b') { Add-Score '🚀 Vehicles' (2 * $qty) }
        if ($text -match '(?i)\binfect\b|\bpoison counter\b|\btoxic\b') { Add-Score '💉 Infect' (3 * $qty) }
        if ($text -match '(?i)\bblink\b|\bexile\b.*\breturn\b.*\bbattlefield\b') { Add-Score '🎭 Blink' (2 * $qty) }
        if ($text -match '(?i)\badd\b.*\{[WUBRGC]\}|\bsearch your library for (?:a|up to .*?) land\b') { Add-Score '🌱 Ramp' $qty }
        if ($text -match '(?i)\bdeal\b.*\bdamage\b.*\bany target\b|\bdeals? 1 damage\b') { Add-Score '🔫 Pingers' $qty }
        if ($text -match '(?i)\bcan''t attack\b|\bunless their controller pays\b|\bprevent all combat damage\b') { Add-Score '🛡️ Pillowfort' $qty }

        if ($sub) {
            foreach ($tribe in @(
                'Human','Soldier','Knight','Bard','Elf','Dryad','Angel','Wizard','Vampire',
                'Skeleton','Zombie','Demon','Eldrazi','Dragon','Merfolk','Cat','Wolf','Werewolf',
                'Bat','Rat','Bird','Insect','Fungus','Boar','Fox','Unicorn','Elephant','Bear',
                'Rhino','Scorpion'
            )) {
                if ($sub -match "(?i)\b$tribe(?:s)?\b") {
                    if (-not $creatureSubtypes.ContainsKey($tribe)) { $creatureSubtypes[$tribe] = 0 }
                    $creatureSubtypes[$tribe] += $qty
                }
            }
        }
    }

    if ($typeCounts['Creature'] -ge 25) { Add-Score '⚔️ Creature' 10 }
    if ($typeCounts['Artifact'] -ge 12) { Add-Score '💎 Artifact' 10 }
    if ($typeCounts['Enchantment'] -ge 10) { Add-Score '🟡 Enchantment' 10 }
    if ($typeCounts['Sorcery'] -ge 10) { Add-Score '📖 Sorcery' 10 }
    if ($typeCounts['Instant'] -ge 10) { Add-Score '⚡ Instant' 10 }
    if ($typeCounts['Planeswalker'] -ge 5) { Add-Score '🌌 Planeswalker' 10 }
    if ($typeCounts['Land'] -ge 30) { Add-Score '🌍 Land' 5 }

    foreach ($tribe in $creatureSubtypes.Keys) {
        if ($creatureSubtypes[$tribe] -lt 8) { continue }

        $tag = switch ($tribe) {
            'Human' { '🧙 Humans' }
            'Soldier' { '⚔️ Soldiers' }
            'Knight' { '🛡️ Knights' }
            'Bard' { '🎸 Bards' }
            'Elf' { '🧝 Elves' }
            'Dryad' { '🌲 Dryads' }
            'Angel' { '😇 Angels' }
            'Wizard' { '🎩 Wizards' }
            'Vampire' { '🧛 Vampires' }
            'Skeleton' { '🦴 Skeletons' }
            'Zombie' { '💀 Zombies' }
            'Demon' { '😈 Demons' }
            'Eldrazi' { '👾 Eldrazi' }
            'Dragon' { '🐉 Dragons' }
            'Merfolk' { '🐟 Merfolk' }
            'Cat' { '🐱 Cats' }
            'Wolf' { '🐺 Wolves' }
            'Werewolf' { '🐺 Werewolves' }
            'Bat' { '🦇 Bats' }
            'Rat' { '🐀 Rats' }
            'Bird' { '🦅 Birds' }
            'Insect' { '🦗 Insects' }
            'Fungus' { '🍄 Fungus' }
            'Boar' { '🐗 Boars' }
            'Fox' { '🦊 Foxes' }
            'Unicorn' { '🦄 Unicorns' }
            'Elephant' { '🐘 Elephants' }
            'Bear' { '🐻 Bears' }
            'Rhino' { '🦏 Rhinos' }
            'Scorpion' { '🦂 Scorpions' }
        }

        if ($tag) {
            Add-Score $tag (10 + $creatureSubtypes[$tribe])
            Add-Score '🐉 Kindred' 10
        }
    }

    # Conservative thresholds. Smart tags are suggestions, never forced.
    $suggestions = @(
        foreach ($kv in $scores.GetEnumerator()) {
            if ($kv.Value -ge 8) {
                [pscustomobject]@{
                    Tag = $kv.Key
                    Score = [int]$kv.Value
                }
            }
        }
    ) | Sort-Object @{Expression='Score'; Descending=$true}, @{Expression='Tag'; Descending=$false}

    return @($suggestions)
}

function Show-TagManager {
    param(
        [string[]]$CurrentTags,
        $Entries,
        [string]$DataRoot
    )

    $dlg = New-Object System.Windows.Forms.Form
    $dlg.Text = 'Cockatrice Deck Tags'
    $dlg.StartPosition = 'CenterParent'
    $dlg.Size = New-Object System.Drawing.Size(650,760)
    $dlg.MinimumSize = New-Object System.Drawing.Size(560,620)
    $dlg.Font = New-Object System.Drawing.Font('Segoe UI',9)

    $topPanel = New-Object System.Windows.Forms.Panel
    $topPanel.Dock = 'Top'
    $topPanel.Height = 112
    $dlg.Controls.Add($topPanel)

    $lbl = New-Object System.Windows.Forms.Label
    $lbl.Text = 'Choose Cockatrice tags, use Smart Suggest, add your own, or select None.'
    $lbl.Location = New-Object System.Drawing.Point(10,10)
    $lbl.AutoSize = $true
    $topPanel.Controls.Add($lbl)

    $txtFilter = New-Object System.Windows.Forms.TextBox
    $txtFilter.Location = New-Object System.Drawing.Point(10,35)
    $txtFilter.Size = New-Object System.Drawing.Size(610,24)
    $topPanel.Controls.Add($txtFilter)

    $btnSmart = New-Object System.Windows.Forms.Button
    $btnSmart.Text = 'Smart Suggest'
    $btnSmart.Location = New-Object System.Drawing.Point(10,69)
    $btnSmart.Size = New-Object System.Drawing.Size(115,30)
    $topPanel.Controls.Add($btnSmart)

    $btnAllOff = New-Object System.Windows.Forms.Button
    $btnAllOff.Text = 'None / Clear'
    $btnAllOff.Location = New-Object System.Drawing.Point(135,69)
    $btnAllOff.Size = New-Object System.Drawing.Size(105,30)
    $topPanel.Controls.Add($btnAllOff)

    $btnSelectAll = New-Object System.Windows.Forms.Button
    $btnSelectAll.Text = 'Select All'
    $btnSelectAll.Location = New-Object System.Drawing.Point(250,69)
    $btnSelectAll.Size = New-Object System.Drawing.Size(95,30)
    $topPanel.Controls.Add($btnSelectAll)

    $lblHint = New-Object System.Windows.Forms.Label
    $lblHint.Text = 'Smart suggestions are never automatic.'
    $lblHint.Location = New-Object System.Drawing.Point(360,76)
    $lblHint.AutoSize = $true
    $lblHint.ForeColor = [System.Drawing.Color]::DimGray
    $topPanel.Controls.Add($lblHint)

    $bottom = New-Object System.Windows.Forms.Panel
    $bottom.Dock = 'Bottom'
    $bottom.Height = 95
    $dlg.Controls.Add($bottom)

    $lblCustom = New-Object System.Windows.Forms.Label
    $lblCustom.Text = 'Custom tag:'
    $lblCustom.Location = New-Object System.Drawing.Point(10,8)
    $lblCustom.AutoSize = $true
    $bottom.Controls.Add($lblCustom)

    $txtCustom = New-Object System.Windows.Forms.TextBox
    $txtCustom.Location = New-Object System.Drawing.Point(90,6)
    $txtCustom.Size = New-Object System.Drawing.Size(350,24)
    $bottom.Controls.Add($txtCustom)

    $btnAddCustom = New-Object System.Windows.Forms.Button
    $btnAddCustom.Text = 'Add Custom'
    $btnAddCustom.Location = New-Object System.Drawing.Point(450,5)
    $btnAddCustom.Size = New-Object System.Drawing.Size(100,28)
    $bottom.Controls.Add($btnAddCustom)

    $btnOK = New-Object System.Windows.Forms.Button
    $btnOK.Text = 'Use Selected Tags'
    $btnOK.Location = New-Object System.Drawing.Point(350,50)
    $btnOK.Size = New-Object System.Drawing.Size(140,30)
    $btnOK.DialogResult = [System.Windows.Forms.DialogResult]::OK
    $bottom.Controls.Add($btnOK)

    $btnCancel = New-Object System.Windows.Forms.Button
    $btnCancel.Text = 'Cancel'
    $btnCancel.Location = New-Object System.Drawing.Point(500,50)
    $btnCancel.Size = New-Object System.Drawing.Size(85,30)
    $btnCancel.DialogResult = [System.Windows.Forms.DialogResult]::Cancel
    $bottom.Controls.Add($btnCancel)

    $list = New-Object System.Windows.Forms.CheckedListBox
    $list.Dock = 'Fill'
    $list.CheckOnClick = $true
    $list.HorizontalScrollbar = $true
    $dlg.Controls.Add($list)
    $list.BringToFront()

    $allTags = New-Object System.Collections.Generic.List[string]
    foreach ($t in $Script:KnownCockatriceTags) { $allTags.Add($t) }

    foreach ($t in @($CurrentTags)) {
        if ($t -and -not ($allTags -contains $t)) { $allTags.Add($t) }
    }

    function Rebuild-TagList([string]$Filter='') {
        $selected = @($list.CheckedItems | ForEach-Object { [string]$_ })
        $list.Items.Clear()

        foreach ($tag in $allTags) {
            if ($Filter -and $tag -notmatch [regex]::Escape($Filter)) { continue }

            $idx = $list.Items.Add($tag)
            if (($CurrentTags -contains $tag) -or ($selected -contains $tag)) {
                $list.SetItemChecked($idx, $true)
            }
        }
    }

    Rebuild-TagList

    $txtFilter.Add_TextChanged({
        Rebuild-TagList $txtFilter.Text.Trim()
    })

    $btnAllOff.Add_Click({
        for ($i=0; $i -lt $list.Items.Count; $i++) { $list.SetItemChecked($i,$false) }
        $CurrentTags = @()
    })

    $btnSelectAll.Add_Click({
        for ($i=0; $i -lt $list.Items.Count; $i++) { $list.SetItemChecked($i,$true) }
    })

    $btnAddCustom.Add_Click({
        $t = $txtCustom.Text.Trim()
        if (-not $t) { return }

        if (-not ($allTags -contains $t)) { $allTags.Add($t) }
        $txtFilter.Clear()
        Rebuild-TagList
        $idx = $list.Items.IndexOf($t)
        if ($idx -ge 0) { $list.SetItemChecked($idx,$true) }
        $txtCustom.Clear()
    })

    $btnSmart.Add_Click({
        if (-not $Entries -or -not $DataRoot) {
            [System.Windows.Forms.MessageBox]::Show(
                'Load/check the deck first so Smart Suggest can inspect it.',
                'Smart Tags',
                [System.Windows.Forms.MessageBoxButtons]::OK,
                [System.Windows.Forms.MessageBoxIcon]::Information
            ) | Out-Null
            return
        }

        $lblHint.Text = 'Analyzing deck...'
        [System.Windows.Forms.Application]::DoEvents()

        try {
            $sugs = @(Get-SmartTagSuggestions -DataRoot $DataRoot -Entries $Entries)
            if ($sugs.Count -eq 0) {
                $lblHint.Text = 'No strong tag suggestions found.'
                return
            }

            $suggestedTags = @($sugs | Select-Object -ExpandProperty Tag)
            $msg = "Suggested tags:`r`n`r`n" + (($sugs | ForEach-Object {
                "  $($_.Tag)  [score $($_.Score)]"
            }) -join "`r`n") + "`r`n`r`nSelect these tags?"

            $answer = [System.Windows.Forms.MessageBox]::Show(
                $msg,
                'Smart Tag Suggestions',
                [System.Windows.Forms.MessageBoxButtons]::YesNo,
                [System.Windows.Forms.MessageBoxIcon]::Question
            )

            if ($answer -eq [System.Windows.Forms.DialogResult]::Yes) {
                $txtFilter.Clear()
                Rebuild-TagList
                for ($i=0; $i -lt $list.Items.Count; $i++) {
                    if ($suggestedTags -contains [string]$list.Items[$i]) {
                        $list.SetItemChecked($i,$true)
                    }
                }
                $lblHint.Text = "$($suggestedTags.Count) suggestion(s) selected."
            }
            else {
                $lblHint.Text = 'Suggestions not applied.'
            }
        }
        catch {
            $lblHint.Text = 'Smart tag analysis failed.'
            [System.Windows.Forms.MessageBox]::Show(
                $_.Exception.Message,
                'Smart Tags',
                [System.Windows.Forms.MessageBoxButtons]::OK,
                [System.Windows.Forms.MessageBoxIcon]::Error
            ) | Out-Null
        }
    })

    $dlg.AcceptButton = $btnOK
    $dlg.CancelButton = $btnCancel

    if ($dlg.ShowDialog() -ne [System.Windows.Forms.DialogResult]::OK) {
        return $null
    }

    return @($list.CheckedItems | ForEach-Object { [string]$_ })
}


function Show-CommanderPicker {
    param(
        $Entries,
        [string[]]$CurrentCommanders
    )

    if (-not $Entries -or @($Entries).Count -eq 0) {
        [System.Windows.Forms.MessageBox]::Show(
            'Load Deck the deck first so there are cards to choose from.',
            'Select Commander',
            [System.Windows.Forms.MessageBoxButtons]::OK,
            [System.Windows.Forms.MessageBoxIcon]::Information
        ) | Out-Null
        return $null
    }

    $merged = @(Merge-Entries $Entries)

    $dlg = New-Object System.Windows.Forms.Form
    $dlg.Text = 'Select Commander from Deck'
    $dlg.StartPosition = 'CenterParent'
    $dlg.Size = New-Object System.Drawing.Size(600,700)
    $dlg.MinimumSize = New-Object System.Drawing.Size(500,560)
    $dlg.Font = New-Object System.Drawing.Font('Segoe UI',9)

    $top = New-Object System.Windows.Forms.Panel
    $top.Dock = 'Top'
    $top.Height = 210
    $dlg.Controls.Add($top)

    $lbl = New-Object System.Windows.Forms.Label
    $lbl.Text = 'Select one or more cards already in this deck.'
    $lbl.Location = New-Object System.Drawing.Point(10,8)
    $lbl.AutoSize = $true
    $top.Controls.Add($lbl)

    $filter = New-Object System.Windows.Forms.TextBox
    $filter.Location = New-Object System.Drawing.Point(10,34)
    $filter.Size = New-Object System.Drawing.Size(560,24)
    $top.Controls.Add($filter)

    $bottom = New-Object System.Windows.Forms.Panel
    $bottom.Dock = 'Bottom'
    $bottom.Height = 58
    $dlg.Controls.Add($bottom)

    $btnNone = New-Object System.Windows.Forms.Button
    $btnNone.Text = 'No Commander'
    $btnNone.Location = New-Object System.Drawing.Point(10,14)
    $btnNone.Size = New-Object System.Drawing.Size(115,30)
    $bottom.Controls.Add($btnNone)

    $btnOK = New-Object System.Windows.Forms.Button
    $btnOK.Text = 'Use Selection'
    $btnOK.Location = New-Object System.Drawing.Point(385,14)
    $btnOK.Size = New-Object System.Drawing.Size(105,30)
    $btnOK.DialogResult = [System.Windows.Forms.DialogResult]::OK
    $bottom.Controls.Add($btnOK)

    $btnCancel = New-Object System.Windows.Forms.Button
    $btnCancel.Text = 'Cancel'
    $btnCancel.Location = New-Object System.Drawing.Point(500,14)
    $btnCancel.Size = New-Object System.Drawing.Size(75,30)
    $btnCancel.DialogResult = [System.Windows.Forms.DialogResult]::Cancel
    $bottom.Controls.Add($btnCancel)

    $list = New-Object System.Windows.Forms.CheckedListBox
    $list.Dock = 'Fill'
    $list.CheckOnClick = $true
    $list.HorizontalScrollbar = $true
    $dlg.Controls.Add($list)
    $list.BringToFront()

    $allNames = @($merged | Sort-Object Name | Select-Object -ExpandProperty Name -Unique)

    function Rebuild-CommanderList([string]$FilterText='') {
        $checkedNow = @($list.CheckedItems | ForEach-Object { [string]$_ })
        $list.Items.Clear()

        foreach ($name in $allNames) {
            if ($FilterText -and $name -notmatch [regex]::Escape($FilterText)) { continue }
            $idx = $list.Items.Add($name)

            if (($CurrentCommanders -contains $name) -or ($checkedNow -contains $name)) {
                $list.SetItemChecked($idx, $true)
            }
        }
    }

    Rebuild-CommanderList

    $filter.Add_TextChanged({
        Rebuild-CommanderList $filter.Text.Trim()
    })

    $btnNone.Add_Click({
        for ($i=0; $i -lt $list.Items.Count; $i++) {
            $list.SetItemChecked($i,$false)
        }
        $Script:CommanderPickerCleared = $true
        $dlg.DialogResult = [System.Windows.Forms.DialogResult]::OK
        $dlg.Close()
    })

    $dlg.AcceptButton = $btnOK
    $dlg.CancelButton = $btnCancel

    $Script:CommanderPickerCleared = $false

    if ($dlg.ShowDialog() -ne [System.Windows.Forms.DialogResult]::OK) {
        return $null
    }

    if ($Script:CommanderPickerCleared) {
        return @()
    }

    return @($list.CheckedItems | ForEach-Object { [string]$_ })
}


function Show-CommanderSetup {
    param(
        $Entries,
        [string]$CurrentPrimary = '',
        [string]$CurrentSecondary = '',
        [string]$CurrentCompanion = '',
        [string]$CurrentMode = 'Regular Commander'
    )

    $merged = @(Merge-Entries $Entries)

    $dlg = New-Object System.Windows.Forms.Form
    $dlg.Text = 'Commander Setup'
    $dlg.StartPosition = 'CenterParent'
    $dlg.Size = New-Object System.Drawing.Size(700,390)
    $dlg.MinimumSize = New-Object System.Drawing.Size(650,360)
    $dlg.Font = New-Object System.Drawing.Font('Segoe UI',9)

    $lblMode = New-Object System.Windows.Forms.Label
    $lblMode.Text = 'Commander Type'
    $lblMode.Location = New-Object System.Drawing.Point(14,14)
    $lblMode.AutoSize = $true
    $dlg.Controls.Add($lblMode)

    $cmbMode = New-Object System.Windows.Forms.ComboBox
    $cmbMode.Location = New-Object System.Drawing.Point(14,36)
    $cmbMode.Size = New-Object System.Drawing.Size(260,25)
    $cmbMode.DropDownStyle = 'DropDownList'
    [void]$cmbMode.Items.AddRange(@(
        'Regular Commander',
        'Partner',
        'Friends Forever',
        'Choose a Background',
        "Doctor + Doctor's Companion",
        'Partner With'
    ))
    $cmbMode.SelectedItem = $CurrentMode
    if ($cmbMode.SelectedIndex -lt 0) { $cmbMode.SelectedIndex = 0 }
    $dlg.Controls.Add($cmbMode)

    $lblPrimary = New-Object System.Windows.Forms.Label
    $lblPrimary.Text = 'Primary Commander'
    $lblPrimary.Location = New-Object System.Drawing.Point(14,78)
    $lblPrimary.AutoSize = $true
    $dlg.Controls.Add($lblPrimary)

    $txtPrimary = New-Object System.Windows.Forms.TextBox
    $txtPrimary.Location = New-Object System.Drawing.Point(14,100)
    $txtPrimary.Size = New-Object System.Drawing.Size(505,25)
    $txtPrimary.ReadOnly = $true
    $txtPrimary.Text = if ($CurrentPrimary) { $CurrentPrimary } else { '(None)' }
    $dlg.Controls.Add($txtPrimary)

    $btnPrimary = New-Object System.Windows.Forms.Button
    $btnPrimary.Text = 'Select...'
    $btnPrimary.Location = New-Object System.Drawing.Point(530,98)
    $btnPrimary.Size = New-Object System.Drawing.Size(120,29)
    $dlg.Controls.Add($btnPrimary)

    $lblSecondary = New-Object System.Windows.Forms.Label
    $lblSecondary.Text = 'Secondary Commander'
    $lblSecondary.Location = New-Object System.Drawing.Point(14,142)
    $lblSecondary.AutoSize = $true
    $dlg.Controls.Add($lblSecondary)

    $txtSecondary = New-Object System.Windows.Forms.TextBox
    $txtSecondary.Location = New-Object System.Drawing.Point(14,164)
    $txtSecondary.Size = New-Object System.Drawing.Size(505,25)
    $txtSecondary.ReadOnly = $true
    $txtSecondary.Text = if ($CurrentSecondary) { $CurrentSecondary } else { '(None)' }
    $dlg.Controls.Add($txtSecondary)

    $btnSecondary = New-Object System.Windows.Forms.Button
    $btnSecondary.Text = 'Select...'
    $btnSecondary.Location = New-Object System.Drawing.Point(530,162)
    $btnSecondary.Size = New-Object System.Drawing.Size(120,29)
    $dlg.Controls.Add($btnSecondary)

    $lblCompanion = New-Object System.Windows.Forms.Label
    $lblCompanion.Text = 'Companion (optional)'
    $lblCompanion.Location = New-Object System.Drawing.Point(14,206)
    $lblCompanion.AutoSize = $true
    $dlg.Controls.Add($lblCompanion)

    $txtCompanion = New-Object System.Windows.Forms.TextBox
    $txtCompanion.Location = New-Object System.Drawing.Point(14,228)
    $txtCompanion.Size = New-Object System.Drawing.Size(505,25)
    $txtCompanion.ReadOnly = $true
    $txtCompanion.Text = if ($CurrentCompanion) { $CurrentCompanion } else { '(None)' }
    $dlg.Controls.Add($txtCompanion)

    $btnCompanion = New-Object System.Windows.Forms.Button
    $btnCompanion.Text = 'Select...'
    $btnCompanion.Location = New-Object System.Drawing.Point(530,226)
    $btnCompanion.Size = New-Object System.Drawing.Size(120,29)
    $dlg.Controls.Add($btnCompanion)

    $lblInfo = New-Object System.Windows.Forms.Label
    $lblInfo.Location = New-Object System.Drawing.Point(14,270)
    $lblInfo.Size = New-Object System.Drawing.Size(636,38)
    $lblInfo.ForeColor = [System.Drawing.Color]::DimGray
    $dlg.Controls.Add($lblInfo)

    $btnOK = New-Object System.Windows.Forms.Button
    $btnOK.Text = 'Apply'
    $btnOK.Location = New-Object System.Drawing.Point(470,315)
    $btnOK.Size = New-Object System.Drawing.Size(85,30)
    $btnOK.DialogResult = [System.Windows.Forms.DialogResult]::OK
    $dlg.Controls.Add($btnOK)

    $btnCancel = New-Object System.Windows.Forms.Button
    $btnCancel.Text = 'Cancel'
    $btnCancel.Location = New-Object System.Drawing.Point(565,315)
    $btnCancel.Size = New-Object System.Drawing.Size(85,30)
    $btnCancel.DialogResult = [System.Windows.Forms.DialogResult]::Cancel
    $dlg.Controls.Add($btnCancel)

    function Update-CommanderSetupMode {
        $mode = [string]$cmbMode.SelectedItem

        switch ($mode) {
            'Regular Commander' {
                $lblSecondary.Text = 'Secondary Commander'
                $txtSecondary.Text = '(None)'
                $btnSecondary.Enabled = $false
                $lblInfo.Text = 'One commander. Companion remains optional and separate.'
            }
            'Partner' {
                $lblSecondary.Text = 'Partner Commander'
                $btnSecondary.Enabled = $true
                $lblInfo.Text = 'Use for commanders with Partner.'
            }
            'Friends Forever' {
                $lblSecondary.Text = 'Friends Forever Commander'
                $btnSecondary.Enabled = $true
                $lblInfo.Text = 'Use for commanders with Friends Forever.'
            }
            'Choose a Background' {
                $lblSecondary.Text = 'Background'
                $btnSecondary.Enabled = $true
                $lblInfo.Text = 'Primary commander + a Background. Companion remains optional.'
            }
            "Doctor + Doctor's Companion" {
                $lblSecondary.Text = "Doctor's Companion"
                $btnSecondary.Enabled = $true
                $lblInfo.Text = "Use a Doctor with a card that has Doctor's Companion."
            }
            'Partner With' {
                $lblSecondary.Text = 'Partner With'
                $btnSecondary.Enabled = $true
                $lblInfo.Text = 'Use the specifically named Partner With pairing.'
            }
        }
    }

    $cmbMode.Add_SelectedIndexChanged({ Update-CommanderSetupMode })
    Update-CommanderSetupMode

    $btnPrimary.Add_Click({
        $picked = Show-CommanderPicker -Entries $Entries -CurrentCommanders @(
            if ($txtPrimary.Text -ne '(None)') { $txtPrimary.Text }
        )
        if ($null -ne $picked -and @($picked).Count -gt 0) {
            $txtPrimary.Text = [string]@($picked)[0]
        }
    })

    $btnSecondary.Add_Click({
        $picked = Show-CommanderPicker -Entries $Entries -CurrentCommanders @(
            if ($txtSecondary.Text -ne '(None)') { $txtSecondary.Text }
        )
        if ($null -ne $picked -and @($picked).Count -gt 0) {
            $txtSecondary.Text = [string]@($picked)[0]
        }
    })

    $btnCompanion.Add_Click({
        $picked = Show-CommanderPicker -Entries $Entries -CurrentCommanders @(
            if ($txtCompanion.Text -ne '(None)') { $txtCompanion.Text }
        )
        if ($null -ne $picked -and @($picked).Count -gt 0) {
            $txtCompanion.Text = [string]@($picked)[0]
        }
    })

    $dlg.AcceptButton = $btnOK
    $dlg.CancelButton = $btnCancel

    if ($dlg.ShowDialog($form) -ne [System.Windows.Forms.DialogResult]::OK) {
        return $null
    }

    $primary = if ($txtPrimary.Text -ne '(None)') { $txtPrimary.Text } else { '' }
    $secondary = if ($txtSecondary.Text -ne '(None)' -and $btnSecondary.Enabled) { $txtSecondary.Text } else { '' }
    $companion = if ($txtCompanion.Text -ne '(None)') { $txtCompanion.Text } else { '' }

    return [pscustomobject]@{
        Mode = [string]$cmbMode.SelectedItem
        Primary = $primary
        Secondary = $secondary
        Companion = $companion
    }
}

function Update-CommanderSummaryText {
    $parts = New-Object System.Collections.Generic.List[string]

    if ($Script:PrimaryCommander) { $parts.Add($Script:PrimaryCommander) }
    if ($Script:SecondaryCommander) { $parts.Add($Script:SecondaryCommander) }

    if ($parts.Count -eq 0) {
        $txtCommander.Text = '(None)'
    }
    else {
        $txtCommander.Text = ($parts -join ' + ')
    }

    if ($Script:CompanionCard) {
        $txtCommander.Text += " | Companion: $($Script:CompanionCard)"
    }
    Update-CommanderColorIdentityDisplay
    if ($manaIdentityPanel) { $manaIdentityPanel.Invalidate() }
}

function Apply-SelectedCommanders {
    param(
        $Entries,
        [string[]]$CommanderNames
    )

    # Reset existing commander zoning to main first.
    foreach ($e in $Entries) {
        if ($e.Zone -eq 'commander') {
            $e.Zone = 'main'
        }
    }

    foreach ($name in @($CommanderNames)) {
        $matches = @($Entries | Where-Object { $_.Name -ieq $name })

        if ($matches.Count -gt 0) {
            foreach ($e in $matches) {
                $e.Zone = 'commander'
            }
        }
    }

    return @($Entries)
}


function Import-CockatriceCod {
    param([Parameter(Mandatory=$true)][string]$Path)

    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) {
        throw "Cockatrice deck file not found:`r`n$Path"
    }

    try {
        [xml]$doc = Get-Content -LiteralPath $Path -Raw -ErrorAction Stop
    }
    catch {
        throw "Could not read Cockatrice .cod XML.`r`n$($_.Exception.Message)"
    }

    if (-not $doc.cockatrice_deck) {
        throw 'The selected file is not a valid Cockatrice .cod deck.'
    }

    $root = $doc.cockatrice_deck
    $deckName = [string]$root.deckname
    if ([string]::IsNullOrWhiteSpace($deckName)) {
        $deckName = [System.IO.Path]::GetFileNameWithoutExtension($Path)
    }

    $format = [string]$root.format
    if ([string]::IsNullOrWhiteSpace($format)) { $format = 'Commander' }

    $banner = ''
    if ($root.bannerCard) { $banner = [string]$root.bannerCard }

    $comments = [string]$root.comments
    $tags = @($root.tags.tag | ForEach-Object { [string]$_ } | Where-Object { $_ })

    $entries = New-Object System.Collections.Generic.List[object]

    foreach ($zoneNode in @($root.zone)) {
        $zoneName = [string]$zoneNode.name
        $internalZone = if ($zoneName -ieq 'side') { 'side' } else { 'main' }

        foreach ($card in @($zoneNode.card)) {
            if (-not $card) { continue }

            $name = [string]$card.name
            if ([string]::IsNullOrWhiteSpace($name)) { continue }

            $qty = 1
            try {
                if ($card.number) { $qty = [int]$card.number }
            }
            catch { $qty = 1 }

            # Banner card is Cockatrice's commander marker.  It may physically
            # live in main or side depending on how the source deck was saved.
            $zone = $internalZone
            if ($banner -and $name -ieq $banner) {
                $zone = 'commander'
            }

                        $printingSet = ''
            $printingCollector = ''
            $printingUUID = ''

            try { if ($card.setShortName) { $printingSet = [string]$card.setShortName } } catch {}
            try { if ($card.collectorNumber) { $printingCollector = [string]$card.collectorNumber } } catch {}
            try { if ($card.uuid) { $printingUUID = [string]$card.uuid } } catch {}

            $entries.Add((New-Entry `
                -Qty $qty `
                -Name $name `
                -Zone $zone `
                -Source 'Cockatrice .COD' `
                -PrintingSet $printingSet `
                -PrintingCollector $printingCollector `
                -PrintingUUID $printingUUID))
        }
    }

    if ($entries.Count -eq 0) {
        throw 'The Cockatrice .cod file contains no cards.'
    }

    return [pscustomobject]@{
        Path = $Path
        Name = $deckName
        Format = $format
        Banner = $banner
        Comments = $comments
        Tags = $tags
        Entries = $entries.ToArray()
        Source = 'Cockatrice .COD'
    }
}

function Convert-EntriesToPlainText {
    param($Entries)

    $merged = @(Merge-Entries $Entries)
    $lines = New-Object System.Collections.Generic.List[string]

    $cmd = @($merged | Where-Object Zone -eq 'commander' | Sort-Object Name)
    $main = @($merged | Where-Object Zone -eq 'main' | Sort-Object Name)
    $side = @($merged | Where-Object Zone -eq 'side' | Sort-Object Name)

    if ($cmd.Count -gt 0) {
        $lines.Add('COMMANDER:')
        foreach ($e in $cmd) { $lines.Add(("{0} {1}" -f $e.Qty,$e.Name)) }
        $lines.Add('')
    }

    if ($main.Count -gt 0) {
        $lines.Add('MAINBOARD:')
        foreach ($e in $main) { $lines.Add(("{0} {1}" -f $e.Qty,$e.Name)) }
    }

    if ($side.Count -gt 0) {
        $lines.Add('')
        $lines.Add('SIDEBOARD:')
        foreach ($e in $side) { $lines.Add(("{0} {1}" -f $e.Qty,$e.Name)) }
    }

    return ($lines -join "`r`n")
}

function Show-CardPreview {
    param([Parameter(Mandatory=$true)][string]$CardName)

    $dlg = New-Object System.Windows.Forms.Form
    $dlg.Text = "Card Preview - $CardName"
    $dlg.StartPosition = 'CenterParent'
    $dlg.Size = New-Object System.Drawing.Size(520,760)
    $dlg.MinimumSize = New-Object System.Drawing.Size(420,600)
    $dlg.Font = New-Object System.Drawing.Font('Segoe UI',9)

    $pic = New-Object System.Windows.Forms.PictureBox
    $pic.Dock = 'Fill'
    $pic.SizeMode = 'Zoom'
    $pic.BackColor = [System.Drawing.Color]::Black
    $dlg.Controls.Add($pic)

    $bottom = New-Object System.Windows.Forms.Panel
    $bottom.Dock = 'Bottom'
    $bottom.Height = 75
    $dlg.Controls.Add($bottom)

    $lbl = New-Object System.Windows.Forms.Label
    $lbl.Text = $CardName
    $lbl.AutoEllipsis = $true
    $lbl.Location = New-Object System.Drawing.Point(10,8)
    $lbl.Size = New-Object System.Drawing.Size(480,22)
    $bottom.Controls.Add($lbl)

    $btnBrowser = New-Object System.Windows.Forms.Button
    $btnBrowser.Text = 'Open on Scryfall'
    $btnBrowser.Location = New-Object System.Drawing.Point(10,36)
    $btnBrowser.Size = New-Object System.Drawing.Size(120,28)
    $bottom.Controls.Add($btnBrowser)

    $btnClose = New-Object System.Windows.Forms.Button
    $btnClose.Text = 'Close'
    $btnClose.Location = New-Object System.Drawing.Point(400,36)
    $btnClose.Size = New-Object System.Drawing.Size(85,28)
    $bottom.Controls.Add($btnClose)

    $escaped = [uri]::EscapeDataString($CardName)
    $scryfallPage = "https://scryfall.com/search?q=%21%22$escaped%22"

    $btnBrowser.Add_Click({
        Start-Process $scryfallPage
    })
    $btnClose.Add_Click({ $dlg.Close() })

    try {
        $api = "https://api.scryfall.com/cards/named?exact=$escaped"
        $headers = @{ 'User-Agent' = 'CockatriceUniversalDeckImporter/3.1.4'; 'Accept'='application/json' }
        $card = Invoke-RestMethod -Uri $api -Headers $headers -Method Get -ErrorAction Stop

        $imageUrl = $null
        if ($card.image_uris -and $card.image_uris.normal) {
            $imageUrl = [string]$card.image_uris.normal
        }
        elseif ($card.card_faces -and $card.card_faces.Count -gt 0 -and $card.card_faces[0].image_uris.normal) {
            $imageUrl = [string]$card.card_faces[0].image_uris.normal
        }

        if ($imageUrl) {
            $wc = New-Object System.Net.WebClient
            $wc.Headers['User-Agent'] = 'CockatriceUniversalDeckImporter/3.1.4'
            $bytes = $wc.DownloadData($imageUrl)
            $ms = New-Object System.IO.MemoryStream(,$bytes)
            $pic.Image = [System.Drawing.Image]::FromStream($ms)
            $pic.Tag = $ms
        }
        else {
            $lbl.Text = "$CardName - image unavailable; use Open on Scryfall."
        }
    }
    catch {
        $lbl.Text = "$CardName - preview unavailable; use Open on Scryfall."
    }

    Set-DarkThemeRecursive -Control $dlg
    Set-DarkThemeRecursive -Control $dlg
    [void]$dlg.ShowDialog($form)

    if ($pic.Image) { $pic.Image.Dispose() }
    if ($pic.Tag -is [System.IDisposable]) { $pic.Tag.Dispose() }
}



function Convert-ColorIdentityToText {
    param([string[]]$Colors)

    $ordered = @('W','U','B','R','G')
    $present = @($ordered | Where-Object { $Colors -contains $_ })

    if ($present.Count -eq 0) {
        return 'Colorless'
    }

    return ($present -join ' ')
}

function Get-ScryfallColorIdentityByName {
    param([Parameter(Mandatory=$true)][string]$CardName)

    $key = $CardName.Trim().ToLowerInvariant()
    if ($Script:ColorIdentityCache.ContainsKey($key)) {
        return @($Script:ColorIdentityCache[$key])
    }

    $escaped = [uri]::EscapeDataString($CardName.Trim())
    $url = "https://api.scryfall.com/cards/named?exact=$escaped"
    $headers = @{
        'User-Agent' = 'CockatriceUniversalDeckImporter/3.1.4'
        'Accept' = 'application/json'
    }

    try {
        $card = Invoke-RestMethod -Uri $url -Headers $headers -Method Get -ErrorAction Stop
        $colors = @($card.color_identity | ForEach-Object { [string]$_ })
        $Script:ColorIdentityCache[$key] = @($colors)
        return @($colors)
    }
    catch {
        # Unknown identity should not hard-stop deck editing.
        $Script:ColorIdentityCache[$key] = @()
        return @()
    }
}

function Get-CommanderColorIdentity {
    $all = New-Object System.Collections.Generic.HashSet[string]

    foreach ($name in @($Script:PrimaryCommander, $Script:SecondaryCommander)) {
        if ([string]::IsNullOrWhiteSpace($name)) { continue }

        foreach ($c in @(Get-ScryfallColorIdentityByName -CardName $name)) {
            [void]$all.Add($c)
        }
    }

    return @($all)
}

function Update-CommanderColorIdentityDisplay {
    if (-not $lblCommanderColors) { return }

    $colors = @(Get-CommanderColorIdentity)
    $lblCommanderColors.Text = "Colors:"
    if ($manaIdentityPanel) { $manaIdentityPanel.BringToFront(); $manaIdentityPanel.Invalidate() }
}

function Test-CardColorIdentityAllowed {
    param(
        [Parameter(Mandatory=$true)][string]$CardName,
        [string[]]$CardColors = @()
    )

    # Only enforce Commander-style color identity when a commander is selected.
    if ([string]::IsNullOrWhiteSpace($Script:PrimaryCommander)) {
        return $true
    }

    $commanderColors = @(Get-CommanderColorIdentity)

    if (-not $CardColors -or $CardColors.Count -eq 0) {
        $CardColors = @(Get-ScryfallColorIdentityByName -CardName $CardName)
    }

    # Colorless cards are always legal for identity purposes.
    if ($CardColors.Count -eq 0) {
        return $true
    }

    foreach ($c in $CardColors) {
        if ($commanderColors -notcontains $c) {
            return $false
        }
    }

    return $true
}

function Confirm-OffColorCard {
    param(
        [Parameter(Mandatory=$true)][string]$CardName,
        [string[]]$CardColors = @()
    )

    $key = $CardName.Trim().ToLowerInvariant()
    if ($Script:AllowOffColorCards.ContainsKey($key) -and $Script:AllowOffColorCards[$key]) {
        return $true
    }

    if (Test-CardColorIdentityAllowed -CardName $CardName -CardColors $CardColors) {
        return $true
    }

    $commanderColors = @(Get-CommanderColorIdentity)
    if (-not $CardColors -or $CardColors.Count -eq 0) {
        $CardColors = @(Get-ScryfallColorIdentityByName -CardName $CardName)
    }

    $cmdText = Convert-ColorIdentityToText -Colors $commanderColors
    $cardText = Convert-ColorIdentityToText -Colors $CardColors

    $answer = [System.Windows.Forms.MessageBox]::Show(
        "This card is outside the selected commander's color identity.`r`n`r`nCard:
  $CardName`r`n`r`nCommander colors:
  $cmdText`r`n`r`nCard colors:
  $cardText`r`n`r`nAdd it anyway?",
        'Outside Commander Color Identity',
        [System.Windows.Forms.MessageBoxButtons]::YesNo,
        [System.Windows.Forms.MessageBoxIcon]::Warning
    )

    if ($answer -eq [System.Windows.Forms.DialogResult]::Yes) {
        $Script:AllowOffColorCards[$key] = $true
        return $true
    }

    return $false
}

function Get-OffColorEditorCards {
    $problems = New-Object System.Collections.Generic.List[string]

    if ([string]::IsNullOrWhiteSpace($Script:PrimaryCommander)) {
        return @()
    }

    foreach ($row in $gridDeckEditor.Rows) {
        if ($row.IsNewRow) { continue }

        $name = [string]$row.Cells['CardName'].Value
        $zone = [string]$row.Cells['Zone'].Value

        if ([string]::IsNullOrWhiteSpace($name)) { continue }
        if ($zone -eq 'commander') { continue }

        if (-not (Test-CardColorIdentityAllowed -CardName $name)) {
            $problems.Add($name)
        }
    }

    return @($problems | Sort-Object -Unique)
}



function Show-CommanderFullHelp {
    $dlg = New-Object System.Windows.Forms.Form
    $dlg.Text = 'Commander Setup Help'
    $dlg.StartPosition = 'CenterParent'
    $dlg.Size = New-Object System.Drawing.Size(860,700)
    $dlg.MinimumSize = New-Object System.Drawing.Size(700,540)
    $dlg.Font = New-Object System.Drawing.Font('Segoe UI',9)

    $bottom = New-Object System.Windows.Forms.Panel
    $bottom.Dock = 'Bottom'
    $bottom.Height = 50
    $dlg.Controls.Add($bottom)

    $btnCopyHelp = New-Object System.Windows.Forms.Button
    $btnCopyHelp.Text = 'Copy Help'
    $btnCopyHelp.Size = New-Object System.Drawing.Size(95,28)
    $btnCopyHelp.Location = New-Object System.Drawing.Point(10,10)
    $bottom.Controls.Add($btnCopyHelp)

    $btnClose = New-Object System.Windows.Forms.Button
    $btnClose.Text = 'Close'
    $btnClose.Size = New-Object System.Drawing.Size(85,28)
    $btnClose.Location = New-Object System.Drawing.Point(750,10)
    $btnClose.Anchor = 'Right,Bottom'
    $bottom.Controls.Add($btnClose)

    $rtb = New-Object System.Windows.Forms.RichTextBox
    $rtb.Dock = 'Fill'
    $rtb.ReadOnly = $true
    $rtb.WordWrap = $false
    $rtb.DetectUrls = $false
    $rtb.ScrollBars = [System.Windows.Forms.RichTextBoxScrollBars]::Both
    $rtb.BackColor = [System.Drawing.SystemColors]::Window
    $rtb.ForeColor = [System.Drawing.SystemColors]::WindowText
    $rtb.BorderStyle = [System.Windows.Forms.BorderStyle]::FixedSingle
    $rtb.Font = New-Object System.Drawing.Font('Consolas',10)
    $dlg.Controls.Add($rtb)
    $rtb.BringToFront()

    $helpText = @"
COMMANDER SETUP HELP
====================

BASIC WORKFLOW
--------------

1. Choose your deck Format first.
2. Import, load, or create a deck.
3. Click Commander Setup...
4. Choose the Commander Type.
5. Select the Primary Commander.
6. Add a Secondary Commander role if your commander rules allow it.
7. Add an optional Companion if desired.
8. The app calculates the combined commander Color Identity.
9. Cards outside that identity will show a warning before they are added.

COMMANDER TYPES
---------------

Regular Commander
  One normal commander. No second commander is required.

Partner
  Use two commanders that legally have Partner.

Friends Forever
  Use two commanders that both have Friends Forever.

Choose a Background
  Use a commander with Choose a Background plus a legal Background card.

Doctor + Doctor's Companion
  Use a Doctor with a card that has Doctor's Companion.

Partner With
  Use the specific named Partner With pairing.

COMPANION
---------

Companion is a separate optional role.

A Companion does NOT expand your commander's color identity.

You can have combinations such as:
  - Commander + Companion
  - Partner pair + Companion
  - Commander + Background + Companion
  - Doctor + Doctor's Companion + Companion

COLOR IDENTITY
--------------

The app combines the color identity of:
  - Primary Commander
  - Secondary Commander / Partner / Background / Doctor's Companion

The Companion is NOT included in the combined commander color identity.

Colorless cards are always allowed for color identity purposes.

If you add a card outside the selected commander's colors, the app asks whether
you want to add it anyway. This is a warning rather than a hard block so custom
or unusual deckbuilding is still possible.

ADDING CARDS
------------

Cockatrice Card Search
  Start typing a card name from your local cards.xml.
  Choose a zone and click Add Local Card.

Scryfall Search
  Use normal Scryfall syntax.
  Press Enter or click Search.
  Choose a result.
  Choose main / commander / side.
  Click Add Selected to Deck.

MODIFYING THE DECK
------------------

Inside Modify Deck you can:
  - change quantities
  - edit card names
  - change zones
  - add cards
  - remove cards
  - preview cards
  - restore the originally loaded/imported version
  - use right-click actions for common zone changes

SAVING
------

Save Verified .COD
  Creates and verifies a Cockatrice deck file.

Overwrite Original
  Available when an existing Cockatrice .cod was loaded.
  A backup is created first.

Export Text
  Exports the current deck as a normal text decklist.

NOTE
----

The Commander Setup helper is meant to make deck construction easier, but the
program intentionally warns instead of hard-blocking unusual/custom setups.
"@

    # WinForms on Windows behaves best with explicit CRLF line endings.
    $helpText = $helpText -replace "`r?`n", "`r`n"
    $rtb.Text = $helpText
    $rtb.SelectionStart = 0
    $rtb.ScrollToCaret()

    $btnCopyHelp.Add_Click({
        try {
            [System.Windows.Forms.Clipboard]::SetText($helpText)
            $btnCopyHelp.Text = 'Copied!'
        }
        catch {
            Show-DetailedError -ErrorRecord $_ -Context 'Copy Commander Help'
        }
    })

    $btnClose.Add_Click({ $dlg.Close() })

    Set-DarkThemeRecursive -Control $dlg
    [void]$dlg.ShowDialog($form)
}



function Get-DarkPalette {
    return @{
        Back        = [System.Drawing.Color]::FromArgb(30,30,30)
        Panel       = [System.Drawing.Color]::FromArgb(38,38,38)
        PanelAlt    = [System.Drawing.Color]::FromArgb(45,45,45)
        Input       = [System.Drawing.Color]::FromArgb(50,50,50)
        Grid        = [System.Drawing.Color]::FromArgb(34,34,34)
        GridAlt     = [System.Drawing.Color]::FromArgb(42,42,42)
        Fore        = [System.Drawing.Color]::FromArgb(235,235,235)
        Muted       = [System.Drawing.Color]::FromArgb(170,170,170)
        Border      = [System.Drawing.Color]::FromArgb(72,72,72)
        Accent      = [System.Drawing.Color]::FromArgb(70,130,180)
        Good        = [System.Drawing.Color]::FromArgb(86,170,92)
        Warn        = [System.Drawing.Color]::FromArgb(220,170,60)
        Bad         = [System.Drawing.Color]::FromArgb(210,80,80)
        WhiteMana   = [System.Drawing.Color]::FromArgb(238,231,194)
        BlueMana    = [System.Drawing.Color]::FromArgb(80,145,210)
        BlackMana   = [System.Drawing.Color]::FromArgb(85,85,90)
        RedMana     = [System.Drawing.Color]::FromArgb(210,80,65)
        GreenMana   = [System.Drawing.Color]::FromArgb(75,145,85)
        Colorless   = [System.Drawing.Color]::FromArgb(160,160,160)
    }
}

function Set-DarkThemeRecursive {
    param([System.Windows.Forms.Control]$Control)

    if (-not $Control) { return }
    $p = Get-DarkPalette

    try {
        switch ($Control.GetType().Name) {
            'Form' {
                $Control.BackColor = $p.Back
                $Control.ForeColor = $p.Fore
            }
            'Panel' {
                $Control.BackColor = $p.Panel
                $Control.ForeColor = $p.Fore
            }
            'SplitContainer' {
                $Control.BackColor = $p.Border
                $Control.Panel1.BackColor = $p.Panel
                $Control.Panel2.BackColor = $p.Panel
            }
            'GroupBox' {
                $Control.BackColor = $p.Panel
                $Control.ForeColor = $p.Fore
            }
            'Label' {
                $Control.BackColor = [System.Drawing.Color]::Transparent
                if ($Control.ForeColor -eq [System.Drawing.Color]::DimGray) {
                    $Control.ForeColor = $p.Muted
                } else {
                    $Control.ForeColor = $p.Fore
                }
            }
            'TextBox' {
                $Control.BackColor = $p.Input
                $Control.ForeColor = $p.Fore
                $Control.BorderStyle = [System.Windows.Forms.BorderStyle]::FixedSingle
            }
            'RichTextBox' {
                $Control.BackColor = $p.Input
                $Control.ForeColor = $p.Fore
                $Control.BorderStyle = [System.Windows.Forms.BorderStyle]::FixedSingle
            }
            'ComboBox' {
                $Control.BackColor = $p.Input
                $Control.ForeColor = $p.Fore
                $Control.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
            }
            'Button' {
                $Control.BackColor = $p.PanelAlt
                $Control.ForeColor = $p.Fore
                $Control.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
                $Control.FlatAppearance.BorderColor = $p.Border
                $Control.FlatAppearance.MouseOverBackColor = [System.Drawing.Color]::FromArgb(58,58,58)
            }
            'CheckBox' {
                $Control.BackColor = $p.Panel
                $Control.ForeColor = $p.Fore
            }
            'DataGridView' {
                $Control.BackgroundColor = $p.Grid
                $Control.GridColor = $p.Border
                $Control.BorderStyle = [System.Windows.Forms.BorderStyle]::FixedSingle
                $Control.EnableHeadersVisualStyles = $false
                $Control.ColumnHeadersDefaultCellStyle.BackColor = $p.PanelAlt
                $Control.ColumnHeadersDefaultCellStyle.ForeColor = $p.Fore
                $Control.DefaultCellStyle.BackColor = $p.Grid
                $Control.DefaultCellStyle.ForeColor = $p.Fore
                $Control.DefaultCellStyle.SelectionBackColor = [System.Drawing.Color]::FromArgb(55,95,135)
                $Control.DefaultCellStyle.SelectionForeColor = $p.Fore
                $Control.AlternatingRowsDefaultCellStyle.BackColor = $p.GridAlt
                $Control.RowHeadersDefaultCellStyle.BackColor = $p.PanelAlt
                $Control.RowHeadersDefaultCellStyle.ForeColor = $p.Fore
            }
            'PictureBox' {
                if ($Control.BackColor -eq [System.Drawing.Color]::FromArgb(245,245,245)) {
                    $Control.BackColor = $p.Input
                }
            }
        }
    } catch {}

    foreach ($child in $Control.Controls) {
        Set-DarkThemeRecursive -Control $child
    }
}

function Draw-ManaIdentityBadges {
    param(
        [System.Drawing.Graphics]$Graphics,
        [string[]]$Colors,
        [System.Drawing.Rectangle]$Bounds
    )

    $p = Get-DarkPalette
    $map = @{
        'W' = @{ Fill=$p.WhiteMana; Text=[System.Drawing.Color]::FromArgb(35,35,35); Glyph='W' }
        'U' = @{ Fill=$p.BlueMana;  Text=[System.Drawing.Color]::White; Glyph='U' }
        'B' = @{ Fill=$p.BlackMana; Text=[System.Drawing.Color]::White; Glyph='B' }
        'R' = @{ Fill=$p.RedMana;   Text=[System.Drawing.Color]::White; Glyph='R' }
        'G' = @{ Fill=$p.GreenMana; Text=[System.Drawing.Color]::White; Glyph='G' }
    }

    $ordered = @('W','U','B','R','G') | Where-Object { $Colors -contains $_ }
    if ($ordered.Count -eq 0) {
        $ordered = @('C')
        $map['C'] = @{ Fill=$p.Colorless; Text=[System.Drawing.Color]::FromArgb(30,30,30); Glyph='◇' }
    }

    $size = [Math]::Min(24, [Math]::Max(18, $Bounds.Height - 4))
    $x = $Bounds.X + 2
    $y = $Bounds.Y + [int](($Bounds.Height - $size) / 2)

    $font = New-Object System.Drawing.Font('Segoe UI Symbol', [Math]::Max(9, $size * 0.42), [System.Drawing.FontStyle]::Bold)

    foreach ($c in $ordered) {
        $info = $map[$c]
        $brush = New-Object System.Drawing.SolidBrush($info.Fill)
        $textBrush = New-Object System.Drawing.SolidBrush($info.Text)
        $pen = New-Object System.Drawing.Pen([System.Drawing.Color]::FromArgb(115,115,115),1)

        $rect = New-Object System.Drawing.Rectangle($x,$y,$size,$size)
        $Graphics.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::AntiAlias
        $Graphics.FillEllipse($brush,$rect)
        $Graphics.DrawEllipse($pen,$rect)

        $fmt = New-Object System.Drawing.StringFormat
        $fmt.Alignment = [System.Drawing.StringAlignment]::Center
        $fmt.LineAlignment = [System.Drawing.StringAlignment]::Center
        $Graphics.DrawString($info.Glyph,$font,$textBrush,[System.Drawing.RectangleF]$rect,$fmt)

        $brush.Dispose(); $textBrush.Dispose(); $pen.Dispose(); $fmt.Dispose()
        $x += $size + 5
    }

    $font.Dispose()
}

function Get-DeckCommanderStatus {
    param($Entries)

    $merged = @(Merge-Entries $Entries)
    $mainQty = [int](($merged | Where-Object Zone -eq 'main' | Measure-Object Qty -Sum).Sum)
    $cmdQty  = [int](($merged | Where-Object Zone -eq 'commander' | Measure-Object Qty -Sum).Sum)
    $sideQty = [int](($merged | Where-Object Zone -eq 'side' | Measure-Object Qty -Sum).Sum)

    $basicLands = New-Object 'System.Collections.Generic.HashSet[string]' ([System.StringComparer]::OrdinalIgnoreCase)
    foreach ($basic in @(
        'Plains','Island','Swamp','Mountain','Forest','Wastes',
        'Snow-Covered Plains','Snow-Covered Island','Snow-Covered Swamp',
        'Snow-Covered Mountain','Snow-Covered Forest'
    )) {
        [void]$basicLands.Add($basic)
    }

    # Count quantities directly from the entries. This intentionally handles
    # BOTH separate duplicate rows and a single merged row such as Qty=2/3.
    # Basics are ignored so normal deck statistics are not flooded by lands.
    $nameCounts = New-Object 'System.Collections.Generic.Dictionary[string,int]' ([System.StringComparer]::OrdinalIgnoreCase)

    foreach ($e in @($Entries)) {
        $zone = [string]$e.Zone
        if ($zone -notin @('main','commander')) { continue }

        $name = [string]$e.Name
        if ([string]::IsNullOrWhiteSpace($name)) { continue }
        if ($basicLands.Contains($name)) { continue }

        $qty = 1
        try { $qty = [int]$e.Qty } catch {}
        if ($qty -lt 1) { $qty = 1 }

        if ($nameCounts.ContainsKey($name)) {
            $nameCounts[$name] += $qty
        }
        else {
            $nameCounts[$name] = $qty
        }
    }

    $duplicates = @(
        foreach ($name in $nameCounts.Keys) {
            if ($nameCounts[$name] -gt 1) {
                '{0}x {1}' -f $nameCounts[$name], $name
            }
        }
    ) | Sort-Object

    return [pscustomobject]@{
        MainQty = $mainQty
        CommanderQty = $cmdQty
        SideQty = $sideQty
        DeckQty = $mainQty + $cmdQty
        Duplicates = @($duplicates)
    }
}


function Get-DeckTypeStats {
    param($Entries)

    # Keep stats lightweight on the UI thread.
    # Detailed type metadata can be added later from a prebuilt card-index cache,
    # but we deliberately avoid rereading the large cards.xml here.
    return [pscustomobject]@{
        Creature = 0
        Artifact = 0
        Enchantment = 0
        Instant = 0
        Sorcery = 0
        Planeswalker = 0
        Land = 0
        Other = 0
    }
}

function Get-EntriesForLiveStats {
    # Once the editor is visible, the grid is the source of truth. This makes
    # Qty=2/3 edits and web-import merged rows update duplicate stats instantly.
    if ($Script:EditorMode -and $gridDeckEditor -and $gridDeckEditor.Rows.Count -gt 0) {
        try {
            return @(Get-DeckEditorEntries)
        }
        catch {}
    }

    if ($Script:Analysis -and $Script:Analysis.Entries) {
        return @($Script:Analysis.Entries)
    }

    return @()
}

function Update-DeckStatsPanel {
    if (-not $Script:Analysis -or -not $Script:Analysis.Entries) {
        if ($lblDeckStats) { $lblDeckStats.Text = 'Deck Stats: no deck loaded' }
        if ($manaIdentityPanel) { $manaIdentityPanel.Invalidate() }
        return
    }

    $liveEntries = @(Get-EntriesForLiveStats)
    $statusInfo = Get-DeckCommanderStatus -Entries $liveEntries
    $types = Get-DeckTypeStats -Entries $liveEntries

    $dupCount = @($statusInfo.Duplicates).Count
    $target = if ($cmbFormat.Text -eq 'Commander') { 100 } else { $statusInfo.DeckQty }
    $countText = if ($cmbFormat.Text -eq 'Commander') { "$($statusInfo.DeckQty)/100" } else { [string]$statusInfo.DeckQty }

    $dupLabel = if ($cmbFormat.Text -eq 'Commander') { 'Duplicates' } else { 'Repeated' }
    $lblDeckStats.Text = "Deck $countText   |   Main $($statusInfo.MainQty)   Commander $($statusInfo.CommanderQty)   Side $($statusInfo.SideQty)   $dupLabel $dupCount"
    $lblDeckStats.ForeColor = if ($cmbFormat.Text -eq 'Commander' -and $statusInfo.DeckQty -ne 100) {
        (Get-DarkPalette).Warn
    } elseif ($dupCount -gt 0 -and $cmbFormat.Text -eq 'Commander') {
        (Get-DarkPalette).Warn
    } else {
        (Get-DarkPalette).Fore
    }

    if ($manaIdentityPanel) { $manaIdentityPanel.Invalidate() }
}

function Save-DeckAutosave {
    try {
        if (-not $Script:EditorMode -or -not $gridDeckEditor) { return }

        $rows = @()
        foreach ($row in $gridDeckEditor.Rows) {
            if ($row.IsNewRow) { continue }
            $name = [string]$row.Cells['CardName'].Value
            if ([string]::IsNullOrWhiteSpace($name)) { continue }

            $qty = 1
            try { $qty = [int]$row.Cells['Qty'].Value } catch {}
            $rows += [pscustomobject]@{
                Qty = $qty
                Name = $name
                Zone = [string]$row.Cells['Zone'].Value
            }
        }

        $payload = [ordered]@{
            Version = '5.0'
            SavedAt = (Get-Date).ToString('o')
            DeckName = $txtName.Text
            Format = $cmbFormat.Text
            PrimaryCommander = $Script:PrimaryCommander
            SecondaryCommander = $Script:SecondaryCommander
            Companion = $Script:CompanionCard
            CommanderMode = $Script:CommanderMode
            Comments = $txtComments.Text
            Tags = @($Script:SelectedTags)
            Destination = $cmbDest.Text
            Entries = $rows
        }

        $json = $payload | ConvertTo-Json -Depth 6
        $hash = [Convert]::ToBase64String([System.Security.Cryptography.SHA256]::Create().ComputeHash([System.Text.Encoding]::UTF8.GetBytes($json)))

        if ($hash -ne $Script:LastAutosaveHash) {
            [System.IO.File]::WriteAllText($Script:AutosavePath,$json,[System.Text.Encoding]::UTF8)
            $Script:LastAutosaveHash = $hash
            if ($lblAutosave) { $lblAutosave.Text = "Autosaved $(Get-Date -Format 'HH:mm:ss')" }
        }
    } catch {}
}

function Try-RestoreAutosave {
    if (-not (Test-Path -LiteralPath $Script:AutosavePath -PathType Leaf)) { return }

    try {
        $raw = Get-Content -LiteralPath $Script:AutosavePath -Raw -ErrorAction Stop
        $saved = $raw | ConvertFrom-Json -ErrorAction Stop
        if (-not $saved.Entries -or @($saved.Entries).Count -eq 0) { return }

        $answer = [System.Windows.Forms.MessageBox]::Show(
            "An autosaved deck was found from $($saved.SavedAt).`r`n`r`nRestore it?",
            'Restore Autosaved Deck',
            [System.Windows.Forms.MessageBoxButtons]::YesNo,
            [System.Windows.Forms.MessageBoxIcon]::Question
        )

        if ($answer -ne [System.Windows.Forms.DialogResult]::Yes) { return }

        $txtName.Text = [string]$saved.DeckName
        $cmbFormat.Text = [string]$saved.Format
        $txtComments.Text = [string]$saved.Comments
        if ($saved.Destination) { $cmbDest.Text = [string]$saved.Destination }

        $Script:PrimaryCommander = [string]$saved.PrimaryCommander
        $Script:SecondaryCommander = [string]$saved.SecondaryCommander
        $Script:CompanionCard = [string]$saved.Companion
        $Script:CommanderMode = [string]$saved.CommanderMode
        $Script:SelectedTags = @($saved.Tags)
        Update-CommanderSummaryText

        $entries = @(
            $saved.Entries | ForEach-Object {
                New-Entry -Qty ([int]$_.Qty) -Name ([string]$_.Name) -Zone ([string]$_.Zone) -Source 'Autosave'
            }
        )

        $Script:Analysis = [pscustomobject]@{
            Entries = $entries
            Merged = @(Merge-Entries $entries)
            Invalid = @()
            Source = 'Autosave Recovery'
            MainQty = 0
            CommanderQty = 0
            SideQty = 0
            DeckQty = 0
            TotalQty = 0
        }

        Validate-Entries $entries
        Update-Preview -Entries $entries -SourceName 'Autosave Recovery' -Ignored @()
        Enter-DeckEditor
        Refresh-DeckEditorGrid -Entries $entries
        Update-DeckStatsPanel
        $status.Text = 'Autosaved deck restored.'
    } catch {}
}

function Apply-DeckFilter {
    if (-not $gridDeckEditor) { return }

    $needle = $txtDeckFilter.Text.Trim()

    foreach ($row in $gridDeckEditor.Rows) {
        if ($row.IsNewRow) { continue }
        if ([string]::IsNullOrWhiteSpace($needle)) {
            $row.Visible = $true
            continue
        }

        $name = [string]$row.Cells['CardName'].Value
        $zone = [string]$row.Cells['Zone'].Value
        $row.Visible = ($name.IndexOf($needle,[System.StringComparison]::OrdinalIgnoreCase) -ge 0 -or
                        $zone.IndexOf($needle,[System.StringComparison]::OrdinalIgnoreCase) -ge 0)
    }
}


function Get-LegendaryCreatureCandidates {
    param([string]$DataRoot)

    if ([string]::IsNullOrWhiteSpace($DataRoot)) {
        throw 'Cockatrice data folder is not available.'
    }

    if ($Script:LegendaryCommanderCache -and
        $Script:LegendaryCommanderCacheRoot -eq $DataRoot) {
        return @($Script:LegendaryCommanderCache)
    }

    $cardsXml = Join-Path $DataRoot 'cards.xml'
    if (-not (Test-Path -LiteralPath $cardsXml -PathType Leaf)) {
        throw "cards.xml was not found:`r`n$cardsXml"
    }

    $status.Text = 'Scanning Cockatrice cards.xml for legendary creatures...'
    [System.Windows.Forms.Application]::DoEvents()

    $results = New-Object System.Collections.Generic.List[object]

    $settings = New-Object System.Xml.XmlReaderSettings
    $settings.IgnoreComments = $true
    $settings.IgnoreWhitespace = $true

    $reader = [System.Xml.XmlReader]::Create($cardsXml,$settings)

    try {
        while ($reader.Read()) {
            if ($reader.NodeType -ne [System.Xml.XmlNodeType]::Element -or
                $reader.Name -ne 'card') {
                continue
            }

            $sub = $reader.ReadSubtree()
            $name = ''
            $typeParts = New-Object System.Collections.Generic.List[string]
            $ruleParts = New-Object System.Collections.Generic.List[string]

            try {
                while ($sub.Read()) {
                    if ($sub.NodeType -ne [System.Xml.XmlNodeType]::Element) {
                        continue
                    }

                    switch ($sub.Name.ToLowerInvariant()) {
                        'name' {
                            if (-not $name) {
                                $name = $sub.ReadElementContentAsString()
                            }
                        }

                        # Cockatrice XML variants may distribute Legendary / Creature
                        # over any of these fields. Collect all of them.
                        'type' {
                            $v = $sub.ReadElementContentAsString()
                            if ($v) { $typeParts.Add($v) }
                        }
                        'maintype' {
                            $v = $sub.ReadElementContentAsString()
                            if ($v) { $typeParts.Add($v) }
                        }
                        'supertype' {
                            $v = $sub.ReadElementContentAsString()
                            if ($v) { $typeParts.Add($v) }
                        }
                        'subtype' {
                            $v = $sub.ReadElementContentAsString()
                            if ($v) { $typeParts.Add($v) }
                        }
                        'text' {
                            $v = $sub.ReadElementContentAsString()
                            if ($v) { $ruleParts.Add($v) }
                        }
                    }
                }
            }
            finally {
                $sub.Close()
            }

            if (-not $name) { continue }

            $typeLine = (($typeParts.ToArray() | Where-Object { $_ }) -join ' ')
            $rules = (($ruleParts.ToArray() | Where-Object { $_ }) -join "`r`n")

            # Be tolerant of Cockatrice schemas that store Legendary and Creature
            # in separate properties.
            $isLegendary = ($typeLine -match '(?i)(^|\W)Legendary(\W|$)')
            $isCreature  = ($typeLine -match '(?i)(^|\W)Creature(\W|$)')

            if ($isLegendary -and $isCreature) {
                $mode = 'Regular Commander'

                if ($rules -match '(?i)\bFriends forever\b') {
                    $mode = 'Friends Forever'
                }
                elseif ($rules -match '(?i)\bChoose a Background\b') {
                    $mode = 'Choose a Background'
                }
                elseif ($rules -match "(?i)\bDoctor's companion\b") {
                    $mode = "Doctor + Doctor's Companion"
                }
                elseif ($rules -match '(?i)\bPartner with\b') {
                    $mode = 'Partner With'
                }
                elseif ($rules -match '(?i)(^|\W)Partner(\W|$)') {
                    $mode = 'Partner'
                }

                $results.Add([pscustomobject]@{
                    Name = $name
                    Type = $typeLine
                    Rules = $rules
                    SuggestedMode = $mode
                })
            }
        }
    }
    finally {
        $reader.Close()
    }

    $Script:LegendaryCommanderCache = @(
        $results |
            Group-Object Name |
            ForEach-Object { $_.Group[0] } |
            Sort-Object Name
    )
    $Script:LegendaryCommanderCacheRoot = $DataRoot

    $status.Text = "Smart Commander found $($Script:LegendaryCommanderCache.Count) legendary creatures."
    return @($Script:LegendaryCommanderCache)
}


function Get-DeckLegendaryCommanderCandidates {
    param($Entries)

    if (-not $Entries) { return @() }

    $names = New-Object System.Collections.Generic.List[string]
    $seen = New-Object 'System.Collections.Generic.HashSet[string]' ([System.StringComparer]::OrdinalIgnoreCase)

    foreach ($e in @(Merge-Entries $Entries)) {
        $n = [string]$e.Name
        if ([string]::IsNullOrWhiteSpace($n)) { continue }

        # Cockatrice normally stores only the front-face name. If an imported
        # source still contains "Front // Back", use the front face for Scryfall.
        $lookup = $n
        if ($lookup -match '\s+//\s+') {
            $lookup = ($lookup -split '\s+//\s+',2)[0].Trim()
        }

        if ($seen.Add($lookup)) {
            $names.Add($lookup)
        }
    }

    if ($names.Count -eq 0) { return @() }

    $headers = @{
        'User-Agent' = 'CockatriceUniversalDeckImporter/3.1.4'
        'Accept'     = 'application/json'
    }

    $found = New-Object System.Collections.Generic.List[object]

    # Scryfall /cards/collection accepts up to 75 identifiers per request.
    for ($offset = 0; $offset -lt $names.Count; $offset += 75) {
        $take = [Math]::Min(75, $names.Count - $offset)

        $identifiers = @()
        for ($i = 0; $i -lt $take; $i++) {
            $identifiers += @{ name = $names[$offset + $i] }
        }

        $body = @{ identifiers = $identifiers } | ConvertTo-Json -Depth 4

        try {
            $response = Invoke-RestMethod `
                -Uri 'https://api.scryfall.com/cards/collection' `
                -Method Post `
                -Headers $headers `
                -ContentType 'application/json' `
                -Body $body `
                -ErrorAction Stop
        }
        catch {
            # Automatic commander detection must never block deck loading.
            $status.Text = 'Deck loaded. Smart Commander lookup unavailable; use Smart Commander manually if needed.'
            return @()
        }

        foreach ($card in @($response.data)) {
            $name = [string]$card.name
            $typeLine = [string]$card.type_line
            $rules = [string]$card.oracle_text

            if ($typeLine -notmatch '(?i)(^|\W)Legendary(\W|$)') { continue }
            if ($typeLine -notmatch '(?i)(^|\W)Creature(\W|$)') { continue }

            $mode = 'Regular Commander'

            if ($rules -match '(?i)\bFriends forever\b') {
                $mode = 'Friends Forever'
            }
            elseif ($rules -match '(?i)\bChoose a Background\b') {
                $mode = 'Choose a Background'
            }
            elseif ($rules -match "(?i)\bDoctor's companion\b") {
                $mode = "Doctor + Doctor's Companion"
            }
            elseif ($rules -match '(?i)\bPartner with\b') {
                $mode = 'Partner With'
            }
            elseif ($rules -match '(?i)(^|\W)Partner(\W|$)') {
                $mode = 'Partner'
            }

            $imageUrl = $null
            if ($card.image_uris -and $card.image_uris.normal) {
                $imageUrl = [string]$card.image_uris.normal
            }
            elseif ($card.card_faces -and $card.card_faces.Count -gt 0 -and
                    $card.card_faces[0].image_uris.normal) {
                $imageUrl = [string]$card.card_faces[0].image_uris.normal
            }

            $found.Add([pscustomobject]@{
                Name          = $name
                Type          = $typeLine
                Rules         = $rules
                SuggestedMode = $mode
                ImageUrl      = $imageUrl
            })
        }
    }

    return @(
        $found |
            Group-Object Name |
            ForEach-Object { $_.Group[0] } |
            Sort-Object Name
    )
}


function Show-DeckCommanderChooser {
    param(
        $Entries,
        [switch]$Automatic
    )

    $candidates = @(Get-DeckLegendaryCommanderCandidates -Entries $Entries)

    if ($candidates.Count -eq 0) {
        if (-not $Automatic) {
            [System.Windows.Forms.MessageBox]::Show(
                "No Legendary Creatures from this deck were identified as commander candidates.`r`n`r`nYou can still use Commander Setup... or Smart Commander... manually.",
                'Smart Commander',
                [System.Windows.Forms.MessageBoxButtons]::OK,
                [System.Windows.Forms.MessageBoxIcon]::Information
            ) | Out-Null
        }
        return $null
    }

    if ($candidates.Count -eq 1) {
        $one = $candidates[0]
        $answer = [System.Windows.Forms.MessageBox]::Show(
            "Smart Commander found one Legendary Creature in this deck:`r`n`r`n$($one.Name)`r`n`r`nUse it as the Primary Commander?",
            'Smart Commander',
            [System.Windows.Forms.MessageBoxButtons]::YesNo,
            [System.Windows.Forms.MessageBoxIcon]::Question
        )
        if ($answer -eq [System.Windows.Forms.DialogResult]::Yes) {
            return $one
        }
        return $null
    }

    $dlg = New-Object System.Windows.Forms.Form
    $dlg.Text = 'Choose Commander From This Deck'
    $dlg.StartPosition = 'CenterParent'
    $dlg.Size = New-Object System.Drawing.Size(760,590)
    $dlg.MinimumSize = New-Object System.Drawing.Size(680,500)
    $dlg.Font = New-Object System.Drawing.Font('Segoe UI',9)

    $lbl = New-Object System.Windows.Forms.Label
    $lbl.Text = "Legendary Creatures found in this deck: $($candidates.Count)"
    $lbl.Location = New-Object System.Drawing.Point(12,12)
    $lbl.AutoSize = $true
    $dlg.Controls.Add($lbl)

    $txtFind = New-Object System.Windows.Forms.TextBox
    $txtFind.Location = New-Object System.Drawing.Point(12,36)
    $txtFind.Size = New-Object System.Drawing.Size(350,25)
    $dlg.Controls.Add($txtFind)

    $list = New-Object System.Windows.Forms.ListBox
    $list.Location = New-Object System.Drawing.Point(12,70)
    $list.Size = New-Object System.Drawing.Size(350,430)
    $list.Anchor = 'Top,Bottom,Left'
    $list.DisplayMember = 'Name'
    $dlg.Controls.Add($list)

    $pic = New-Object System.Windows.Forms.PictureBox
    $pic.Location = New-Object System.Drawing.Point(380,70)
    $pic.Size = New-Object System.Drawing.Size(350,400)
    $pic.Anchor = 'Top,Bottom,Left,Right'
    $pic.SizeMode = 'Zoom'
    $dlg.Controls.Add($pic)

    $lblDetails = New-Object System.Windows.Forms.Label
    $lblDetails.Location = New-Object System.Drawing.Point(380,478)
    $lblDetails.Size = New-Object System.Drawing.Size(350,42)
    $lblDetails.Anchor = 'Bottom,Left,Right'
    $dlg.Controls.Add($lblDetails)

    $btnUse = New-Object System.Windows.Forms.Button
    $btnUse.Text = 'Use Commander'
    $btnUse.Location = New-Object System.Drawing.Point(540,525)
    $btnUse.Size = New-Object System.Drawing.Size(120,30)
    $btnUse.Anchor = 'Bottom,Right'
    $btnUse.Enabled = $false
    $dlg.Controls.Add($btnUse)

    $btnCancel = New-Object System.Windows.Forms.Button
    $btnCancel.Text = 'Cancel'
    $btnCancel.Location = New-Object System.Drawing.Point(665,525)
    $btnCancel.Size = New-Object System.Drawing.Size(70,30)
    $btnCancel.Anchor = 'Bottom,Right'
    $dlg.Controls.Add($btnCancel)

    $selection = $null
    $resultSelection = $null

    function Refresh-DeckCommanderList {
        $needle = $txtFind.Text.Trim()

        $list.BeginUpdate()
        $list.Items.Clear()

        foreach ($c in $candidates) {
            if ($needle -and
                $c.Name.IndexOf($needle,[System.StringComparison]::OrdinalIgnoreCase) -lt 0) {
                continue
            }
            [void]$list.Items.Add($c)
        }

        $list.EndUpdate()
        if ($list.Items.Count -gt 0) {
            $list.SelectedIndex = 0
        }
    }

    $txtFind.Add_TextChanged({ Refresh-DeckCommanderList })

    $list.Add_SelectedIndexChanged({
        try {
            $c = $list.SelectedItem
            if (-not $c) {
                $btnUse.Enabled = $false
                return
            }

            $selection = $c
            $btnUse.Enabled = $true
            $lblDetails.Text = "$($c.Name)`r`nDetected: $($c.SuggestedMode)"

            $imageUrl = [string]$c.ImageUrl

            if ($imageUrl) {
                $wc = New-Object System.Net.WebClient
                $wc.Headers['User-Agent'] = 'CockatriceUniversalDeckImporter/3.1.4'
                $bytes = $wc.DownloadData($imageUrl)

                $ms = New-Object System.IO.MemoryStream(,$bytes)
                $img = [System.Drawing.Image]::FromStream($ms)

                if ($pic.Image) {
                    $oldImg = $pic.Image
                    $pic.Image = $null
                    $oldImg.Dispose()
                }

                if ($pic.Tag -is [System.IDisposable]) {
                    $pic.Tag.Dispose()
                }

                $pic.Image = $img
                $pic.Tag = $ms
            }
        }
        catch {
            if ($selection) {
                $lblDetails.Text = "$($selection.Name)`r`nPreview unavailable."
            }
        }
    })

    $chooseHighlightedCommander = {
        $picked = $list.SelectedItem

        if (-not $picked) {
            [System.Windows.Forms.MessageBox]::Show(
                'Select a commander first.',
                'Smart Commander',
                [System.Windows.Forms.MessageBoxButtons]::OK,
                [System.Windows.Forms.MessageBoxIcon]::Information
            ) | Out-Null
            return
        }

        $script:DeckCommanderChooserResult = $picked
        $dlg.DialogResult = [System.Windows.Forms.DialogResult]::OK
        $dlg.Close()
    }

    $btnUse.Add_Click($chooseHighlightedCommander)

    $list.Add_DoubleClick({
        if ($list.SelectedItem) {
            & $chooseHighlightedCommander
        }
    })

    $list.Add_KeyDown({
        param($sender,$e)

        if ($e.KeyCode -eq [System.Windows.Forms.Keys]::Enter -and $list.SelectedItem) {
            $e.Handled = $true
            $e.SuppressKeyPress = $true
            & $chooseHighlightedCommander
        }
    })

    $btnCancel.Add_Click({
        $dlg.DialogResult = [System.Windows.Forms.DialogResult]::Cancel
        $dlg.Close()
    })

    $script:DeckCommanderChooserResult = $null

    Refresh-DeckCommanderList
    Set-DarkThemeRecursive -Control $dlg

    if ($dlg.ShowDialog($form) -eq [System.Windows.Forms.DialogResult]::OK) {
        $picked = $script:DeckCommanderChooserResult
        $script:DeckCommanderChooserResult = $null
        return $picked
    }

    $script:DeckCommanderChooserResult = $null
    return $null
}

function Apply-SmartCommanderSelection {
    param(
        $Picked,
        $Entries
    )

    if (-not $Picked) { return }

    $Script:PrimaryCommander = [string]$Picked.Name
    $Script:SecondaryCommander = ''
    $Script:CommanderMode = [string]$Picked.SuggestedMode
    $Script:SelectedCommanderNames = @($Script:PrimaryCommander)

    Update-CommanderSummaryText

    if ($Entries) {
        $updated = @(Apply-SelectedCommanders `
            -Entries $Entries `
            -CommanderNames @($Script:SelectedCommanderNames))

        Validate-Entries $updated

        # Persist the updated commander zone back into the active analysis.
        if ($Script:Analysis) {
            $Script:Analysis.Entries = $updated
            $Script:Analysis.Merged = @(Merge-Entries $updated)
        }

        Update-Preview `
            -Entries $updated `
            -SourceName $Script:Analysis.Source `
            -Ignored @()

        if ($Script:EditorMode) {
            Refresh-DeckEditorGrid -Entries $updated
        }

        Update-DeckStatsPanel
        Save-DeckAutosave
    }

    $status.Text = "Commander selected: $($Picked.Name)"
}

function Invoke-AutoCommanderChooser {
    param($Entries)

    if ($cmbFormat.Text -notmatch '(?i)Commander|Brawl') { return }
    if (-not [string]::IsNullOrWhiteSpace($Script:PrimaryCommander)) { return }
    if (-not $Entries) { return }

    # Clone the current entries so the deferred callback does not depend on a
    # mutable local variable from the load routine.
    $entryCopy = @($Entries)

    $form.BeginInvoke([System.Windows.Forms.MethodInvoker]{
        try {
            if (-not [string]::IsNullOrWhiteSpace($Script:PrimaryCommander)) {
                return
            }

            $status.Text = 'Checking deck for possible commanders...'
            $picked = Show-DeckCommanderChooser -Entries $entryCopy -Automatic

            if ($picked) {
                $status.Text = "Applying commander: $($picked.Name)..."
                Apply-SmartCommanderSelection -Picked $picked -Entries $entryCopy
            }
            else {
                $status.Text = 'Deck loaded. No commander selected.'
            }
        }
        catch {
            Show-DetailedError -ErrorRecord $_ -Context 'Automatic Smart Commander'
        }
    }) | Out-Null
}


function Show-SmartCommanderPicker {
    $folder = $cmbDest.Text.Trim()
    $dataRoot = Get-DataRootFromDeckFolder $folder

    if (-not $dataRoot) {
        throw 'Could not determine the Cockatrice data folder from the selected save location.'
    }

    $allCandidates = @(Get-LegendaryCreatureCandidates -DataRoot $dataRoot)

    $dlg = New-Object System.Windows.Forms.Form
    $dlg.Text = 'Smart Commander'
    $dlg.StartPosition = 'CenterParent'
    $dlg.Size = New-Object System.Drawing.Size(900,650)
    $dlg.MinimumSize = New-Object System.Drawing.Size(760,520)
    $dlg.Font = New-Object System.Drawing.Font('Segoe UI',9)

    $lblSearch = New-Object System.Windows.Forms.Label
    $lblSearch.Text = 'Search legendary creatures'
    $lblSearch.Location = New-Object System.Drawing.Point(12,12)
    $lblSearch.AutoSize = $true
    $dlg.Controls.Add($lblSearch)

    $txtSearch = New-Object System.Windows.Forms.TextBox
    $txtSearch.Location = New-Object System.Drawing.Point(12,34)
    $txtSearch.Size = New-Object System.Drawing.Size(430,25)
    $dlg.Controls.Add($txtSearch)

    $lblMode = New-Object System.Windows.Forms.Label
    $lblMode.Text = 'Commander type'
    $lblMode.Location = New-Object System.Drawing.Point(460,12)
    $lblMode.AutoSize = $true
    $dlg.Controls.Add($lblMode)

    $cmbModeFilter = New-Object System.Windows.Forms.ComboBox
    $cmbModeFilter.Location = New-Object System.Drawing.Point(460,34)
    $cmbModeFilter.Size = New-Object System.Drawing.Size(190,25)
    $cmbModeFilter.DropDownStyle = 'DropDownList'
    [void]$cmbModeFilter.Items.Add('All Types')
    [void]$cmbModeFilter.Items.Add('Regular Commander')
    [void]$cmbModeFilter.Items.Add('Partner')
    [void]$cmbModeFilter.Items.Add('Friends Forever')
    [void]$cmbModeFilter.Items.Add('Choose a Background')
    [void]$cmbModeFilter.Items.Add("Doctor + Doctor's Companion")
    [void]$cmbModeFilter.Items.Add('Partner With')
    $cmbModeFilter.SelectedIndex = 0
    $dlg.Controls.Add($cmbModeFilter)

    $list = New-Object System.Windows.Forms.ListBox
    $list.Location = New-Object System.Drawing.Point(12,72)
    $list.Size = New-Object System.Drawing.Size(430,500)
    $list.Anchor = 'Top,Bottom,Left'
    $dlg.Controls.Add($list)

    $previewPanel = New-Object System.Windows.Forms.Panel
    $previewPanel.Location = New-Object System.Drawing.Point(460,72)
    $previewPanel.Size = New-Object System.Drawing.Size(410,420)
    $previewPanel.Anchor = 'Top,Bottom,Left,Right'
    $dlg.Controls.Add($previewPanel)

    $pic = New-Object System.Windows.Forms.PictureBox
    $pic.Dock = 'Fill'
    $pic.SizeMode = 'Zoom'
    $previewPanel.Controls.Add($pic)

    $lblSelected = New-Object System.Windows.Forms.Label
    $lblSelected.Location = New-Object System.Drawing.Point(460,500)
    $lblSelected.Size = New-Object System.Drawing.Size(410,55)
    $lblSelected.Anchor = 'Bottom,Left,Right'
    $dlg.Controls.Add($lblSelected)

    $btnUse = New-Object System.Windows.Forms.Button
    $btnUse.Text = 'Use as Primary Commander'
    $btnUse.Location = New-Object System.Drawing.Point(650,575)
    $btnUse.Size = New-Object System.Drawing.Size(180,30)
    $btnUse.Anchor = 'Bottom,Right'
    $btnUse.Enabled = $false
    $dlg.Controls.Add($btnUse)

    $btnCancel = New-Object System.Windows.Forms.Button
    $btnCancel.Text = 'Cancel'
    $btnCancel.Location = New-Object System.Drawing.Point(560,575)
    $btnCancel.Size = New-Object System.Drawing.Size(80,30)
    $btnCancel.Anchor = 'Bottom,Right'
    $dlg.Controls.Add($btnCancel)

    $selection = $null

    function Refresh-SmartCommanderList {
        $needle = $txtSearch.Text.Trim()
        $modeFilter = [string]$cmbModeFilter.SelectedItem

        $list.BeginUpdate()
        $list.Items.Clear()

        foreach ($c in $allCandidates) {
            if ($needle -and
                $c.Name.IndexOf($needle,[System.StringComparison]::OrdinalIgnoreCase) -lt 0) {
                continue
            }

            if ($modeFilter -and $modeFilter -ne 'All Types' -and
                $c.SuggestedMode -ne $modeFilter) {
                continue
            }

            [void]$list.Items.Add($c)
        }

        $list.DisplayMember = 'Name'
        $list.EndUpdate()

        if ($list.Items.Count -gt 0) {
            $list.SelectedIndex = 0
        }
    }

    $txtSearch.Add_TextChanged({ Refresh-SmartCommanderList })
    $cmbModeFilter.Add_SelectedIndexChanged({ Refresh-SmartCommanderList })

    $list.Add_SelectedIndexChanged({
        try {
            $c = $list.SelectedItem
            if (-not $c) {
                $btnUse.Enabled = $false
                return
            }

            $selection = $c
            $btnUse.Enabled = $true
            $lblSelected.Text = "$($c.Name)`r`nDetected type: $($c.SuggestedMode)"

            $escaped = [uri]::EscapeDataString([string]$c.Name)
            $headers = @{
                'User-Agent' = 'CockatriceUniversalDeckImporter/3.1.4'
                'Accept' = 'application/json'
            }

            $card = Invoke-RestMethod -Uri "https://api.scryfall.com/cards/named?exact=$escaped" -Headers $headers -Method Get -ErrorAction Stop

            $imageUrl = $null
            if ($card.image_uris -and $card.image_uris.normal) {
                $imageUrl = [string]$card.image_uris.normal
            }
            elseif ($card.card_faces -and $card.card_faces.Count -gt 0 -and
                    $card.card_faces[0].image_uris.normal) {
                $imageUrl = [string]$card.card_faces[0].image_uris.normal
            }

            if ($imageUrl) {
                $wc = New-Object System.Net.WebClient
                $wc.Headers['User-Agent'] = 'CockatriceUniversalDeckImporter/3.1.4'
                $bytes = $wc.DownloadData($imageUrl)

                $ms = New-Object System.IO.MemoryStream(,$bytes)
                $img = [System.Drawing.Image]::FromStream($ms)

                if ($pic.Image) {
                    $old = $pic.Image
                    $pic.Image = $null
                    $old.Dispose()
                }

                if ($pic.Tag -is [System.IDisposable]) {
                    $pic.Tag.Dispose()
                }

                $pic.Image = $img
                $pic.Tag = $ms
            }
        }
        catch {
            $lblSelected.Text = "$($selection.Name)`r`nPreview unavailable."
        }
    })

    $btnUse.Add_Click({
        if ($selection) {
            $dlg.Tag = $selection
            $dlg.DialogResult = [System.Windows.Forms.DialogResult]::OK
            $dlg.Close()
        }
    })

    $btnCancel.Add_Click({
        $dlg.DialogResult = [System.Windows.Forms.DialogResult]::Cancel
        $dlg.Close()
    })

    Refresh-SmartCommanderList
    Set-DarkThemeRecursive -Control $dlg

    if ($dlg.ShowDialog($form) -eq [System.Windows.Forms.DialogResult]::OK) {
        return $dlg.Tag
    }

    return $null
}


# =============================================================================
# GUI
# =============================================================================


function Show-ScryfallSearchBasics {
    param([System.Windows.Forms.IWin32Window]$Owner)

    $helpDlg = New-Object System.Windows.Forms.Form
    $helpDlg.Text = 'Scryfall Search Basics - Offline Help'
    $helpDlg.StartPosition = [System.Windows.Forms.FormStartPosition]::CenterParent
    $helpDlg.Size = New-Object System.Drawing.Size(760,700)
    $helpDlg.MinimumSize = New-Object System.Drawing.Size(620,520)
    $helpDlg.Font = New-Object System.Drawing.Font('Segoe UI',9)

    $top = New-Object System.Windows.Forms.Panel
    $top.Dock = [System.Windows.Forms.DockStyle]::Top
    $top.Height = 64
    $top.Padding = New-Object System.Windows.Forms.Padding(10,8,10,4)
    $helpDlg.Controls.Add($top)

    $title = New-Object System.Windows.Forms.Label
    $title.Text = 'Scryfall Search Basics'
    $title.Dock = [System.Windows.Forms.DockStyle]::Top
    $title.Height = 25
    $title.Font = New-Object System.Drawing.Font('Segoe UI',12,[System.Drawing.FontStyle]::Bold)
    $top.Controls.Add($title)

    $intro = New-Object System.Windows.Forms.Label
    $intro.Text = 'Start with these common searches. Spaces combine filters; put - before a filter to exclude it.'
    $intro.Dock = [System.Windows.Forms.DockStyle]::Bottom
    $intro.Height = 25
    $top.Controls.Add($intro)

    $bottom = New-Object System.Windows.Forms.FlowLayoutPanel
    $bottom.Dock = [System.Windows.Forms.DockStyle]::Bottom
    $bottom.Height = 54
    $bottom.Padding = New-Object System.Windows.Forms.Padding(8,8,0,0)
    $bottom.FlowDirection = [System.Windows.Forms.FlowDirection]::RightToLeft
    $helpDlg.Controls.Add($bottom)

    $btnCloseHelp = New-Object System.Windows.Forms.Button
    $btnCloseHelp.Text = 'Close'
    $btnCloseHelp.Width = 90
    $bottom.Controls.Add($btnCloseHelp)

    $btnOfficial = New-Object System.Windows.Forms.Button
    $btnOfficial.Text = 'Official Scryfall Reference'
    $btnOfficial.Width = 165
    $bottom.Controls.Add($btnOfficial)

    $btnCopyBasics = New-Object System.Windows.Forms.Button
    $btnCopyBasics.Text = 'Copy Cheat Sheet'
    $btnCopyBasics.Width = 120
    $bottom.Controls.Add($btnCopyBasics)

    $grid = New-Object System.Windows.Forms.DataGridView
    $grid.Dock = [System.Windows.Forms.DockStyle]::Fill
    $grid.ReadOnly = $true
    $grid.AllowUserToAddRows = $false
    $grid.AllowUserToDeleteRows = $false
    $grid.AllowUserToResizeRows = $false
    $grid.RowHeadersVisible = $false
    $grid.SelectionMode = [System.Windows.Forms.DataGridViewSelectionMode]::FullRowSelect
    $grid.MultiSelect = $false
    $grid.AutoSizeRowsMode = [System.Windows.Forms.DataGridViewAutoSizeRowsMode]::AllCells
    $grid.BackgroundColor = [System.Drawing.Color]::FromArgb(32,32,32)
    $helpDlg.Controls.Add($grid)
    $grid.BringToFront()

    $colArea = New-Object System.Windows.Forms.DataGridViewTextBoxColumn
    $colArea.Name = 'Area'
    $colArea.HeaderText = 'What you want'
    $colArea.Width = 145
    [void]$grid.Columns.Add($colArea)

    $colSearch = New-Object System.Windows.Forms.DataGridViewTextBoxColumn
    $colSearch.Name = 'Search'
    $colSearch.HeaderText = 'Type this'
    $colSearch.Width = 205
    [void]$grid.Columns.Add($colSearch)

    $colMeaning = New-Object System.Windows.Forms.DataGridViewTextBoxColumn
    $colMeaning.Name = 'Meaning'
    $colMeaning.HeaderText = 'What it does'
    $colMeaning.AutoSizeMode = [System.Windows.Forms.DataGridViewAutoSizeColumnMode]::Fill
    $colMeaning.DefaultCellStyle.WrapMode = [System.Windows.Forms.DataGridViewTriState]::True
    [void]$grid.Columns.Add($colMeaning)

    $rows = @(
        @('Color', 'c:rg', 'Cards that are red and green.'),
        @('Commander colors', 'id<=esper t:instant', 'Instants that fit within an Esper commander color identity.'),
        @('Card type', 't:merfolk t:legend', 'Legendary Merfolk cards.'),
        @('Rules text', 'o:draw t:creature', 'Creatures whose current Oracle text deals with drawing cards.'),
        @('Keyword ability', 'kw:flying -t:creature', 'Noncreature cards with the Flying keyword.'),
        @('Mana value', 'c:u mv=5', 'Blue cards with mana value 5.'),
        @('Power', 'pow>=8', 'Cards with power 8 or greater.'),
        @('Rarity', 'r:common t:artifact', 'Common artifact cards.'),
        @('Set', 'e:war', 'Cards from War of the Spark.'),
        @('Format', 'c:g t:creature f:pauper', 'Green creatures legal in Pauper.'),
        @('Commander cards', 'is:commander', 'Cards that can be your commander.'),
        @('Exclude something', 'o:changeling -t:creature', 'Cards with Changeling in their text that are not creatures.'),
        @('Exact card name', '!"Lightning Bolt"', 'Only the card named Lightning Bolt.'),
        @('Either / OR', 't:fish OR t:bird', 'Cards that are Fish or Birds.')
    )

    foreach ($r in $rows) {
        [void]$grid.Rows.Add($r[0],$r[1],$r[2])
    }

    $cheatSheet = @"
Scryfall Search Basics

c:rg
Cards that are red and green.

id<=esper t:instant
Instants that fit within an Esper commander color identity.

t:merfolk t:legend
Legendary Merfolk cards.

o:draw t:creature
Creatures whose current Oracle text deals with drawing cards.

kw:flying -t:creature
Noncreature cards with the Flying keyword.

c:u mv=5
Blue cards with mana value 5.

pow>=8
Cards with power 8 or greater.

r:common t:artifact
Common artifact cards.

e:war
Cards from War of the Spark.

c:g t:creature f:pauper
Green creatures legal in Pauper.

is:commander
Cards that can be your commander.

o:changeling -t:creature
Cards with Changeling in their text that are not creatures.

!"Lightning Bolt"
Only the card named Lightning Bolt.

t:fish OR t:bird
Cards that are Fish or Birds.

Tips:
- Spaces combine filters.
- Prefix a filter with - to exclude it.
- Put phrases in quotes when they contain spaces.
- The Card Database Browser also accepts a simple word like myriad and searches card names first, then rules text.
"@

    $btnCopyBasics.Add_Click({
        try {
            [System.Windows.Forms.Clipboard]::SetText($cheatSheet)
            $btnCopyBasics.Text = 'Copied!'
        }
        catch {}
    })

    $btnOfficial.Add_Click({
        try {
            Start-Process 'https://scryfall.com/docs/syntax'
        }
        catch {
            [System.Windows.Forms.MessageBox]::Show(
                'Could not open the browser. The offline basics in this window are still available.',
                'Scryfall Search Help',
                [System.Windows.Forms.MessageBoxButtons]::OK,
                [System.Windows.Forms.MessageBoxIcon]::Information
            ) | Out-Null
        }
    })

    $btnCloseHelp.Add_Click({ $helpDlg.Close() })

    try { Set-DarkThemeRecursive -Control $helpDlg } catch {}

    if ($Owner) {
        [void]$helpDlg.ShowDialog($Owner)
    }
    else {
        [void]$helpDlg.ShowDialog()
    }
}

$form = New-Object System.Windows.Forms.Form
$form.Text = 'Cockatrice Universal Deck Importer 5.0 Release 3'

try {
    $os64 = [Environment]::Is64BitOperatingSystem
    $proc64 = [Environment]::Is64BitProcess
    Write-PerformanceLog -Stage 'Application started' `
        -Details ("OS64={0}; Process64={1}; PowerShell={2}" -f $os64,$proc64,$PSVersionTable.PSVersion)
}
catch {}

$form.StartPosition = 'CenterScreen'
$form.WindowState = [System.Windows.Forms.FormWindowState]::Maximized
$form.Size = New-Object System.Drawing.Size(1220,850)
$form.MinimumSize = New-Object System.Drawing.Size(1050,720)
$form.Font = New-Object System.Drawing.Font('Segoe UI',9)

$top = New-Object System.Windows.Forms.Panel
$top.Dock = 'Top'
$top.Height = 205
$form.Controls.Add($top)

$lblName = New-Object System.Windows.Forms.Label
$lblName.Text = 'Deck / Save Name'
$lblName.Location = New-Object System.Drawing.Point(12,10)
$lblName.AutoSize = $true
$top.Controls.Add($lblName)

$txtName = New-Object System.Windows.Forms.TextBox
$txtName.Location = New-Object System.Drawing.Point(12,32)
$txtName.Size = New-Object System.Drawing.Size(345,25)
$top.Controls.Add($txtName)

$lblFormat = New-Object System.Windows.Forms.Label
$lblFormat.Text = 'Format'
$lblFormat.Location = New-Object System.Drawing.Point(372,10)
$lblFormat.AutoSize = $true
$top.Controls.Add($lblFormat)

$cmbFormat = New-Object System.Windows.Forms.ComboBox
$cmbFormat.Location = New-Object System.Drawing.Point(372,32)
$cmbFormat.Size = New-Object System.Drawing.Size(170,25)
$cmbFormat.DropDownStyle = 'DropDown'
[void]$cmbFormat.Items.AddRange(@('Commander','Standard','Modern','Pioneer','Legacy','Vintage','Pauper','Brawl','Oathbreaker','Other'))
$cmbFormat.Text = 'Commander'
$top.Controls.Add($cmbFormat)

$lblCommander = New-Object System.Windows.Forms.Label
$lblCommander.Text = 'Commander(s)'
$lblCommander.Location = New-Object System.Drawing.Point(558,10)
$lblCommander.AutoSize = $true
$top.Controls.Add($lblCommander)

$txtCommander = New-Object System.Windows.Forms.TextBox
$txtCommander.Location = New-Object System.Drawing.Point(558,32)
$txtCommander.Size = New-Object System.Drawing.Size(465,25)
$txtCommander.ReadOnly = $true
$top.Controls.Add($txtCommander)
$txtCommander.Text = '(None)'

$btnSelectCommander = New-Object System.Windows.Forms.Button
$btnSelectCommander.Text = 'Commander Setup...'
$btnSelectCommander.Location = New-Object System.Drawing.Point(1032,30)
$btnSelectCommander.Size = New-Object System.Drawing.Size(156,29)
$top.Controls.Add($btnSelectCommander)

$btnSmartCommander = New-Object System.Windows.Forms.Button
$btnSmartCommander.Text = 'Smart Commander...'
$btnSmartCommander.Location = New-Object System.Drawing.Point(1032,58)
$btnSmartCommander.Size = New-Object System.Drawing.Size(156,25)
$top.Controls.Add($btnSmartCommander)


$lblCommanderColors = New-Object System.Windows.Forms.Label
$lblCommanderColors.Text = 'Color Identity: (None)'
$lblCommanderColors.Location = New-Object System.Drawing.Point(558,61)
$lblCommanderColors.Size = New-Object System.Drawing.Size(55,20)
$lblCommanderColors.ForeColor = [System.Drawing.Color]::DimGray
$top.Controls.Add($lblCommanderColors)

$grpCommanderHelp = New-Object System.Windows.Forms.GroupBox
$grpCommanderHelp.Text = 'Commander Quick Help'
$grpCommanderHelp.Location = New-Object System.Drawing.Point(0,8)
$grpCommanderHelp.Size = New-Object System.Drawing.Size(450,178)
$grpCommanderHelp.Anchor = 'Top'
$top.Controls.Add($grpCommanderHelp)

$lblCommanderHelp = New-Object System.Windows.Forms.Label
$lblCommanderHelp.Location = New-Object System.Drawing.Point(10,22)
$lblCommanderHelp.Size = New-Object System.Drawing.Size(425,118)
$lblCommanderHelp.AutoSize = $false
$lblCommanderHelp.Text = @"
1. Choose Format.
2. Load a deck; Smart Commander can auto-pick.
3. Smart Commander is below Setup.
4. Add Partner / Background / Doctor's Companion if allowed.
5. Companion is separate.
6. Color Identity updates automatically.
7. Off-color cards warn before adding.
"@
$grpCommanderHelp.Controls.Add($lblCommanderHelp)

$btnCommanderFullHelp = New-Object System.Windows.Forms.Button
$btnCommanderFullHelp.Text = 'Full Help...'
$btnCommanderFullHelp.Location = New-Object System.Drawing.Point(10,142)
$btnCommanderFullHelp.Size = New-Object System.Drawing.Size(95,27)
$grpCommanderHelp.Controls.Add($btnCommanderFullHelp)

function Update-CommanderHelpPosition {
    try {
        # Keep a clearly visible gap from Commander Setup while avoiding
        # the extreme far-right edge on wide/maximized displays.
        $preferredX = 1260
        $rightSafeX = $top.ClientSize.Width - $grpCommanderHelp.Width - 12

        $x = [Math]::Min($preferredX, $rightSafeX)

        # Minimum gap from the Commander controls.
        if ($x -lt 1220) {
            $x = 1220
        }

        $grpCommanderHelp.Location = New-Object System.Drawing.Point($x,12)
        $grpCommanderHelp.BringToFront()
    }
    catch {}
}

$tipCommander = New-Object System.Windows.Forms.ToolTip
$tipCommander.SetToolTip(
    $btnSelectCommander,
    "Configure primary commander, partner/background/secondary commander, and optional companion."
)

$lblDest = New-Object System.Windows.Forms.Label
$lblDest.Text = 'Save Location'
$lblDest.Location = New-Object System.Drawing.Point(12,70)
$lblDest.AutoSize = $true
$top.Controls.Add($lblDest)

$cmbDest = New-Object System.Windows.Forms.ComboBox
$cmbDest.Location = New-Object System.Drawing.Point(12,92)
$cmbDest.Size = New-Object System.Drawing.Size(960,25)
$cmbDest.DropDownStyle = 'DropDown'
$top.Controls.Add($cmbDest)

$btnBrowse = New-Object System.Windows.Forms.Button
$btnBrowse.Text = 'Browse...'
$btnBrowse.Location = New-Object System.Drawing.Point(982,90)
$btnBrowse.Size = New-Object System.Drawing.Size(95,29)
$top.Controls.Add($btnBrowse)

$btnOpenFolder = New-Object System.Windows.Forms.Button
$btnOpenFolder.Text = 'Open Folder'
$btnOpenFolder.Location = New-Object System.Drawing.Point(1085,90)
$btnOpenFolder.Size = New-Object System.Drawing.Size(103,29)
$top.Controls.Add($btnOpenFolder)

$Script:SelectedTags = @()

$lblTags = New-Object System.Windows.Forms.Label
$lblTags.Text = 'Cockatrice Tags'
$lblTags.Location = New-Object System.Drawing.Point(12,124)
$lblTags.AutoSize = $true
$top.Controls.Add($lblTags)

$txtTags = New-Object System.Windows.Forms.TextBox
$txtTags.Location = New-Object System.Drawing.Point(12,146)
$txtTags.Size = New-Object System.Drawing.Size(325,25)
$txtTags.ReadOnly = $true
$txtTags.Text = '(None)'
$top.Controls.Add($txtTags)

$btnTags = New-Object System.Windows.Forms.Button
$btnTags.Text = 'Manage Tags...'
$btnTags.Location = New-Object System.Drawing.Point(347,144)
$btnTags.Size = New-Object System.Drawing.Size(105,29)
$top.Controls.Add($btnTags)

$help = New-Object System.Windows.Forms.Label
$help.Text = 'Smart / manual / custom tags'
$help.Location = New-Object System.Drawing.Point(1018,150)
$help.AutoSize = $true
$help.ForeColor = [System.Drawing.Color]::DimGray
$top.Controls.Add($help)

$lblDeckStats = New-Object System.Windows.Forms.Label
$lblDeckStats.Text = 'Deck Stats: no deck loaded'
$lblDeckStats.Location = New-Object System.Drawing.Point(8,178)
$lblDeckStats.Size = New-Object System.Drawing.Size(1180,22)
$lblDeckStats.Anchor = 'Left,Top,Right'
$top.Controls.Add($lblDeckStats)

$manaIdentityPanel = New-Object System.Windows.Forms.Panel
$manaIdentityPanel.Location = New-Object System.Drawing.Point(545,58)
$manaIdentityPanel.Size = New-Object System.Drawing.Size(150,26)
$manaIdentityPanel.Anchor = 'Top,Left'
$manaIdentityPanel.BackColor = [System.Drawing.Color]::Transparent
$top.Controls.Add($manaIdentityPanel)

$lblAutosave = New-Object System.Windows.Forms.Label
$lblAutosave.Text = 'Autosave ready'
$lblAutosave.Location = New-Object System.Drawing.Point(1195,178)
$lblAutosave.Size = New-Object System.Drawing.Size(190,22)
$lblAutosave.Anchor = 'Top,Left'
$lblAutosave.ForeColor = [System.Drawing.Color]::DimGray
$top.Controls.Add($lblAutosave)

$manaIdentityPanel.Add_Paint({
    param($sender,$e)
    $colors = @(Get-CommanderColorIdentity)
    Draw-ManaIdentityBadges -Graphics $e.Graphics -Colors $colors -Bounds $sender.ClientRectangle
})


$split = New-Object System.Windows.Forms.SplitContainer
$split.Dock = 'Fill'
$split.SplitterDistance = 600
$form.Controls.Add($split)
$split.BringToFront()

# Left input panel
$leftTitle = New-Object System.Windows.Forms.Label
$leftTitle.Text = 'Moxfield / Archidekt URL or pasted deck list'
$leftTitle.Dock = 'Top'
$leftTitle.Height = 28
$leftTitle.Padding = New-Object System.Windows.Forms.Padding(7,7,0,0)
$split.Panel1.Controls.Add($leftTitle)

$leftButtons = New-Object System.Windows.Forms.FlowLayoutPanel
$leftButtons.Dock = 'Bottom'
$leftButtons.Height = 48
$leftButtons.Padding = New-Object System.Windows.Forms.Padding(6,7,0,0)
$split.Panel1.Controls.Add($leftButtons)

$btnPaste = New-Object System.Windows.Forms.Button
$btnPaste.Text = 'Paste Deck / Link'
$btnPaste.Width = 120
$leftButtons.Controls.Add($btnPaste)

$btnLoad = New-Object System.Windows.Forms.Button
$btnLoad.Text = 'Load Web Deck'
$btnLoad.Width = 100
$leftButtons.Controls.Add($btnLoad)

$btnLoadCod = New-Object System.Windows.Forms.Button
$btnLoadCod.Text = 'Load Cockatrice Deck'
$btnLoadCod.Width = 145
$leftButtons.Controls.Add($btnLoadCod)

$btnNewDeck = New-Object System.Windows.Forms.Button
$btnNewDeck.Text = 'New Deck'
$btnNewDeck.Width = 85
$leftButtons.Controls.Add($btnNewDeck)

$btnClear = New-Object System.Windows.Forms.Button
$btnClear.Text = 'Clear'
$btnClear.Width = 70
$leftButtons.Controls.Add($btnClear)

$chkMaybe = New-Object System.Windows.Forms.CheckBox
$chkMaybe.Text = 'Include maybeboard'
$chkMaybe.AutoSize = $true
$chkMaybe.Padding = New-Object System.Windows.Forms.Padding(8,5,0,0)
$leftButtons.Controls.Add($chkMaybe)

$txtInput = New-Object System.Windows.Forms.TextBox
$txtInput.Multiline = $true
$txtInput.ScrollBars = 'Both'
$txtInput.WordWrap = $false
$txtInput.AcceptsReturn = $true
$txtInput.AcceptsTab = $true
$txtInput.Dock = 'Fill'
$txtInput.Font = New-Object System.Drawing.Font('Consolas',9)
$split.Panel1.Controls.Add($txtInput)
$txtInput.BringToFront()

# Parsed-deck editor. Hidden until Modify Deck is clicked.
$deckEditorPanel = New-Object System.Windows.Forms.Panel
$deckEditorPanel.Dock = 'Fill'
$deckEditorPanel.Visible = $false
$split.Panel1.Controls.Add($deckEditorPanel)

$deckEditorButtons = New-Object System.Windows.Forms.FlowLayoutPanel
$deckEditorButtons.Dock = 'Bottom'
$deckEditorButtons.Height = 52
$deckEditorButtons.Padding = New-Object System.Windows.Forms.Padding(6,7,0,0)
$deckEditorPanel.Controls.Add($deckEditorButtons)

$btnEditorAdd = New-Object System.Windows.Forms.Button
$btnEditorAdd.Text = 'Add Card'
$btnEditorAdd.Width = 85
$deckEditorButtons.Controls.Add($btnEditorAdd)

$btnEditorRemove = New-Object System.Windows.Forms.Button
$btnEditorRemove.Text = 'Remove Selected'
$btnEditorRemove.Width = 120
$deckEditorButtons.Controls.Add($btnEditorRemove)

$btnEditorApply = New-Object System.Windows.Forms.Button
$btnEditorApply.Text = 'Apply / Validate'
$btnEditorApply.Width = 110
$deckEditorButtons.Controls.Add($btnEditorApply)

$btnEditorBack = New-Object System.Windows.Forms.Button
$btnEditorBack.Text = 'Back to Import'
$btnEditorBack.Width = 100
$deckEditorButtons.Controls.Add($btnEditorBack)

$btnEditorRestore = New-Object System.Windows.Forms.Button
$btnEditorRestore.Text = 'Restore Original'
$btnEditorRestore.Width = 105
$deckEditorButtons.Controls.Add($btnEditorRestore)

$btnEditorPreview = New-Object System.Windows.Forms.Button
$btnEditorPreview.Text = 'Choose Art'
$btnEditorPreview.Width = 90
$deckEditorButtons.Controls.Add($btnEditorPreview)


$lblDeckFilter = New-Object System.Windows.Forms.Label
$lblDeckFilter.Text = 'Find:'
$lblDeckFilter.Width = 35
$lblDeckFilter.TextAlign = [System.Drawing.ContentAlignment]::MiddleLeft
$deckEditorButtons.Controls.Add($lblDeckFilter)

$txtDeckFilter = New-Object System.Windows.Forms.TextBox
$txtDeckFilter.Width = 220
$deckEditorButtons.Controls.Add($txtDeckFilter)

$btnClearFilter = New-Object System.Windows.Forms.Button
$btnClearFilter.Text = 'Clear Find'
$btnClearFilter.Width = 80
$deckEditorButtons.Controls.Add($btnClearFilter)


$lblHoverDelay = New-Object System.Windows.Forms.Label
$lblHoverDelay.Text = 'Hover:'
$lblHoverDelay.Width = 45
$lblHoverDelay.TextAlign = [System.Drawing.ContentAlignment]::MiddleLeft
$deckEditorButtons.Controls.Add($lblHoverDelay)

$cmbHoverDelay = New-Object System.Windows.Forms.ComboBox
$cmbHoverDelay.Width = 80
$cmbHoverDelay.DropDownStyle = [System.Windows.Forms.ComboBoxStyle]::DropDownList
foreach ($ms in @(100,150,200,250,300,350,400,450,500)) {
    [void]$cmbHoverDelay.Items.Add("$ms ms")
}
$cmbHoverDelay.SelectedItem = '150 ms'
$deckEditorButtons.Controls.Add($cmbHoverDelay)


# Deck editor body: editable card grid on the left and live card preview on the right.
$editorSplit = New-Object System.Windows.Forms.SplitContainer
$editorSplit.Dock = 'Fill'
$editorSplit.Orientation = [System.Windows.Forms.Orientation]::Vertical
$editorSplit.SplitterWidth = 6
$editorSplit.SplitterDistance = 600
$deckEditorPanel.Controls.Add($editorSplit)
$editorSplit.BringToFront()

$livePreviewPanel = New-Object System.Windows.Forms.Panel
$livePreviewPanel.Dock = 'Fill'
$livePreviewPanel.Padding = New-Object System.Windows.Forms.Padding(8)
$editorSplit.Panel2.Controls.Add($livePreviewPanel)

$lblLivePreviewTitle = New-Object System.Windows.Forms.Label
$lblLivePreviewTitle.Text = 'Card Search / Tools'
$lblLivePreviewTitle.Visible = $false
$lblLivePreviewTitle.Height = 0
$lblLivePreviewTitle.Dock = 'Top'
$lblLivePreviewTitle.Height = 26
$lblLivePreviewTitle.Font = New-Object System.Drawing.Font('Segoe UI',9,[System.Drawing.FontStyle]::Bold)
$livePreviewPanel.Controls.Add($lblLivePreviewTitle)

$scrySearchPanel = New-Object System.Windows.Forms.Panel
$scrySearchPanel.Dock = 'Top'
$scrySearchPanel.Height = 390
$livePreviewPanel.Controls.Add($scrySearchPanel)

# ---------------- Cockatrice local card search ----------------
$lblLocalSearch = New-Object System.Windows.Forms.Label
$lblLocalSearch.Text = 'Cockatrice Card Search'
$lblLocalSearch.Location = New-Object System.Drawing.Point(0,4)
$lblLocalSearch.AutoSize = $true
$lblLocalSearch.Font = New-Object System.Drawing.Font('Segoe UI',9,[System.Drawing.FontStyle]::Bold)
$scrySearchPanel.Controls.Add($lblLocalSearch)

$lblLocalInstructions = New-Object System.Windows.Forms.Label
$lblLocalInstructions.Text = 'Start typing a card name from your Cockatrice cards.xml'
$lblLocalInstructions.Location = New-Object System.Drawing.Point(0,23)
$lblLocalInstructions.AutoSize = $true
$lblLocalInstructions.ForeColor = [System.Drawing.Color]::DimGray
$scrySearchPanel.Controls.Add($lblLocalInstructions)

$txtLocalCardSearch = New-Object System.Windows.Forms.TextBox
$txtLocalCardSearch.Location = New-Object System.Drawing.Point(0,45)
$txtLocalCardSearch.Size = New-Object System.Drawing.Size(265,24)
$txtLocalCardSearch.Anchor = 'Top,Left,Right'
$txtLocalCardSearch.AutoCompleteMode = [System.Windows.Forms.AutoCompleteMode]::SuggestAppend
$txtLocalCardSearch.AutoCompleteSource = [System.Windows.Forms.AutoCompleteSource]::CustomSource
$scrySearchPanel.Controls.Add($txtLocalCardSearch)

$lblLocalZone = New-Object System.Windows.Forms.Label
$lblLocalZone.Text = 'Zone:'
$lblLocalZone.Location = New-Object System.Drawing.Point(275,49)
$lblLocalZone.AutoSize = $true
$lblLocalZone.Anchor = 'Top,Right'
$scrySearchPanel.Controls.Add($lblLocalZone)

$cmbLocalZone = New-Object System.Windows.Forms.ComboBox
$cmbLocalZone.Location = New-Object System.Drawing.Point(315,45)
$cmbLocalZone.Size = New-Object System.Drawing.Size(90,25)
$cmbLocalZone.Anchor = 'Top,Right'
$cmbLocalZone.DropDownStyle = 'DropDownList'
[void]$cmbLocalZone.Items.Add('main')
[void]$cmbLocalZone.Items.Add('commander')
[void]$cmbLocalZone.Items.Add('side')
$cmbLocalZone.SelectedIndex = 0
$scrySearchPanel.Controls.Add($cmbLocalZone)

$btnLocalAdd = New-Object System.Windows.Forms.Button
$btnLocalAdd.Text = 'Add Local Card'
$btnLocalAdd.Location = New-Object System.Drawing.Point(0,76)
$btnLocalAdd.Size = New-Object System.Drawing.Size(110,28)
$scrySearchPanel.Controls.Add($btnLocalAdd)

$btnBrowseCards = New-Object System.Windows.Forms.Button
$btnBrowseCards.Text = 'Browse Card Database'
$btnBrowseCards.Location = New-Object System.Drawing.Point(0,347)
$btnBrowseCards.Size = New-Object System.Drawing.Size(170,30)
$scrySearchPanel.Controls.Add($btnBrowseCards)

$lblDivider = New-Object System.Windows.Forms.Label
$lblDivider.Text = 'or use advanced Scryfall syntax'
$lblDivider.Location = New-Object System.Drawing.Point(0,112)
$lblDivider.AutoSize = $true
$lblDivider.ForeColor = [System.Drawing.Color]::DimGray
$scrySearchPanel.Controls.Add($lblDivider)

# ---------------- Scryfall syntax search ----------------
$lblScrySearch = New-Object System.Windows.Forms.Label
$lblScrySearch.Text = 'Scryfall Search'
$lblScrySearch.Location = New-Object System.Drawing.Point(0,132)
$lblScrySearch.AutoSize = $true
$lblScrySearch.Font = New-Object System.Drawing.Font('Segoe UI',9,[System.Drawing.FontStyle]::Bold)
$scrySearchPanel.Controls.Add($lblScrySearch)

$lblScryInstructions = New-Object System.Windows.Forms.Label
$lblScryInstructions.Text = 'Type Scryfall syntax, then press Enter or click Search.'
$lblScryInstructions.Location = New-Object System.Drawing.Point(0,151)
$lblScryInstructions.AutoSize = $true
$lblScryInstructions.ForeColor = [System.Drawing.Color]::DimGray
$scrySearchPanel.Controls.Add($lblScryInstructions)

$txtScryfallSearch = New-Object System.Windows.Forms.TextBox
$txtScryfallSearch.Location = New-Object System.Drawing.Point(0,173)
$txtScryfallSearch.Size = New-Object System.Drawing.Size(275,24)
$txtScryfallSearch.Anchor = 'Top,Left,Right'
$scrySearchPanel.Controls.Add($txtScryfallSearch)

$btnScryfallSearch = New-Object System.Windows.Forms.Button
$btnScryfallSearch.Text = 'Search'
$btnScryfallSearch.Location = New-Object System.Drawing.Point(0,202)
$btnScryfallSearch.Size = New-Object System.Drawing.Size(85,27)
$scrySearchPanel.Controls.Add($btnScryfallSearch)

$btnScrySearchHelp = New-Object System.Windows.Forms.Button
$btnScrySearchHelp.Text = 'Search Help'
$btnScrySearchHelp.Location = New-Object System.Drawing.Point(95,202)
$btnScrySearchHelp.Size = New-Object System.Drawing.Size(95,27)
$scrySearchPanel.Controls.Add($btnScrySearchHelp)

$cmbScryResults = New-Object System.Windows.Forms.ComboBox
$cmbScryResults.Location = New-Object System.Drawing.Point(0,234)
$cmbScryResults.Size = New-Object System.Drawing.Size(275,25)
$cmbScryResults.Anchor = 'Top,Left,Right'
$cmbScryResults.DropDownStyle = 'DropDownList'
$scrySearchPanel.Controls.Add($cmbScryResults)

$lblScryZone = New-Object System.Windows.Forms.Label
$lblScryZone.Text = 'Add selected result to:'
$lblScryZone.Location = New-Object System.Drawing.Point(0,265)
$lblScryZone.AutoSize = $true
$scrySearchPanel.Controls.Add($lblScryZone)

$cmbScryZone = New-Object System.Windows.Forms.ComboBox
$cmbScryZone.Location = New-Object System.Drawing.Point(0,284)
$cmbScryZone.Size = New-Object System.Drawing.Size(120,25)
$cmbScryZone.DropDownStyle = 'DropDownList'
[void]$cmbScryZone.Items.Add('main')
[void]$cmbScryZone.Items.Add('commander')
[void]$cmbScryZone.Items.Add('side')
$cmbScryZone.SelectedIndex = 0
$scrySearchPanel.Controls.Add($cmbScryZone)

$btnScryAdd = New-Object System.Windows.Forms.Button
$btnScryAdd.Text = 'Add Selected to Deck'
$btnScryAdd.Location = New-Object System.Drawing.Point(130,282)
$btnScryAdd.Size = New-Object System.Drawing.Size(145,28)
$btnScryAdd.Enabled = $false
$scrySearchPanel.Controls.Add($btnScryAdd)

# ---------------- Card Search / Tools ----------------
$lblToolsSection = New-Object System.Windows.Forms.Label
$lblToolsSection.Text = 'Card Search / Tools'
$lblToolsSection.Location = New-Object System.Drawing.Point(0,322)
$lblToolsSection.AutoSize = $true
$lblToolsSection.Font = New-Object System.Drawing.Font('Segoe UI',9,[System.Drawing.FontStyle]::Bold)
$scrySearchPanel.Controls.Add($lblToolsSection)

# Fixed card image removed in 3.1.0.
# Lightweight hidden compatibility controls remain so older helper functions
# cannot break if called by a legacy event path.
$lblLivePreviewName = New-Object System.Windows.Forms.Label
$lblLivePreviewName.Visible = $false

$picLivePreview = New-Object System.Windows.Forms.PictureBox
$picLivePreview.Visible = $false


$gridDeckEditor = New-Object System.Windows.Forms.DataGridView
$gridDeckEditor.Dock = 'Fill'
$gridDeckEditor.AllowUserToAddRows = $false
$gridDeckEditor.AllowUserToDeleteRows = $true
$gridDeckEditor.AllowUserToResizeRows = $false
$gridDeckEditor.RowHeadersVisible = $false
$gridDeckEditor.SelectionMode = 'FullRowSelect'
$gridDeckEditor.MultiSelect = $true
$gridDeckEditor.AutoSizeColumnsMode = 'None'
$gridDeckEditor.BackgroundColor = [System.Drawing.SystemColors]::Window
$gridDeckEditor.EditMode = 'EditOnKeystrokeOrF2'
$editorSplit.Panel1.Controls.Add($gridDeckEditor)
$gridDeckEditor.BringToFront()

$deckContextMenu = New-Object System.Windows.Forms.ContextMenuStrip

$ctxSetCommander = New-Object System.Windows.Forms.ToolStripMenuItem('Set as Commander')
$ctxMoveMain = New-Object System.Windows.Forms.ToolStripMenuItem('Move to Main')
$ctxMoveSide = New-Object System.Windows.Forms.ToolStripMenuItem('Move to Sideboard')
$ctxPreview = New-Object System.Windows.Forms.ToolStripMenuItem('Choose Art / Printing')
$ctxRemove = New-Object System.Windows.Forms.ToolStripMenuItem('Remove Selected')

[void]$deckContextMenu.Items.Add($ctxSetCommander)
[void]$deckContextMenu.Items.Add($ctxMoveMain)
[void]$deckContextMenu.Items.Add($ctxMoveSide)
[void]$deckContextMenu.Items.Add((New-Object System.Windows.Forms.ToolStripSeparator))
[void]$deckContextMenu.Items.Add($ctxPreview)
[void]$deckContextMenu.Items.Add($ctxRemove)


$gridDeckEditor.Add_DataError({
    param($sender, $e)

    # Prevent WinForms from showing its default modal DataGridView error dialog.
    $e.ThrowException = $false

    try {
        $status.Text = "Deck editor corrected an invalid cell value. Click Apply / Validate to refresh."
    }
    catch {}
})

$gridDeckEditor.ContextMenuStrip = $deckContextMenu


$colQty = New-Object System.Windows.Forms.DataGridViewTextBoxColumn
$colQty.Name = 'Qty'
$colQty.HeaderText = 'Qty'
$colQty.Width = 48
[void]$gridDeckEditor.Columns.Add($colQty)

$colName = New-Object System.Windows.Forms.DataGridViewTextBoxColumn
$colName.Name = 'CardName'
$colName.HeaderText = 'Card Name'
$colName.Width = 325
[void]$gridDeckEditor.Columns.Add($colName)

$colZone = New-Object System.Windows.Forms.DataGridViewComboBoxColumn
$colZone.Name = 'Zone'
$colZone.HeaderText = 'Zone'
$colZone.Width = 100
$colZone.FlatStyle = 'Flat'
[void]$colZone.Items.Add('main')
[void]$colZone.Items.Add('commander')
[void]$colZone.Items.Add('side')
[void]$gridDeckEditor.Columns.Add($colZone)

$colType = New-Object System.Windows.Forms.DataGridViewTextBoxColumn
$colType.Name = 'CardType'
$colType.HeaderText = 'Type'
$colType.Width = 85
$colType.ReadOnly = $true
[void]$gridDeckEditor.Columns.Add($colType)

$colValid = New-Object System.Windows.Forms.DataGridViewCheckBoxColumn
$colValid.Name = 'Valid'
$colValid.HeaderText = 'OK'
$colValid.Width = 42
$colValid.ReadOnly = $true
[void]$gridDeckEditor.Columns.Add($colValid)

$colStatus = New-Object System.Windows.Forms.DataGridViewTextBoxColumn
$colStatus.Name = 'Status'
$colStatus.HeaderText = 'Validation'
$colStatus.Width = 300
$colStatus.ReadOnly = $true
[void]$gridDeckEditor.Columns.Add($colStatus)

# Right results panel
$rightTitle = New-Object System.Windows.Forms.Label
$rightTitle.Text = 'Smart checker / final preview'
$rightTitle.Dock = 'Top'
$rightTitle.Height = 28
$rightTitle.Padding = New-Object System.Windows.Forms.Padding(7,7,0,0)
$split.Panel2.Controls.Add($rightTitle)

$rightBottom = New-Object System.Windows.Forms.Panel
$rightBottom.Dock = 'Bottom'
$rightBottom.Height = 118
$split.Panel2.Controls.Add($rightBottom)

$lblComments = New-Object System.Windows.Forms.Label
$lblComments.Text = 'Comments (optional)'
$lblComments.Location = New-Object System.Drawing.Point(8,7)
$lblComments.AutoSize = $true
$rightBottom.Controls.Add($lblComments)

$txtComments = New-Object System.Windows.Forms.TextBox
$txtComments.Location = New-Object System.Drawing.Point(8,28)
$txtComments.Size = New-Object System.Drawing.Size(575,24)
$rightBottom.Controls.Add($txtComments)

$chkInvalid = New-Object System.Windows.Forms.CheckBox
$chkInvalid.Text = 'Allow unresolved names (not recommended)'
$chkInvalid.Location = New-Object System.Drawing.Point(8,57)
$chkInvalid.AutoSize = $true
$rightBottom.Controls.Add($chkInvalid)

$btnAnalyze = New-Object System.Windows.Forms.Button
$btnAnalyze.Text = 'Recheck'
$btnAnalyze.Location = New-Object System.Drawing.Point(8,83)
$btnAnalyze.Size = New-Object System.Drawing.Size(82,28)
$rightBottom.Controls.Add($btnAnalyze)

$btnModifyDeck = New-Object System.Windows.Forms.Button
$btnModifyDeck.Text = 'Modify Deck'
$btnModifyDeck.Width = 100
$btnModifyDeck.Enabled = $false
$leftButtons.Controls.Add($btnModifyDeck)
$leftButtons.Controls.SetChildIndex($btnModifyDeck, 4)

$btnSave = New-Object System.Windows.Forms.Button
$btnSave.Text = 'Save Verified .COD'
$btnSave.Location = New-Object System.Drawing.Point(462,144)
$btnSave.Size = New-Object System.Drawing.Size(145,29)
$btnSave.Enabled = $false
$top.Controls.Add($btnSave)

$btnOpenSaved = New-Object System.Windows.Forms.Button
$btnOpenSaved.Text = 'Open Last Saved'
$btnOpenSaved.Location = New-Object System.Drawing.Point(617,144)
$btnOpenSaved.Size = New-Object System.Drawing.Size(135,29)
$btnOpenSaved.Enabled = $false
$top.Controls.Add($btnOpenSaved)

$btnOverwriteOriginal = New-Object System.Windows.Forms.Button
$btnOverwriteOriginal.Text = 'Overwrite Original'
$btnOverwriteOriginal.Location = New-Object System.Drawing.Point(762,144)
$btnOverwriteOriginal.Size = New-Object System.Drawing.Size(135,29)
$btnOverwriteOriginal.Enabled = $false
$top.Controls.Add($btnOverwriteOriginal)

$btnExportText = New-Object System.Windows.Forms.Button
$btnExportText.Text = 'Export Text'
$btnExportText.Location = New-Object System.Drawing.Point(907,144)
$btnExportText.Size = New-Object System.Drawing.Size(100,29)
$btnExportText.Enabled = $false
$top.Controls.Add($btnExportText)

$btnCopyError = New-Object System.Windows.Forms.Button
$btnCopyError.Text = 'Copy Error'
$btnCopyError.Location = New-Object System.Drawing.Point(100,83)
$btnCopyError.Size = New-Object System.Drawing.Size(95,28)
$rightBottom.Controls.Add($btnCopyError)

$txtResults = New-Object System.Windows.Forms.TextBox
$txtResults.Multiline = $true
$txtResults.ScrollBars = 'Both'
$txtResults.WordWrap = $false
$txtResults.ReadOnly = $true
$txtResults.Dock = 'Fill'
$txtResults.Font = New-Object System.Drawing.Font('Consolas',9)
$split.Panel2.Controls.Add($txtResults)
$txtResults.BringToFront()

$statusStrip = New-Object System.Windows.Forms.StatusStrip
$status = New-Object System.Windows.Forms.ToolStripStatusLabel
$status.Spring = $true
$status.TextAlign = 'MiddleLeft'
$status.Text = 'Ready.'
[void]$statusStrip.Items.Add($status)
$form.Controls.Add($statusStrip)

# Populate destination list.
$folders = @(Get-DeckFolders)
foreach ($f in $folders) { [void]$cmbDest.Items.Add($f) }
if ($folders.Count -gt 0) { $cmbDest.SelectedIndex = 0 }

if (Test-Path -LiteralPath $SettingsPath -PathType Leaf) {
    try {
        $j = Get-Content -LiteralPath $SettingsPath -Raw | ConvertFrom-Json
        if ($j.DeckFolder) { $cmbDest.Text = [string]$j.DeckFolder }
        if ($j.HoverPreviewDelay) {
            $d = [int]$j.HoverPreviewDelay
            if ($d -ge 100 -and $d -le 500 -and (($d - 100) % 50 -eq 0)) {
                $Script:HoverPreviewDelay = $d
                if ($cmbHoverDelay) { $cmbHoverDelay.SelectedItem = "$d ms" }
            }
        }
    }
    catch {}
}






function Get-ScryfallImageUrl {
    param(
        [string]$CardName,
        [string]$PrintingUUID=''
    )

    if ([string]::IsNullOrWhiteSpace($CardName) -and [string]::IsNullOrWhiteSpace($PrintingUUID)) {
        return $null
    }

    $cacheKey = if ($PrintingUUID) { "uuid:$PrintingUUID" } else { "name:$($CardName.ToLowerInvariant())" }

    if ($Script:HoverPreviewImageUrlCache.ContainsKey($cacheKey)) {
        return [string]$Script:HoverPreviewImageUrlCache[$cacheKey]
    }

    try {
        $headers = @{
            'User-Agent' = 'CockatriceUniversalDeckImporter/3.1.4'
            'Accept' = 'application/json'
        }

        if ($PrintingUUID) {
            $api = "https://api.scryfall.com/cards/$PrintingUUID"
        }
        else {
            $escaped = [uri]::EscapeDataString($CardName)
            $api = "https://api.scryfall.com/cards/named?exact=$escaped"
        }

        $card = Invoke-RestMethod -Uri $api -Headers $headers -Method Get -ErrorAction Stop
        $imageUrl = $null

        if ($card.image_uris -and $card.image_uris.normal) {
            $imageUrl = [string]$card.image_uris.normal
        }
        elseif ($card.card_faces -and
                $card.card_faces.Count -gt 0 -and
                $card.card_faces[0].image_uris -and
                $card.card_faces[0].image_uris.normal) {
            $imageUrl = [string]$card.card_faces[0].image_uris.normal
        }

        if ($imageUrl) {
            # Strings only; tiny cache even on 8 GB systems.
            if ($Script:HoverPreviewImageUrlCache.Count -gt 250) {
                $Script:HoverPreviewImageUrlCache.Clear()
            }
            $Script:HoverPreviewImageUrlCache[$cacheKey] = $imageUrl
        }

        return $imageUrl
    }
    catch {
        return $null
    }
}

function Initialize-HoverPreviewPopup {
    if ($Script:HoverPreviewForm -and -not $Script:HoverPreviewForm.IsDisposed) {
        return
    }

    $Script:HoverPreviewForm = New-Object System.Windows.Forms.Form
    $Script:HoverPreviewForm.FormBorderStyle = [System.Windows.Forms.FormBorderStyle]::FixedSingle
    $Script:HoverPreviewForm.ShowInTaskbar = $false
    $Script:HoverPreviewForm.StartPosition = [System.Windows.Forms.FormStartPosition]::Manual
    $Script:HoverPreviewForm.TopMost = $true
    $Script:HoverPreviewForm.ControlBox = $false
    $Script:HoverPreviewForm.Text = ''
    $Script:HoverPreviewForm.BackColor = [System.Drawing.Color]::FromArgb(24,24,24)

    $Script:HoverPreviewPicture = New-Object System.Windows.Forms.PictureBox
    $Script:HoverPreviewPicture.Dock = [System.Windows.Forms.DockStyle]::Fill
    $Script:HoverPreviewPicture.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::Zoom
    $Script:HoverPreviewPicture.BackColor = [System.Drawing.Color]::Black
    $Script:HoverPreviewForm.Controls.Add($Script:HoverPreviewPicture)

    $Script:HoverPreviewLabel = New-Object System.Windows.Forms.Label
    $Script:HoverPreviewLabel.Dock = [System.Windows.Forms.DockStyle]::Bottom
    $Script:HoverPreviewLabel.Height = 30
    $Script:HoverPreviewLabel.TextAlign = [System.Drawing.ContentAlignment]::MiddleCenter
    $Script:HoverPreviewLabel.ForeColor = [System.Drawing.Color]::White
    $Script:HoverPreviewLabel.BackColor = [System.Drawing.Color]::FromArgb(24,24,24)
    $Script:HoverPreviewLabel.AutoEllipsis = $true
    $Script:HoverPreviewForm.Controls.Add($Script:HoverPreviewLabel)
    $Script:HoverPreviewLabel.BringToFront()
}

function Hide-HoverCardPreview {
    try {
        if ($Script:HoverPreviewTimer) {
            $Script:HoverPreviewTimer.Stop()
        }
        if ($Script:HoverPreviewForm -and -not $Script:HoverPreviewForm.IsDisposed) {
            $Script:HoverPreviewForm.Hide()
        }
        $Script:HoverPreviewVisible = $false
        $Script:HoverPreviewPendingName = ''
        $Script:HoverPreviewPendingUUID = ''
    }
    catch {}
}

function Show-HoverCardPreviewNow {
    param(
        [string]$CardName,
        [string]$PrintingUUID=''
    )

    if ([string]::IsNullOrWhiteSpace($CardName)) {
        Hide-HoverCardPreview
        return
    }

    Initialize-HoverPreviewPopup

    $key = "$CardName|$PrintingUUID"
    $imageUrl = Get-ScryfallImageUrl -CardName $CardName -PrintingUUID $PrintingUUID

    if (-not $imageUrl) {
        Hide-HoverCardPreview
        return
    }

    $screen = [System.Windows.Forms.Screen]::FromPoint([System.Windows.Forms.Cursor]::Position)
    $wa = $screen.WorkingArea

    $imageHeight = [Math]::Min(610, [Math]::Max(340, [int]($wa.Height * 0.58)))
    $imageWidth = [int]([Math]::Round($imageHeight * 0.716))
    $formHeight = $imageHeight + 34
    $formWidth = $imageWidth + 8

    $cursor = [System.Windows.Forms.Cursor]::Position
    $x = $cursor.X + 22
    $y = $cursor.Y + 18

    if (($x + $formWidth) -gt $wa.Right) {
        $x = $cursor.X - $formWidth - 22
    }
    if (($y + $formHeight) -gt $wa.Bottom) {
        $y = $wa.Bottom - $formHeight
    }
    if ($x -lt $wa.Left) { $x = $wa.Left }
    if ($y -lt $wa.Top) { $y = $wa.Top }

    $Script:HoverPreviewForm.Size = New-Object System.Drawing.Size($formWidth,$formHeight)
    $Script:HoverPreviewForm.Location = New-Object System.Drawing.Point($x,$y)
    $Script:HoverPreviewLabel.Text = $CardName

    # PictureBox async loading avoids blocking the UI on the actual image download.
    try {
        $Script:HoverPreviewPicture.CancelAsync()
    }
    catch {}

    $Script:HoverPreviewPicture.ImageLocation = $imageUrl
    $Script:HoverPreviewPicture.LoadAsync()

    if (-not $Script:HoverPreviewForm.Visible) {
        $Script:HoverPreviewForm.Show($form)
    }

    $Script:HoverPreviewForm.BringToFront()
    $Script:HoverPreviewLastKey = $key
    $Script:HoverPreviewVisible = $true
}

function Queue-HoverCardPreview {
    param(
        [string]$CardName,
        [string]$PrintingUUID=''
    )

    if ([string]::IsNullOrWhiteSpace($CardName)) {
        Hide-HoverCardPreview
        return
    }

    if (-not $Script:HoverPreviewTimer) {
        $Script:HoverPreviewTimer = New-Object System.Windows.Forms.Timer
        $Script:HoverPreviewTimer.Add_Tick({
            $Script:HoverPreviewTimer.Stop()
            $name = $Script:HoverPreviewPendingName
            $uuid = $Script:HoverPreviewPendingUUID

            if ($name) {
                Show-HoverCardPreviewNow -CardName $name -PrintingUUID $uuid
            }
        })
    }

    $Script:HoverPreviewPendingName = $CardName
    $Script:HoverPreviewPendingUUID = $PrintingUUID
    $Script:HoverPreviewTimer.Stop()
    $Script:HoverPreviewTimer.Interval = [int]$Script:HoverPreviewDelay
    $Script:HoverPreviewTimer.Start()
}

function Get-ScryfallPrintingsForCard {
    param([Parameter(Mandatory=$true)][string]$CardName)

    $results = New-Object System.Collections.Generic.List[object]

    $headers = @{
        'User-Agent' = 'CockatriceUniversalDeckImporter/3.1.4'
        'Accept' = 'application/json'
    }

    $exact = '!"' + $CardName.Replace('"','\"') + '"'
    $encoded = [uri]::EscapeDataString($exact)
    $url = "https://api.scryfall.com/cards/search?q=$encoded&unique=prints&order=released&dir=desc"

    while ($url) {
        $response = Invoke-RestMethod -Uri $url -Headers $headers -Method Get -ErrorAction Stop

        foreach ($card in @($response.data)) {
            $imageUrl = $null
            if ($card.image_uris -and $card.image_uris.normal) {
                $imageUrl = [string]$card.image_uris.normal
            }
            elseif ($card.card_faces -and
                    $card.card_faces.Count -gt 0 -and
                    $card.card_faces[0].image_uris -and
                    $card.card_faces[0].image_uris.normal) {
                $imageUrl = [string]$card.card_faces[0].image_uris.normal
            }

            $results.Add([pscustomobject]@{
                Name = [string]$card.name
                SetCode = ([string]$card.set).ToUpperInvariant()
                SetName = [string]$card.set_name
                CollectorNumber = [string]$card.collector_number
                UUID = [string]$card.id
                ReleasedAt = [string]$card.released_at
                ImageUrl = $imageUrl
            })
        }

        if ($response.has_more -and $response.next_page) {
            $url = [string]$response.next_page
            Start-Sleep -Milliseconds 80
        }
        else {
            $url = $null
        }
    }

    return $results.ToArray()
}

function Show-ArtSelector {
    param(
        [Parameter(Mandatory=$true)][string]$CardName,
        $CurrentPrinting
    )

    $dlg = New-Object System.Windows.Forms.Form
    $dlg.Text = "Choose Art / Printing - $CardName"
    $dlg.StartPosition = [System.Windows.Forms.FormStartPosition]::CenterParent
    $dlg.Size = New-Object System.Drawing.Size(980,740)
    $dlg.MinimumSize = New-Object System.Drawing.Size(860,620)
    $dlg.Font = New-Object System.Drawing.Font('Segoe UI',9)

    $left = New-Object System.Windows.Forms.Panel
    $left.Dock = [System.Windows.Forms.DockStyle]::Left
    $left.Width = 280
    $left.Padding = New-Object System.Windows.Forms.Padding(10)
    $dlg.Controls.Add($left)

    $right = New-Object System.Windows.Forms.Panel
    $right.Dock = [System.Windows.Forms.DockStyle]::Fill
    $right.Padding = New-Object System.Windows.Forms.Padding(4,0,0,0)
    $dlg.Controls.Add($right)

    $lblInfo = New-Object System.Windows.Forms.Label
    $lblInfo.Dock = [System.Windows.Forms.DockStyle]::Top
    $lblInfo.Height = 36
    $lblInfo.Text = "Default Art clears set/collector/UUID and lets Cockatrice choose the image."
    $lblInfo.AutoEllipsis = $true
    $left.Controls.Add($lblInfo)

    $list = New-Object System.Windows.Forms.ListBox
    $list.Dock = [System.Windows.Forms.DockStyle]::Fill
    $left.Controls.Add($list)
    $list.BringToFront()

    $buttons = New-Object System.Windows.Forms.FlowLayoutPanel
    $buttons.Dock = [System.Windows.Forms.DockStyle]::Bottom
    $buttons.Height = 48
    $buttons.FlowDirection = [System.Windows.Forms.FlowDirection]::RightToLeft
    $left.Controls.Add($buttons)

    $btnCancel = New-Object System.Windows.Forms.Button
    $btnCancel.Text = 'Cancel'
    $btnCancel.Width = 90
    $buttons.Controls.Add($btnCancel)

    $btnOK = New-Object System.Windows.Forms.Button
    $btnOK.Text = 'Use Selected'
    $btnOK.Width = 105
    $buttons.Controls.Add($btnOK)

    $previewHost = New-Object System.Windows.Forms.Panel
    $previewHost.Dock = [System.Windows.Forms.DockStyle]::Fill
    $previewHost.BackColor = [System.Drawing.Color]::Black
    $right.Controls.Add($previewHost)

    $pic = New-Object System.Windows.Forms.PictureBox
    $pic.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::Zoom
    $pic.BackColor = [System.Drawing.Color]::Black
    $previewHost.Controls.Add($pic)

    $centerArtPreview = {
        try {
            $availableWidth = [Math]::Max(100, $previewHost.ClientSize.Width)
            $availableHeight = [Math]::Max(100, $previewHost.ClientSize.Height)

            # Standard MTG card proportions are approximately 2.5 x 3.5.
            $cardRatio = 2.5 / 3.5

            # Scryfall's normal image is already clean enough for this selector.
            # Do not upscale it beyond a normal-image-sized preview; enlarging a
            # 488x680-ish source is what made it look soft/blurry in WinForms.
            $maxPreviewWidth = 488
            $maxPreviewHeight = 680

            $targetHeight = [Math]::Min($availableHeight, $maxPreviewHeight)
            $targetWidth = [int][Math]::Round($targetHeight * $cardRatio)

            if ($targetWidth -gt $availableWidth) {
                $targetWidth = $availableWidth
                $targetHeight = [int][Math]::Round($targetWidth / $cardRatio)
            }

            if ($targetWidth -gt $maxPreviewWidth) {
                $targetWidth = $maxPreviewWidth
                $targetHeight = [int][Math]::Round($targetWidth / $cardRatio)
            }

            $x = [int](($availableWidth - $targetWidth) / 2)
            $y = [int](($availableHeight - $targetHeight) / 2)

            # Apply a light right-bias so the art sits closer to the right edge
            # and the large black gap on the far right is reduced.
            if ($availableWidth -gt $targetWidth) {
                $rightBias = [int][Math]::Round(($availableWidth - $targetWidth) * 0.16)
                $x = [Math]::Min(($availableWidth - $targetWidth), ($x + $rightBias))
            }

            $pic.SetBounds($x, $y, $targetWidth, $targetHeight)
        }
        catch {}
    }

    $previewHost.Add_Resize($centerArtPreview)

    $lblSelected = New-Object System.Windows.Forms.Label
    $lblSelected.Dock = [System.Windows.Forms.DockStyle]::Bottom
    $lblSelected.Height = 58
    $lblSelected.TextAlign = [System.Drawing.ContentAlignment]::MiddleCenter
    $lblSelected.AutoEllipsis = $true
    $right.Controls.Add($lblSelected)
    $lblSelected.BringToFront()
    & $centerArtPreview

    $defaultItem = [pscustomobject]@{
        Display = '[DEFAULT ART]  Let Cockatrice choose'
        SetCode = ''
        SetName = ''
        CollectorNumber = ''
        UUID = ''
        ImageUrl = ''
        IsDefault = $true
    }

    $items = New-Object System.Collections.Generic.List[object]
    $items.Add($defaultItem)

    $status.Text = "Loading Scryfall printings for $CardName..."
    [System.Windows.Forms.Application]::DoEvents()

    try {
        foreach ($p in @(Get-ScryfallPrintingsForCard -CardName $CardName)) {
            $items.Add([pscustomobject]@{
                Display = "$($p.SetCode) #$($p.CollectorNumber)  -  $($p.SetName)  [$($p.ReleasedAt)]"
                SetCode = $p.SetCode
                SetName = $p.SetName
                CollectorNumber = $p.CollectorNumber
                UUID = $p.UUID
                ImageUrl = $p.ImageUrl
                IsDefault = $false
            })
        }
    }
    catch {
        $status.Text = "Could not load Scryfall printings for $CardName."
        throw
    }

    foreach ($item in $items) {
        [void]$list.Items.Add([string]$item.Display)
    }

    $selectedIndex = 0
    if ($CurrentPrinting -and $CurrentPrinting.PrintingUUID) {
        for ($i=1; $i -lt $items.Count; $i++) {
            if ([string]$items[$i].UUID -ieq [string]$CurrentPrinting.PrintingUUID) {
                $selectedIndex = $i
                break
            }
        }
    }
    elseif ($CurrentPrinting -and $CurrentPrinting.PrintingSet -and $CurrentPrinting.PrintingCollector) {
        for ($i=1; $i -lt $items.Count; $i++) {
            if ([string]$items[$i].SetCode -ieq [string]$CurrentPrinting.PrintingSet -and
                [string]$items[$i].CollectorNumber -ieq [string]$CurrentPrinting.PrintingCollector) {
                $selectedIndex = $i
                break
            }
        }
    }

    $updateArtPreview = {
        $i = $list.SelectedIndex
        if ($i -lt 0 -or $i -ge $items.Count) { return }

        $item = $items[$i]
        if ($item.IsDefault) {
            $lblSelected.Text = "Default Art / No Specific Printing`r`nPreview only: image quality here may differ from Cockatrice."
            $pic.ImageLocation = $null
            $defaultUrl = Get-ScryfallImageUrl -CardName $CardName
            if ($defaultUrl) {
                $pic.ImageLocation = $defaultUrl
                & $centerArtPreview
                $pic.LoadAsync()
            }
        }
        else {
            $lblSelected.Text = "$($item.SetCode) #$($item.CollectorNumber) - $($item.SetName)`r`nPreview only: image quality here may differ from Cockatrice."
            if ($item.ImageUrl) {
                $pic.ImageLocation = [string]$item.ImageUrl
                & $centerArtPreview
                $pic.LoadAsync()
            }
        }
    }

    $list.Add_SelectedIndexChanged($updateArtPreview)
    $dlg.Add_Resize({ & $centerArtPreview })
    $list.Add_DoubleClick({ $btnOK.PerformClick() })

    $selection = $null

    $btnOK.Add_Click({
        if ($list.SelectedIndex -lt 0) { return }
        $script:__ArtSelectorResult = $items[$list.SelectedIndex]
        $dlg.DialogResult = [System.Windows.Forms.DialogResult]::OK
        $dlg.Close()
    })

    $btnCancel.Add_Click({
        $dlg.DialogResult = [System.Windows.Forms.DialogResult]::Cancel
        $dlg.Close()
    })

    $list.SelectedIndex = $selectedIndex
    & $updateArtPreview

    Set-DarkThemeRecursive -Control $dlg

    $script:__ArtSelectorResult = $null
    $result = $dlg.ShowDialog($form)

    try { $pic.CancelAsync() } catch {}

    if ($result -eq [System.Windows.Forms.DialogResult]::OK) {
        $picked = $script:__ArtSelectorResult
        $script:__ArtSelectorResult = $null

        if ($picked) {
            return [pscustomobject]@{
                PrintingSet = [string]$picked.SetCode
                PrintingCollector = [string]$picked.CollectorNumber
                PrintingUUID = [string]$picked.UUID
                IsDefault = [bool]$picked.IsDefault
            }
        }
    }

    $script:__ArtSelectorResult = $null
    return $null
}

function Choose-ArtForSelectedEditorRow {
    # DataGridView can have a valid CurrentRow even when SelectedRows is empty
    # (for example after clicking a cell instead of the row header). Prefer an
    # explicitly selected row, then safely fall back to the current row.
    $row = $null

    if ($gridDeckEditor.SelectedRows.Count -ge 1) {
        $row = $gridDeckEditor.SelectedRows[0]
    }
    elseif ($gridDeckEditor.CurrentRow -and -not $gridDeckEditor.CurrentRow.IsNewRow) {
        $row = $gridDeckEditor.CurrentRow
    }

    if (-not $row -or $row.IsNewRow) {
        [System.Windows.Forms.MessageBox]::Show(
            'Select a card in the deck editor first.',
            'Choose Card Art',
            [System.Windows.Forms.MessageBoxButtons]::OK,
            [System.Windows.Forms.MessageBoxIcon]::Information
        ) | Out-Null
        return
    }

    $name = [string]$row.Cells['CardName'].Value

    if ([string]::IsNullOrWhiteSpace($name)) {
        [System.Windows.Forms.MessageBox]::Show(
            'The selected row does not contain a card name.',
            'Choose Card Art',
            [System.Windows.Forms.MessageBoxButtons]::OK,
            [System.Windows.Forms.MessageBoxIcon]::Information
        ) | Out-Null
        return
    }

    $current = $row.Tag
    if (-not $current) {
        $current = [pscustomobject]@{
            PrintingSet = ''
            PrintingCollector = ''
            PrintingUUID = ''
        }
    }

    Hide-HoverCardPreview
    $picked = Show-ArtSelector -CardName $name -CurrentPrinting $current
    if (-not $picked) { return }

    $row.Tag = [pscustomobject]@{
        PrintingSet = [string]$picked.PrintingSet
        PrintingCollector = [string]$picked.PrintingCollector
        PrintingUUID = [string]$picked.PrintingUUID
    }

    Apply-DeckEditorChanges -Silent

    if ($picked.IsDefault) {
        $status.Text = "$name set to Default Art. Cockatrice will choose the normal/default image."
    }
    else {
        $status.Text = "$name art set to $($picked.PrintingSet) #$($picked.PrintingCollector)."
    }

    Save-DeckAutosave
}


function Show-CardDatabaseBrowser {
    if (-not $Script:EditorMode) {
        throw 'Open or create a deck in the editor before browsing cards.'
    }

    if (-not $Script:CardIndex -or $Script:CardIndex.Count -eq 0) {
        $folder = $cmbDest.Text.Trim()
        $dataRoot = Get-DataRootFromDeckFolder $folder
        if (-not $dataRoot) {
            throw 'A Cockatrice card database could not be located. Choose a valid Cockatrice decks folder first.'
        }
        Load-CardIndex -DataRoot $dataRoot -StatusLabel $status
    }

    $dlg = New-Object System.Windows.Forms.Form
    $dlg.Text = 'Cockatrice Card Database Browser'
    $dlg.StartPosition = [System.Windows.Forms.FormStartPosition]::CenterParent
    $dlg.Size = New-Object System.Drawing.Size(1180,760)
    $dlg.MinimumSize = New-Object System.Drawing.Size(900,620)
    $dlg.Font = New-Object System.Drawing.Font('Segoe UI',9)

    $splitBrowser = New-Object System.Windows.Forms.SplitContainer
    $splitBrowser.Dock = [System.Windows.Forms.DockStyle]::Fill
    $splitBrowser.Orientation = [System.Windows.Forms.Orientation]::Vertical
    $splitBrowser.SplitterWidth = 6
    $dlg.Controls.Add($splitBrowser)

    # IMPORTANT: Do not set Panel1MinSize / Panel2MinSize / SplitterDistance
    # while the SplitContainer still has its tiny constructor-default width.
    # WinForms validates those values immediately and can throw before the
    # browser is shown. Configure them only after the form has a real size.
    $configureBrowserSplit = {
        try {
            $width = [Math]::Max(700, $splitBrowser.ClientSize.Width)
            $splitter = [Math]::Max(4, $splitBrowser.SplitterWidth)

            # Leave enough room for the responsive preview/actions pane.
            $panel1Min = [Math]::Min(500, [int]($width * 0.48))
            $panel2Min = [Math]::Min(300, [int]($width * 0.30))

            # Guarantee the minimums fit inside the current width.
            $maxCombined = $width - $splitter - 20
            if (($panel1Min + $panel2Min) -gt $maxCombined) {
                $panel2Min = [Math]::Max(220, $maxCombined - $panel1Min)
            }

            $splitBrowser.Panel1MinSize = [Math]::Max(300, $panel1Min)
            $splitBrowser.Panel2MinSize = [Math]::Max(220, $panel2Min)

            $minDistance = $splitBrowser.Panel1MinSize
            $maxDistance = $width - $splitter - $splitBrowser.Panel2MinSize

            if ($maxDistance -gt $minDistance) {
                $target = [int][Math]::Round($width * 0.72)
                $target = [Math]::Max($minDistance, [Math]::Min($target, $maxDistance))
                $splitBrowser.SplitterDistance = $target
            }
        }
        catch {
            # Layout should never prevent the browser from opening.
        }
    }

    $dlg.Add_Shown({
        & $configureBrowserSplit
    })

    $dlg.Add_Resize({
        try {
            # Keep current user-adjusted split unless the resized window would
            # make it invalid. In that case clamp it safely.
            $width = $splitBrowser.ClientSize.Width
            if ($width -le 0) { return }

            $minDistance = $splitBrowser.Panel1MinSize
            $maxDistance = $width - $splitBrowser.SplitterWidth - $splitBrowser.Panel2MinSize

            if ($maxDistance -gt $minDistance) {
                if ($splitBrowser.SplitterDistance -lt $minDistance) {
                    $splitBrowser.SplitterDistance = $minDistance
                }
                elseif ($splitBrowser.SplitterDistance -gt $maxDistance) {
                    $splitBrowser.SplitterDistance = $maxDistance
                }
            }
        }
        catch {}
    })

    # ---------------- left: searchable local Cockatrice database ----------------
    $leftBrowser = New-Object System.Windows.Forms.Panel
    $leftBrowser.Dock = [System.Windows.Forms.DockStyle]::Fill
    $leftBrowser.Padding = New-Object System.Windows.Forms.Padding(10)
    $splitBrowser.Panel1.Controls.Add($leftBrowser)

    $lblBrowserTitle = New-Object System.Windows.Forms.Label
    $lblBrowserTitle.Text = 'Card Database'
    $lblBrowserTitle.Dock = [System.Windows.Forms.DockStyle]::Top
    $lblBrowserTitle.Height = 28
    $lblBrowserTitle.Font = New-Object System.Drawing.Font('Segoe UI',11,[System.Drawing.FontStyle]::Bold)
    $leftBrowser.Controls.Add($lblBrowserTitle)

    $browserSearchRow = New-Object System.Windows.Forms.Panel
    $browserSearchRow.Dock = [System.Windows.Forms.DockStyle]::Top
    $browserSearchRow.Height = 31
    $leftBrowser.Controls.Add($browserSearchRow)
    $browserSearchRow.BringToFront()

    $btnBrowserSearchHelp = New-Object System.Windows.Forms.Button
    $btnBrowserSearchHelp.Text = 'Search Help'
    $btnBrowserSearchHelp.Dock = [System.Windows.Forms.DockStyle]::Right
    $btnBrowserSearchHelp.Width = 100
    $browserSearchRow.Controls.Add($btnBrowserSearchHelp)

    $txtBrowserSearch = New-Object System.Windows.Forms.TextBox
    $txtBrowserSearch.Dock = [System.Windows.Forms.DockStyle]::Fill
    $browserSearchRow.Controls.Add($txtBrowserSearch)
    $txtBrowserSearch.BringToFront()

    $lblBrowserHint = New-Object System.Windows.Forms.Label
    $lblBrowserHint.Text = 'Name or keyword search. Scryfall syntax works too: o:myriad, t:artifact, c:u, mv<=3.'
    $lblBrowserHint.Dock = [System.Windows.Forms.DockStyle]::Top
    $lblBrowserHint.Height = 26
    $leftBrowser.Controls.Add($lblBrowserHint)
    $lblBrowserHint.BringToFront()

    $lblBrowserCount = New-Object System.Windows.Forms.Label
    $lblBrowserCount.Dock = [System.Windows.Forms.DockStyle]::Bottom
    $lblBrowserCount.Height = 25
    $leftBrowser.Controls.Add($lblBrowserCount)

    $listBrowser = New-Object System.Windows.Forms.ListBox
    $listBrowser.Dock = [System.Windows.Forms.DockStyle]::Fill
    $listBrowser.HorizontalScrollbar = $true
    $leftBrowser.Controls.Add($listBrowser)
    $listBrowser.BringToFront()

    # ---------------- right: preview + add controls ----------------
    # Use a real row layout instead of overlapping Dock/BringToFront controls.
    # This remains stable at different Windows DPI/scaling levels.
    $rightBrowser = New-Object System.Windows.Forms.TableLayoutPanel
    $rightBrowser.Dock = [System.Windows.Forms.DockStyle]::Fill
    $rightBrowser.Padding = New-Object System.Windows.Forms.Padding(8)
    $rightBrowser.ColumnCount = 1
    $rightBrowser.RowCount = 3
    [void]$rightBrowser.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Absolute,34)))
    [void]$rightBrowser.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Percent,100)))
    [void]$rightBrowser.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Absolute,126)))
    $splitBrowser.Panel2.Controls.Add($rightBrowser)

    $lblBrowserCard = New-Object System.Windows.Forms.Label
    $lblBrowserCard.Text = 'Select a card'
    $lblBrowserCard.Dock = [System.Windows.Forms.DockStyle]::Fill
    $lblBrowserCard.TextAlign = [System.Drawing.ContentAlignment]::MiddleCenter
    $lblBrowserCard.Font = New-Object System.Drawing.Font('Segoe UI',10,[System.Drawing.FontStyle]::Bold)
    $rightBrowser.Controls.Add($lblBrowserCard,0,0)

    $previewHostBrowser = New-Object System.Windows.Forms.Panel
    $previewHostBrowser.Dock = [System.Windows.Forms.DockStyle]::Fill
    $previewHostBrowser.Margin = New-Object System.Windows.Forms.Padding(0,4,0,6)
    $previewHostBrowser.BackColor = [System.Drawing.Color]::Black
    $rightBrowser.Controls.Add($previewHostBrowser,0,1)

    $picBrowser = New-Object System.Windows.Forms.PictureBox
    $picBrowser.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::Zoom
    $picBrowser.BackColor = [System.Drawing.Color]::Black
    $previewHostBrowser.Controls.Add($picBrowser)

    $resizeBrowserPreview = {
        try {
            $aw = [Math]::Max(100,$previewHostBrowser.ClientSize.Width)
            $ah = [Math]::Max(100,$previewHostBrowser.ClientSize.Height)

            # Scryfall normal images are roughly 488x680. Never enlarge past
            # that size so the preview remains clean on large screens.
            $tw = [Math]::Min(488,$aw)
            $th = [int][Math]::Round($tw / (2.5/3.5))
            if ($th -gt [Math]::Min(680,$ah)) {
                $th = [Math]::Min(680,$ah)
                $tw = [int][Math]::Round($th * (2.5/3.5))
            }

            $x = [int](($aw-$tw)/2)
            $y = [int](($ah-$th)/2)
            $picBrowser.SetBounds($x,$y,$tw,$th)
        }
        catch {}
    }
    $previewHostBrowser.Add_Resize($resizeBrowserPreview)

    $browserFooter = New-Object System.Windows.Forms.TableLayoutPanel
    $browserFooter.Dock = [System.Windows.Forms.DockStyle]::Fill
    $browserFooter.Margin = New-Object System.Windows.Forms.Padding(0)
    $browserFooter.ColumnCount = 1
    $browserFooter.RowCount = 3
    [void]$browserFooter.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Absolute,38)))
    [void]$browserFooter.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Absolute,38)))
    [void]$browserFooter.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Percent,100)))
    $rightBrowser.Controls.Add($browserFooter,0,2)

    # Row 1: zone selector. Centered and independent of button widths.
    $zoneRow = New-Object System.Windows.Forms.FlowLayoutPanel
    $zoneRow.Dock = [System.Windows.Forms.DockStyle]::Fill
    $zoneRow.FlowDirection = [System.Windows.Forms.FlowDirection]::LeftToRight
    $zoneRow.WrapContents = $false
    $zoneRow.AutoSize = $false
    $zoneRow.Padding = New-Object System.Windows.Forms.Padding(8,3,0,0)
    $browserFooter.Controls.Add($zoneRow,0,0)

    $lblBrowserZone = New-Object System.Windows.Forms.Label
    $lblBrowserZone.Text = 'Add to:'
    $lblBrowserZone.Width = 55
    $lblBrowserZone.Height = 28
    $lblBrowserZone.TextAlign = [System.Drawing.ContentAlignment]::MiddleLeft
    $zoneRow.Controls.Add($lblBrowserZone)

    $cmbBrowserZone = New-Object System.Windows.Forms.ComboBox
    $cmbBrowserZone.Width = 120
    $cmbBrowserZone.DropDownStyle = [System.Windows.Forms.ComboBoxStyle]::DropDownList
    [void]$cmbBrowserZone.Items.Add('main')
    [void]$cmbBrowserZone.Items.Add('commander')
    [void]$cmbBrowserZone.Items.Add('side')
    $cmbBrowserZone.SelectedIndex = 0
    $zoneRow.Controls.Add($cmbBrowserZone)

    # Row 2: actions. Separate row prevents clipping on narrower preview panes.
    $actionRow = New-Object System.Windows.Forms.FlowLayoutPanel
    $actionRow.Dock = [System.Windows.Forms.DockStyle]::Fill
    $actionRow.FlowDirection = [System.Windows.Forms.FlowDirection]::LeftToRight
    $actionRow.WrapContents = $false
    $actionRow.Padding = New-Object System.Windows.Forms.Padding(8,3,0,0)
    $browserFooter.Controls.Add($actionRow,0,1)

    $btnBrowserAdd = New-Object System.Windows.Forms.Button
    $btnBrowserAdd.Text = 'Add to Deck'
    $btnBrowserAdd.Width = 112
    $btnBrowserAdd.Enabled = $false
    $actionRow.Controls.Add($btnBrowserAdd)

    $btnBrowserClose = New-Object System.Windows.Forms.Button
    $btnBrowserClose.Text = 'Close'
    $btnBrowserClose.Width = 82
    $actionRow.Controls.Add($btnBrowserClose)

    $lblBrowserStatus = New-Object System.Windows.Forms.Label
    $lblBrowserStatus.Dock = [System.Windows.Forms.DockStyle]::Fill
    $lblBrowserStatus.Margin = New-Object System.Windows.Forms.Padding(4,2,4,0)
    $lblBrowserStatus.TextAlign = [System.Drawing.ContentAlignment]::TopCenter
    $lblBrowserStatus.AutoEllipsis = $true
    $lblBrowserStatus.Text = 'Select a card, choose a zone, then click Add to Deck.'
    $browserFooter.Controls.Add($lblBrowserStatus,0,2)

    # Reuse the sorted card-name cache built with cards.xml. A 30k string
    # reference array is inexpensive compared with repeatedly sorting and
    # rendering tens of thousands of WinForms rows.
    if (-not $Script:SortedCardNames -or
        $Script:SortedCardNames.Count -ne $Script:CardIndex.Count) {

        $browserSortWatch = [System.Diagnostics.Stopwatch]::StartNew()
        $Script:SortedCardNames = [string[]]@($Script:CardIndex.Keys | Sort-Object)
        $browserSortWatch.Stop()

        Write-PerformanceLog -Stage 'Browser fallback sort cache built' `
            -Milliseconds $browserSortWatch.Elapsed.TotalMilliseconds `
            -Details ("Cards={0:N0}" -f $Script:SortedCardNames.Count)
    }

    $allNames = $Script:SortedCardNames
    $browserLimit = [int]$Script:BrowserResultLimit

    function Get-BrowserScryfallNames {
        param([string]$SearchText)

        if ([string]::IsNullOrWhiteSpace($SearchText)) {
            return @()
        }

        $typed = $SearchText.Trim()

        # Advanced Scryfall syntax passes straight through. Plain text is also
        # treated as an oracle-text keyword, so typing "myriad" finds cards
        # whose rules text contains Myriad while local name matches stay first.
        $isAdvanced = (
            $typed -match '(^|\s)[A-Za-z][A-Za-z0-9_-]*\s*[:<>=]' -or
            $typed -match '[<>]=?'
        )

        if ($isAdvanced) {
            $query = $typed
        }
        else {
            $safe = $typed.Replace('"','\"')
            $query = 'o:"' + $safe + '"'
        }

        try {
            $cards = @(Invoke-ScryfallCardSearch -Query $query)

            $seen = New-Object 'System.Collections.Generic.HashSet[string]' ([System.StringComparer]::OrdinalIgnoreCase)
            $names = New-Object System.Collections.Generic.List[string]

            foreach ($card in $cards) {
                $name = [string]$card.name
                if ([string]::IsNullOrWhiteSpace($name)) { continue }

                # Browser remains grounded in the user's Cockatrice database.
                if (-not $Script:CardIndex.ContainsKey($name)) { continue }

                if ($seen.Add($name)) {
                    $names.Add($name)
                }
            }

            return $names.ToArray()
        }
        catch {
            return @()
        }
    }

    $populateBrowser = {
        $browserSearchWatch = [System.Diagnostics.Stopwatch]::StartNew()
        $needle = $txtBrowserSearch.Text.Trim()
        $listBrowser.BeginUpdate()
        try {
            $listBrowser.Items.Clear()

            if ([string]::IsNullOrWhiteSpace($needle)) {
                $shown = [Math]::Min($browserLimit, $allNames.Count)

                for ($i = 0; $i -lt $shown; $i++) {
                    [void]$listBrowser.Items.Add([string]$allNames[$i])
                }

                if ($allNames.Count -gt $shown) {
                    $lblBrowserCount.Text = "Showing first $($shown.ToString('N0')) of $($allNames.Count.ToString('N0')) cards - type to narrow the search"
                }
                else {
                    $lblBrowserCount.Text = "Showing $($shown.ToString('N0')) Cockatrice cards"
                }
                return
            }

            $added = New-Object 'System.Collections.Generic.HashSet[string]' ([System.StringComparer]::OrdinalIgnoreCase)
            $localMatches = New-Object System.Collections.Generic.List[string]

            # Fast local card-name matches always appear first.
            $terms = @($needle -split '\s+' | Where-Object { $_ })
            foreach ($n in $allNames) {
                $match = $true
                foreach ($term in $terms) {
                    if ($n.IndexOf($term,[System.StringComparison]::OrdinalIgnoreCase) -lt 0) {
                        $match = $false
                        break
                    }
                }

                if ($match -and $added.Add([string]$n)) {
                    $localMatches.Add([string]$n)

                    if ($listBrowser.Items.Count -lt $browserLimit) {
                        [void]$listBrowser.Items.Add([string]$n)
                    }
                }
            }

            $isAdvanced = (
                $needle -match '(^|\s)[A-Za-z][A-Za-z0-9_-]*\s*[:<>=]' -or
                $needle -match '[<>]=?'
            )

            # Give advanced searches pure Scryfall semantics. For a normal word
            # such as "myriad", retain local name hits first and append keyword
            # oracle-text matches from Scryfall.
            if ($isAdvanced) {
                $listBrowser.Items.Clear()
                $added.Clear()
            }

            $lblBrowserCount.Text = 'Searching Scryfall...'
            [System.Windows.Forms.Application]::DoEvents()

            $scryNames = @(Get-BrowserScryfallNames -SearchText $needle)
            foreach ($name in $scryNames) {
                if ($added.Add([string]$name)) {
                    if ($listBrowser.Items.Count -lt $browserLimit) {
                        [void]$listBrowser.Items.Add([string]$name)
                    }
                }
            }

            $shown = $listBrowser.Items.Count
            if ($isAdvanced) {
                $lblBrowserCount.Text = "Scryfall filter: $($shown.ToString('N0')) matching Cockatrice cards"
            }
            elseif ($scryNames.Count -gt 0) {
                $lblBrowserCount.Text = "Showing $($shown.ToString('N0')) cards - name matches first, then keyword matches"
            }
            else {
                $lblBrowserCount.Text = "Showing $($shown.ToString('N0')) local name matches"
            }
        }
        finally {
            $listBrowser.EndUpdate()
            $browserSearchWatch.Stop()

            Write-PerformanceLog -Stage 'Card browser search' `
                -Milliseconds $browserSearchWatch.Elapsed.TotalMilliseconds `
                -Details ("Query='{0}'; Displayed={1:N0}" -f $needle,$listBrowser.Items.Count)
        }
    }

    # Longer debounce avoids hammering Scryfall while still feeling responsive.
    $filterTimer = New-Object System.Windows.Forms.Timer
    $filterTimer.Interval = 700
    $filterTimer.Add_Tick({
        $filterTimer.Stop()
        & $populateBrowser
    })

    $btnBrowserSearchHelp.Add_Click({ Show-ScryfallSearchBasics -Owner $dlg })

    $txtBrowserSearch.Add_TextChanged({
        $filterTimer.Stop()
        $filterTimer.Start()
    })

    $txtBrowserSearch.Add_KeyDown({
        param($sender,$e)

        if ($e.KeyCode -eq [System.Windows.Forms.Keys]::Enter) {
            $e.SuppressKeyPress = $true
            $filterTimer.Stop()
            & $populateBrowser
        }
    })

    $listBrowser.Add_SelectedIndexChanged({
        try {
            if ($listBrowser.SelectedIndex -lt 0) {
                $btnBrowserAdd.Enabled = $false
                return
            }

            $name = [string]$listBrowser.SelectedItem
            $lblBrowserCard.Text = $name
            $btnBrowserAdd.Enabled = $true
            $lblBrowserStatus.Text = 'Loading preview...'

            $url = Get-ScryfallImageUrl -CardName $name
            if ($url) {
                try { $picBrowser.CancelAsync() } catch {}
                $picBrowser.ImageLocation = $url
                & $resizeBrowserPreview
                $picBrowser.LoadAsync()
                $lblBrowserStatus.Text = "Ready to add $name. Choose a zone, then click Add to Deck."
            }
            else {
                $picBrowser.ImageLocation = $null
                $lblBrowserStatus.Text = 'No Scryfall preview available; the local Cockatrice card can still be added.'
            }
        }
        catch {
            $lblBrowserStatus.Text = 'Preview unavailable; the local Cockatrice card can still be added.'
        }
    })

    $btnBrowserAdd.Add_Click({
        try {
            if ($listBrowser.SelectedIndex -lt 0) { return }
            $name = [string]$listBrowser.SelectedItem
            $zone = [string]$cmbBrowserZone.SelectedItem
            if (-not $zone) { $zone = 'main' }

            if (-not (Confirm-OffColorCard -CardName $name)) {
                $lblBrowserStatus.Text = "Not added: $name is outside commander color identity."
                return
            }

            $result = Add-CardToEditor -CardName $name -Zone $zone -Source 'Card Database Browser'
            if ($result.Cancelled) {
                $lblBrowserStatus.Text = "Not added: duplicate warning cancelled for $name."
                return
            }

            Update-DeckStatsPanel
            Save-DeckAutosave
            $lblBrowserStatus.Text = "Added $name to $zone."
            $status.Text = "Added $name from Card Database Browser."
        }
        catch {
            $lblBrowserStatus.Text = 'Could not add the selected card.'
            Show-DetailedError -ErrorRecord $_ -Context 'Card Database Browser - Add Card'
        }
    })

    $listBrowser.Add_DoubleClick({
        if ($btnBrowserAdd.Enabled) { $btnBrowserAdd.PerformClick() }
    })

    $btnBrowserClose.Add_Click({ $dlg.Close() })

    $dlg.Add_FormClosed({
        try { $filterTimer.Stop(); $filterTimer.Dispose() } catch {}
        try { $picBrowser.CancelAsync() } catch {}
        $allNames = $null
    })

    & $populateBrowser
    & $resizeBrowserPreview
    Set-DarkThemeRecursive -Control $dlg

    # Modeless browser: keep the browser open while allowing the main editor
    # to remain fully interactive. The small message loop keeps this function's
    # local controls/state alive until the browser is closed.
    $dlg.Show($form)
    while (-not $dlg.IsDisposed -and $dlg.Visible) {
        [System.Windows.Forms.Application]::DoEvents()
        Start-Sleep -Milliseconds 20
    }
}

function Get-ScryfallNameSuggestions {
    param(
        [string]$Query,
        [int]$Limit = 8
    )

    if ([string]::IsNullOrWhiteSpace($Query)) { return @() }

    try {
        $headers = @{
            'User-Agent' = 'CockatriceUniversalDeckImporter/3.1.4'
            'Accept' = 'application/json;q=0.9,*/*;q=0.8'
        }

        $encoded = [uri]::EscapeDataString($Query.Trim())
        $url = "https://api.scryfall.com/cards/autocomplete?q=$encoded&include_extras=true"

        $response = Invoke-RestMethod -Uri $url -Headers $headers -Method Get -ErrorAction Stop
        return @($response.data | Select-Object -First $Limit)
    }
    catch {
        return @()
    }
}

function Invoke-ScryfallCardSearch {
    param([Parameter(Mandatory=$true)][string]$Query)

    $q = $Query.Trim()
    if ([string]::IsNullOrWhiteSpace($q)) {
        return @()
    }

    $encoded = [uri]::EscapeDataString($q)
    $url = "https://api.scryfall.com/cards/search?q=$encoded&order=name&unique=cards"

    $headers = @{
        'User-Agent' = 'CockatriceUniversalDeckImporter/3.1.4'
        'Accept' = 'application/json;q=0.9,*/*;q=0.8'
    }

    try {
        $response = Invoke-RestMethod -Uri $url -Headers $headers -Method Get -ErrorAction Stop
        return @($response.data)
    }
    catch [System.Net.WebException] {
        $statusCode = $null

        try {
            if ($_.Exception.Response -and $_.Exception.Response.StatusCode) {
                $statusCode = [int]$_.Exception.Response.StatusCode
            }
        }
        catch {}

        # Scryfall uses HTTP 404 for valid searches that simply match nothing.
        if ($statusCode -eq 404) {
            return @()
        }

        throw
    }
}


function Populate-ScryfallResults {
    param($Cards)

    $cmbScryResults.Items.Clear()
    $btnScryAdd.Enabled = $false
    $Script:ScryfallSearchResults = @()

    $list = @($Cards | Select-Object -First 100)
    $Script:ScryfallSearchResults = $list

    foreach ($card in $list) {
        $name = [string]$card.name
        if ($name) {
            $set = ''
            if ($card.set_name) { $set = [string]$card.set_name }
            elseif ($card.set) { $set = ([string]$card.set).ToUpperInvariant() }

            $display = if ($set) { "$name  [$set]" } else { $name }
            [void]$cmbScryResults.Items.Add($display)
        }
    }

    if ($cmbScryResults.Items.Count -gt 0) {
        $cmbScryResults.SelectedIndex = 0
        $btnScryAdd.Enabled = $true
    }
}

function Get-SelectedScryfallCard {
    if ($cmbScryResults.SelectedIndex -lt 0) { return $null }

    $i = $cmbScryResults.SelectedIndex
    if ($Script:ScryfallSearchResults -and $i -lt $Script:ScryfallSearchResults.Count) {
        return $Script:ScryfallSearchResults[$i]
    }

    return $null
}

function Add-ScryfallCardToDeck {
    param($Card)

    if (-not $Card) {
        throw 'Select a Scryfall search result first.'
    }

    $name = [string]$Card.name
    if ([string]::IsNullOrWhiteSpace($name)) {
        throw 'Selected Scryfall result has no card name.'
    }

    $zone = if ($cmbScryZone.SelectedItem) {
        [string]$cmbScryZone.SelectedItem
    }
    else {
        'main'
    }

    $cardColors = @($Card.color_identity | ForEach-Object { [string]$_ })
    if (-not (Confirm-OffColorCard -CardName $name -CardColors $cardColors)) {
        $status.Text = "Not added: $name is outside commander color identity."
        return $null
    }

    # Use the SAME insertion path as the working Cockatrice local-card search.
    $result = Add-CardToEditor -CardName $name -Zone $zone -Source 'Scryfall Search'

    return $result
}

function Clear-LiveCardPreview {
    try {
        if ($picLivePreview.Image) {
            $oldImage = $picLivePreview.Image
            $picLivePreview.Image = $null
            $oldImage.Dispose()
        }

        if ($picLivePreview.Tag -is [System.IDisposable]) {
            $picLivePreview.Tag.Dispose()
        }
        $picLivePreview.Tag = $null
    }
    catch {}

    $lblLivePreviewName.Text = 'Select a card to preview it.'
    $Script:LivePreviewLastCard = ''
}

function Update-LiveCardPreview {
    param([string]$CardName)

    if ([string]::IsNullOrWhiteSpace($CardName)) {
        Clear-LiveCardPreview
        return
    }

    if ($CardName -eq $Script:LivePreviewLastCard -and $picLivePreview.Image) {
        return
    }

    $Script:LivePreviewLastCard = $CardName
    $lblLivePreviewName.Text = "Loading $CardName..."
    [System.Windows.Forms.Application]::DoEvents()

    try {
        $escaped = [uri]::EscapeDataString($CardName)
        $api = "https://api.scryfall.com/cards/named?exact=$escaped"
        $headers = @{
            'User-Agent' = 'CockatriceUniversalDeckImporter/3.1.4'
            'Accept' = 'application/json'
        }

        $card = Invoke-RestMethod -Uri $api -Headers $headers -Method Get -ErrorAction Stop

        $imageUrl = $null

        if ($card.image_uris -and $card.image_uris.normal) {
            $imageUrl = [string]$card.image_uris.normal
        }
        elseif ($card.card_faces -and
                $card.card_faces.Count -gt 0 -and
                $card.card_faces[0].image_uris -and
                $card.card_faces[0].image_uris.normal) {

            $imageUrl = [string]$card.card_faces[0].image_uris.normal
        }

        if (-not $imageUrl) {
            throw 'No card image URL was returned.'
        }

        $wc = New-Object System.Net.WebClient
        $wc.Headers['User-Agent'] = 'CockatriceUniversalDeckImporter/3.1.4'
        $bytes = $wc.DownloadData($imageUrl)

        $ms = New-Object System.IO.MemoryStream(,$bytes)
        $newImage = [System.Drawing.Image]::FromStream($ms)

        if ($picLivePreview.Image) {
            $oldImage = $picLivePreview.Image
            $picLivePreview.Image = $null
            $oldImage.Dispose()
        }
        if ($picLivePreview.Tag -is [System.IDisposable]) {
            $picLivePreview.Tag.Dispose()
        }

        $picLivePreview.Image = $newImage
        $picLivePreview.Tag = $ms
        $lblLivePreviewName.Text = $CardName
    }
    catch {
        Clear-LiveCardPreview
        $Script:LivePreviewLastCard = $CardName
        $lblLivePreviewName.Text = "$CardName`r`nPreview unavailable"
    }
}

function Set-EditorPreviewSplit {
    try {
        $usable = $editorSplit.ClientSize.Width - $editorSplit.SplitterWidth

        if ($usable -gt 500) {
            # About 70% card grid / 30% search/tools pane.
            $target = [int][Math]::Round($usable * 0.70)

            # Use simple safe bounds instead of Panel1MinSize/Panel2MinSize,
            # because those properties can throw before the control is laid out.
            $minimumLeft = 350
            $minimumRight = 300

            if ($target -lt $minimumLeft) {
                $target = $minimumLeft
            }

            if (($usable - $target) -lt $minimumRight) {
                $target = $usable - $minimumRight
            }

            if ($target -gt 0 -and $target -lt $usable) {
                $editorSplit.SplitterDistance = $target
            }
        }
    }
    catch {
        # Preview layout should never stop the importer from opening.
    }
}


function Refresh-LocalCardAutocomplete {
    try {
        if (-not $txtLocalCardSearch) { return }

        $source = New-Object System.Windows.Forms.AutoCompleteStringCollection

        if ($Script:CardIndex -and $Script:CardIndex.Keys) {
            $names = @($Script:CardIndex.Keys | Sort-Object)
            if ($names.Count -gt 0) {
                $source.AddRange([string[]]$names)
            }
        }

        $txtLocalCardSearch.AutoCompleteCustomSource = $source
    }
    catch {
        # Autocomplete is optional; never stop the importer.
    }
}


function Test-IsCommanderBasicLandName {
    param([string]$CardName)

    if ([string]::IsNullOrWhiteSpace($CardName)) {
        return $false
    }

    return $CardName.Trim() -in @(
        'Plains',
        'Island',
        'Swamp',
        'Mountain',
        'Forest',
        'Wastes',
        'Snow-Covered Plains',
        'Snow-Covered Island',
        'Snow-Covered Swamp',
        'Snow-Covered Mountain',
        'Snow-Covered Forest'
    )
}

function Get-EditorCommanderCopyCount {
    param([string]$CardName)

    if ([string]::IsNullOrWhiteSpace($CardName)) {
        return 0
    }

    $total = 0

    foreach ($row in $gridDeckEditor.Rows) {
        if ($row.IsNewRow) { continue }

        $rowName = [string]$row.Cells['CardName'].Value
        $rowZone = [string]$row.Cells['Zone'].Value

        if ($rowName -ieq $CardName -and
            $rowZone -in @('main','commander')) {
            $qty = 1
            try { $qty = [int]$row.Cells['Qty'].Value } catch {}
            $total += $qty
        }
    }

    return $total
}

function Confirm-CommanderDuplicateAdd {
    param(
        [string]$CardName,
        [string]$Zone
    )

    if ($cmbFormat.Text -ine 'Commander') {
        return $true
    }

    if ($Zone -notin @('main','commander')) {
        return $true
    }

    if (Test-IsCommanderBasicLandName -CardName $CardName) {
        return $true
    }

    $existing = Get-EditorCommanderCopyCount -CardName $CardName

    if ($existing -lt 1) {
        return $true
    }

    $answer = [System.Windows.Forms.MessageBox]::Show(
        "Commander singleton warning:`r`n`r`n$CardName is already in the deck ($existing copy/copies).`r`n`r`nCommander normally allows only one copy of a nonbasic card.`r`n`r`nAdd another copy anyway?",
        'Commander Duplicate',
        [System.Windows.Forms.MessageBoxButtons]::YesNo,
        [System.Windows.Forms.MessageBoxIcon]::Warning,
        [System.Windows.Forms.MessageBoxDefaultButton]::Button2
    )

    return ($answer -eq [System.Windows.Forms.DialogResult]::Yes)
}

function Get-EditorCardTypeCategory {
    param([string]$CardName)

    if ([string]::IsNullOrWhiteSpace($CardName)) {
        return 'Other'
    }

    # 8 GB mode keeps type metadata only for cards actually used.
    if (-not $Script:CardTypeIndex.ContainsKey($CardName)) {
        $probe = @(New-Entry -Qty 1 -Name $CardName -Zone 'main' -Source 'Type lookup')
        Ensure-CardTypesForEntries -Entries $probe
    }

    return Get-CardTypeCategory -CardName $CardName
}

function Add-CardToEditor {
    param(
        [Parameter(Mandatory=$true)][string]$CardName,
        [string]$Zone = 'main',
        [string]$Source = 'Manual'
    )

    $typed = $CardName.Trim()
    if ([string]::IsNullOrWhiteSpace($typed)) {
        throw 'Card name is empty.'
    }

    if ($Zone -notin @('main','commander','side')) {
        $Zone = 'main'
    }

    $resolved = Resolve-CardNameSmart -InputName $typed

    if ($resolved) {
        $finalName = $resolved
        $valid = $true
        $statusText = 'OK'
    }
    else {
        $entry = New-Entry -Qty 1 -Name $typed -Zone $Zone -Source $Source
        $arr = @($entry)
        Validate-Entries $arr
        $entry = $arr[0]

        $finalName = [string]$entry.Name
        $valid = [bool]$entry.Valid

        $statusText = if ($valid) {
            'OK'
        }
        elseif ($entry.Suggestion) {
            'Not found - ' + [string]$entry.Suggestion
        }
        else {
            'Not found'
        }
    }

    # Warn immediately before creating a Commander singleton violation.
    if ($valid -and
        -not (Confirm-CommanderDuplicateAdd -CardName $finalName -Zone $Zone)) {
        $status.Text = "Not added: $finalName is already in this Commander deck."
        return [pscustomobject]@{
            Name = $finalName
            Zone = $Zone
            AddedNewRow = $false
            Valid = $valid
            Cancelled = $true
        }
    }

    # Resolve Type BEFORE writing the row so the new six-column schema is:
    # Qty | Card Name | Zone | Type | OK | Validation
    $category = if ($valid) {
        Get-EditorCardTypeCategory -CardName $finalName
    }
    else {
        'Other'
    }

    # If this exact card/zone already exists, increment Qty after the duplicate
    # confirmation above rather than creating a second physical row.
    foreach ($row in $gridDeckEditor.Rows) {
        if ($row.IsNewRow) { continue }

        $rowName = [string]$row.Cells['CardName'].Value
        $rowZone = [string]$row.Cells['Zone'].Value

        if ($rowName -ieq $finalName -and $rowZone -ieq $Zone) {
            $oldQty = 1
            try { $oldQty = [int]$row.Cells['Qty'].Value } catch {}

            $row.Cells['Qty'].Value = $oldQty + 1
            $row.Cells['CardType'].Value = $category
            $row.Cells['Valid'].Value = [bool]$valid
            $row.Cells['Status'].Value = $statusText

            $gridDeckEditor.ClearSelection()
            $row.Selected = $true


            return [pscustomobject]@{
                Name = $finalName
                Zone = $Zone
                AddedNewRow = $false
                Valid = $valid
                Cancelled = $false
            }
        }
    }

    $idx = $gridDeckEditor.Rows.Add(
        1,
        $finalName,
        $Zone,
        $category,
        [bool]$valid,
        $statusText
    )

    $newRow = $gridDeckEditor.Rows[$idx]
    $newRow.Tag = [pscustomobject]@{
        PrintingSet = ''
        PrintingCollector = ''
        PrintingUUID = ''
    }

    if (-not $valid) {
        $newRow.Cells['CardName'].Style.BackColor = [System.Drawing.Color]::FromArgb(92,35,35)
        $newRow.Cells['CardName'].Style.ForeColor = [System.Drawing.Color]::White
    }

    $gridDeckEditor.ClearSelection()
    $newRow.Selected = $true

    try {
        $gridDeckEditor.FirstDisplayedScrollingRowIndex = [Math]::Max(0,$idx-3)
    }
    catch {}


    return [pscustomobject]@{
        Name = $finalName
        Zone = $Zone
        AddedNewRow = $true
        Valid = $valid
        Cancelled = $false
    }
}


function Add-LocalCockatriceCard {
    $typed = $txtLocalCardSearch.Text.Trim()

    if ([string]::IsNullOrWhiteSpace($typed)) {
        $status.Text = 'Start typing a Cockatrice card name first.'
        return
    }

    $resolved = Resolve-CardNameSmart -InputName $typed

    if (-not $resolved) {
        $suggestions = @(Find-CardSuggestions $typed)

        if ($suggestions.Count -gt 0) {
            $best = [string]$suggestions[0]
            $all = ($suggestions -join "`r`n  ")

            $answer = [System.Windows.Forms.MessageBox]::Show(
                "Card not found:`r`n$typed`r`n`r`nDid you mean:`r`n  $all`r`n`r`nUse the top suggestion:`r`n$best ?",
                'Cockatrice Card Search',
                [System.Windows.Forms.MessageBoxButtons]::YesNo,
                [System.Windows.Forms.MessageBoxIcon]::Question
            )

            if ($answer -eq [System.Windows.Forms.DialogResult]::Yes) {
                $resolved = $best
                $txtLocalCardSearch.Text = $best
            }
            else {
                $status.Text = "Card not found. Suggestions: $($suggestions -join ' | ')"
                return
            }
        }
        else {
            $status.Text = "Card not found in Cockatrice: $typed"
            [System.Windows.Forms.MessageBox]::Show(
                "Card was not found in the loaded Cockatrice cards.xml:`r`n`r`n$typed`r`n`r`nNo close local-name suggestions were found.",
                'Cockatrice Card Search',
                [System.Windows.Forms.MessageBoxButtons]::OK,
                [System.Windows.Forms.MessageBoxIcon]::Information
            ) | Out-Null
            return
        }
    }

    $zone = if ($cmbLocalZone.SelectedItem) {
        [string]$cmbLocalZone.SelectedItem
    }
    else {
        'main'
    }

    if (-not (Confirm-OffColorCard -CardName $resolved)) {
        $status.Text = "Not added: $resolved is outside commander color identity."
        return
    }

    $result = Add-CardToEditor -CardName $resolved -Zone $zone -Source 'Cockatrice Local Search'

    if ($result.Cancelled) {
        return
    }

    $txtLocalCardSearch.Clear()
    $status.Text = "Added $($result.Name) to $($result.Zone)."
    Save-DeckAutosave
    Update-DeckStatsPanel
}


function Refresh-DeckEditorGrid {
    param($Entries)

    $gridWatch = [System.Diagnostics.Stopwatch]::StartNew()

    # 8 GB mode: type metadata is loaded only for cards in this deck.
    Ensure-CardTypesForEntries -Entries $Entries

    $gridDeckEditor.Rows.Clear()

    $zoneOrder = @{
        commander = 0
        main = 1
        side = 2
    }

    $displayRows = @(
        foreach ($e in @(Merge-Entries $Entries)) {
            $category = Get-CardTypeCategory -CardName ([string]$e.Name)

            [pscustomobject]@{
                Entry = $e
                Category = $category
                ZoneOrder = if ($zoneOrder.ContainsKey([string]$e.Zone)) {
                    [int]$zoneOrder[[string]$e.Zone]
                } else {
                    9
                }
                TypeOrder = Get-CardTypeSortOrder -Category $category
            }
        }
    ) | Sort-Object ZoneOrder, TypeOrder, @{Expression={$_.Entry.Name}}

    $lastZone = $null
    $lastCategory = $null

    foreach ($item in $displayRows) {
        $e = $item.Entry
        $category = [string]$item.Category

        $statusText = if ($e.Valid) {
            'OK'
        }
        elseif ($e.Suggestion) {
            'Not found - ' + [string]$e.Suggestion
        }
        else {
            'Not found'
        }

        $idx = $gridDeckEditor.Rows.Add(
            [int]$e.Qty,
            [string]$e.Name,
            [string]$e.Zone,
            $category,
            [bool]$e.Valid,
            $statusText
        )

        $row = $gridDeckEditor.Rows[$idx]

        $row.Tag = [pscustomobject]@{
            PrintingSet = if ($e.PSObject.Properties['PrintingSet']) { [string]$e.PrintingSet } else { '' }
            PrintingCollector = if ($e.PSObject.Properties['PrintingCollector']) { [string]$e.PrintingCollector } else { '' }
            PrintingUUID = if ($e.PSObject.Properties['PrintingUUID']) { [string]$e.PrintingUUID } else { '' }
        }

        if ($lastZone -ne [string]$e.Zone -or $lastCategory -ne $category) {
            $row.DividerHeight = 5
            $row.Cells['CardType'].Style.Font = New-Object System.Drawing.Font(
                $gridDeckEditor.Font,
                [System.Drawing.FontStyle]::Bold
            )
        }

        if (-not $e.Valid) {
            $row.Cells['CardName'].Style.BackColor = [System.Drawing.Color]::FromArgb(92,35,35)
            $row.Cells['CardName'].Style.ForeColor = [System.Drawing.Color]::White
        }

        $lastZone = [string]$e.Zone
        $lastCategory = $category
    }

    $gridWatch.Stop()
    Write-PerformanceLog -Stage 'Deck grid rendered' `
        -Milliseconds $gridWatch.Elapsed.TotalMilliseconds `
        -Details ("Rows={0:N0}" -f $gridDeckEditor.Rows.Count)
}


function Start-NewDeck {
    # Clear previous source-specific state but preserve detected Cockatrice path/settings.
    $Script:LoadedCodPath = $null
    $Script:LastSavedPath = $null
    $Script:OriginalImportText = ''
    $Script:OriginalLoadedSnapshot = $null

    $Script:SelectedTags = @()
    $txtTags.Text = '(None)'
    $txtComments.Clear()

    $Script:SelectedCommanderNames = @()
    $Script:CommanderMode = 'Regular Commander'
    $Script:PrimaryCommander = ''
    $Script:SecondaryCommander = ''
    $Script:CompanionCard = ''
    $Script:AllowOffColorCards = @{}
    $txtCommander.Text = '(None)'

    if ([string]::IsNullOrWhiteSpace($txtName.Text)) {
        $txtName.Text = 'New Deck'
    }

    if ([string]::IsNullOrWhiteSpace($cmbFormat.Text)) {
        $cmbFormat.Text = 'Commander'
    }

    # Ensure local Cockatrice card index is loaded so search/autocomplete works.
    $folder = $cmbDest.Text.Trim()
    if ($folder) {
        $dataRoot = Get-DataRootFromDeckFolder $folder
        if ($dataRoot) {
            Load-CardIndex -DataRoot $dataRoot -StatusLabel $status
        }
    }

    # Seed the editor with a harmless placeholder row, then immediately remove
    # it after Analysis is established. This avoids requiring import text.
    $seed = @(New-Entry -Qty 1 -Name '__NEW_DECK_PLACEHOLDER__' -Zone 'main' -Source 'New Deck')

    $Script:Analysis = [pscustomobject]@{
        Entries = @()
        Merged = @()
        Invalid = @()
        Source = 'New Deck'
        MainQty = 0
        CommanderQty = 0
        SideQty = 0
        DeckQty = 0
        TotalQty = 0
    }

    $txtResults.Text = @"
============================================================
 COCKATRICE DECK BUILDER
============================================================

Source             : New Deck
Deck quantity      : 0
Mainboard          : 0
Commander(s)       : 0
Sideboard          : 0

Use:
  - Cockatrice Card Search
  - Scryfall Search
  - Add Card

Then Apply / Validate and Save Verified .COD.
"@

    $gridDeckEditor.Rows.Clear()
    Refresh-LocalCardAutocomplete

    $txtInput.Clear()
    $txtInput.Visible = $false
    $leftButtons.Visible = $false
    $deckEditorPanel.Visible = $true
    $deckEditorPanel.BringToFront()
    Set-EditorPreviewSplit
    Update-DeckStatsPanel

    $leftTitle.Text = 'Build new deck - add cards, quantities, and zones'
    $Script:EditorMode = $true

    $btnModifyDeck.Enabled = $true
    $btnSave.Enabled = $true
    $btnExportText.Enabled = $true
    $btnOpenSaved.Enabled = $false
    $btnOverwriteOriginal.Enabled = $false

    $status.Text = 'New deck ready. Add cards using local search, Scryfall, or Add Card.'
}

function Enter-DeckEditor {
    if (-not $Script:Analysis -or -not $Script:Analysis.Entries) {
        throw 'Load or import a deck before opening Modify Deck.'
    }

    $Script:OriginalImportText = $txtInput.Text
    $txtInput.Clear()

    Refresh-DeckEditorGrid -Entries $Script:Analysis.Entries
    Refresh-LocalCardAutocomplete

    if (-not $Script:OriginalLoadedSnapshot) {
        $Script:OriginalLoadedSnapshot = Get-AnalysisSnapshot
    }

    $txtInput.Visible = $false
    $leftButtons.Visible = $false
    $deckEditorPanel.Visible = $true
    $deckEditorPanel.BringToFront()
    Set-EditorPreviewSplit
    $leftTitle.Text = 'Modify parsed deck - edit Qty, Card Name, or Zone'
    $Script:EditorMode = $true

    # The live grid is now the source of truth. Refresh immediately so a deck
    # that opens with Qty=2/3 duplicates reports them without requiring any edit.
    Update-DeckStatsPanel

    $status.Text = 'Deck editor open. Apply / Validate when finished.'
}

function Exit-DeckEditor {
    Hide-HoverCardPreview
    Clear-LiveCardPreview
    $deckEditorPanel.Visible = $false
    $txtInput.Visible = $true
    $leftButtons.Visible = $true
    $txtInput.BringToFront()
    $leftButtons.BringToFront()

    if ([string]::IsNullOrWhiteSpace($txtInput.Text) -and $Script:OriginalImportText) {
        $txtInput.Text = $Script:OriginalImportText
    }

    $leftTitle.Text = 'Moxfield / Archidekt URL or pasted deck list'
    $Script:EditorMode = $false
    $status.Text = 'Returned to import source.'
}


function Get-AnalysisSnapshot {
    if (-not $Script:Analysis) { return $null }

    return [pscustomobject]@{
        Entries = @($Script:Analysis.Entries | ForEach-Object {
            [pscustomobject]@{
                Qty=[int]$_.Qty
                Name=[string]$_.Name
                Zone=[string]$_.Zone
                Source=[string]$_.Source
                Valid=[bool]$_.Valid
                Suggestion=[string]$_.Suggestion
                PrintingSet=if ($_.PSObject.Properties['PrintingSet']) { [string]$_.PrintingSet } else { '' }
                PrintingCollector=if ($_.PSObject.Properties['PrintingCollector']) { [string]$_.PrintingCollector } else { '' }
                PrintingUUID=if ($_.PSObject.Properties['PrintingUUID']) { [string]$_.PrintingUUID } else { '' }
            }
        })
        Name = $txtName.Text
        Format = $cmbFormat.Text
        CommanderNames = @($Script:SelectedCommanderNames)
        Comments = $txtComments.Text
        Tags = @($Script:SelectedTags)
        Source = [string]$Script:Analysis.Source
    }
}

function Restore-OriginalLoadedDeck {
    if (-not $Script:OriginalLoadedSnapshot) {
        throw 'There is no original loaded/imported version to restore.'
    }

    $s = $Script:OriginalLoadedSnapshot

    $txtName.Text = [string]$s.Name
    $cmbFormat.Text = [string]$s.Format
    $txtComments.Text = [string]$s.Comments
    $Script:SelectedTags = @($s.Tags)
    $txtTags.Text = if ($Script:SelectedTags.Count) { $Script:SelectedTags -join '; ' } else { '(None)' }

    $Script:SelectedCommanderNames = @($s.CommanderNames)
    $txtCommander.Text = if ($Script:SelectedCommanderNames.Count) {
        $Script:SelectedCommanderNames -join '; '
    } else { '(None)' }

    $entries = @($s.Entries | ForEach-Object {
        [pscustomobject]@{
            Qty=[int]$_.Qty
            Name=[string]$_.Name
            Zone=[string]$_.Zone
            Source=[string]$_.Source
            Valid=[bool]$_.Valid
            Suggestion=[string]$_.Suggestion
            PrintingSet=if ($_.PSObject.Properties['PrintingSet']) { [string]$_.PrintingSet } else { '' }
            PrintingCollector=if ($_.PSObject.Properties['PrintingCollector']) { [string]$_.PrintingCollector } else { '' }
            PrintingUUID=if ($_.PSObject.Properties['PrintingUUID']) { [string]$_.PrintingUUID } else { '' }
        }
    })

    Validate-Entries $entries
    Update-Preview -Entries $entries -SourceName ([string]$s.Source) -Ignored @()
    Refresh-DeckEditorGrid -Entries $Script:Analysis.Entries
    $status.Text = 'Restored original loaded/imported deck.'
}



function Get-DeckEditorEntries {
    $entries = New-Object System.Collections.Generic.List[object]

    foreach ($row in $gridDeckEditor.Rows) {
        if ($row.IsNewRow) { continue }

        $name = [string]$row.Cells['CardName'].Value
        if ([string]::IsNullOrWhiteSpace($name)) { continue }

        $qty = 1
        try { $qty = [int]$row.Cells['Qty'].Value } catch {}
        if ($qty -lt 1) { $qty = 1 }

        $zone = [string]$row.Cells['Zone'].Value
        if ($zone -notin @('main','commander','side')) { $zone = 'main' }

                $printingSet = ''
        $printingCollector = ''
        $printingUUID = ''
        if ($row.Tag) {
            try { $printingSet = [string]$row.Tag.PrintingSet } catch {}
            try { $printingCollector = [string]$row.Tag.PrintingCollector } catch {}
            try { $printingUUID = [string]$row.Tag.PrintingUUID } catch {}
        }

        $entries.Add((New-Entry `
            -Qty $qty `
            -Name $name `
            -Zone $zone `
            -Source 'Deck Editor' `
            -PrintingSet $printingSet `
            -PrintingCollector $printingCollector `
            -PrintingUUID $printingUUID))
    }

    return $entries.ToArray()
}

function Apply-DeckEditorChanges {
    param([switch]$Silent)

    $gridDeckEditor.EndEdit()

    $edited = New-Object System.Collections.Generic.List[object]

    foreach ($row in $gridDeckEditor.Rows) {
        if ($row.IsNewRow) { continue }

        $name = [string]$row.Cells['CardName'].Value
        if ([string]::IsNullOrWhiteSpace($name)) { continue }

        $qtyText = [string]$row.Cells['Qty'].Value
        $qty = 0
        if (-not [int]::TryParse($qtyText, [ref]$qty) -or $qty -lt 1) {
            throw "Invalid quantity '$qtyText' for card '$name'. Quantity must be 1 or greater."
        }

        $zone = [string]$row.Cells['Zone'].Value
        if ($zone -notin @('main','commander','side')) {
            $zone = 'main'
        }

                $printingSet = ''
        $printingCollector = ''
        $printingUUID = ''

        if ($row.Tag) {
            try { $printingSet = [string]$row.Tag.PrintingSet } catch {}
            try { $printingCollector = [string]$row.Tag.PrintingCollector } catch {}
            try { $printingUUID = [string]$row.Tag.PrintingUUID } catch {}
        }

        $edited.Add((New-Entry `
            -Qty $qty `
            -Name $name.Trim() `
            -Zone $zone `
            -Source 'Modified deck' `
            -PrintingSet $printingSet `
            -PrintingCollector $printingCollector `
            -PrintingUUID $printingUUID))
    }

    if ($edited.Count -eq 0) {
        throw 'The modified deck has no cards.'
    }

    $entries = $edited.ToArray()
    Validate-Entries $entries

    $Script:SelectedCommanderNames = @(
        $entries |
            Where-Object { $_.Zone -eq 'commander' } |
            Select-Object -ExpandProperty Name -Unique
    )

    $txtCommander.Text = if ($Script:SelectedCommanderNames.Count -gt 0) {
        $Script:SelectedCommanderNames -join '; '
    } else {
        '(None)'
    }

    $source = 'Modified deck'
    if ($Script:Analysis -and $Script:Analysis.Source) {
        $baseSource = [string]$Script:Analysis.Source
        $baseSource = $baseSource -replace '(?: \(modified\))+$',''
        $source = $baseSource + ' (modified)'
    }

    Update-Preview -Entries $entries -SourceName $source -Ignored @()
    Refresh-DeckEditorGrid -Entries $Script:Analysis.Entries

    if (-not $Silent) {
        $status.Text = "Modified deck validated. $($Script:Analysis.TotalQty) cards across all zones."
    }
}

function Update-Preview {
    param($Entries, [string]$SourceName, [string[]]$Ignored=@())

    $merged = @(Merge-Entries $Entries)
    $invalid = @($merged | Where-Object { -not $_.Valid })
    $main = @($merged | Where-Object Zone -eq 'main')
    $cmd = @($merged | Where-Object Zone -eq 'commander')
    $side = @($merged | Where-Object Zone -eq 'side')

    $mainQty = 0; foreach ($e in $main) { $mainQty += [int]$e.Qty }
    $cmdQty = 0; foreach ($e in $cmd) { $cmdQty += [int]$e.Qty }
    $sideQty = 0; foreach ($e in $side) { $sideQty += [int]$e.Qty }

    # "Deck quantity" excludes sideboard; "All zones" includes everything.
    $deckQty = $mainQty + $cmdQty
    $totalQty = $deckQty + $sideQty

    $lines = New-Object System.Collections.Generic.List[string]
    $lines.Add('============================================================')
    $lines.Add(' COCKATRICE DECK IMPORT CHECK')
    $lines.Add('============================================================')
    $lines.Add('')
    $lines.Add("Source             : $SourceName")
    $lines.Add("Unique parsed cards: $($merged.Count)")
    $lines.Add("Deck quantity      : $deckQty  (Mainboard + Commander)")
    $lines.Add("All zones quantity : $totalQty  (includes Sideboard)")
    $lines.Add("Mainboard          : $mainQty")
    $lines.Add("Commander(s)       : $cmdQty")
    $lines.Add("Sideboard          : $sideQty")
    $lines.Add("Unresolved names   : $($invalid.Count)")
    $lines.Add("Ignored text lines : $($Ignored.Count)")
    $lines.Add('')

    if ($cmd.Count -gt 0) {
        $lines.Add('COMMANDER')
        foreach ($e in $cmd) { $lines.Add(("  {0} {1}" -f $e.Qty,$e.Name)) }
        $lines.Add('')
    }

    $repeatStatus = Get-DeckCommanderStatus -Entries $Entries
    $repeatCards = @($repeatStatus.Duplicates)
    if ($repeatCards.Count -gt 0) {
        if ($cmbFormat.Text -eq 'Commander') {
            $lines.Add('COMMANDER DUPLICATES - NONBASIC CARDS')
        }
        else {
            $lines.Add('REPEATED NONBASIC CARDS - INFORMATIONAL')
        }
        foreach ($dup in $repeatCards) {
            $lines.Add("  $dup")
        }
        $lines.Add('')
    }

    $autoCorrected = @($Entries | Where-Object { $_.PSObject.Properties['AutoCorrected'] -and $_.AutoCorrected })

    if ($autoCorrected.Count -gt 0) {
        $flavorFixes = @($autoCorrected | Where-Object {
            $_.PSObject.Properties['CorrectionReason'] -and
            $_.CorrectionReason -eq 'Flavor name alias'
        })

        $otherFixes = @($autoCorrected | Where-Object {
            -not $_.PSObject.Properties['CorrectionReason'] -or
            $_.CorrectionReason -ne 'Flavor name alias'
        })

        if ($flavorFixes.Count -gt 0) {
            $lines.Add('FLAVOR NAME ALIASES - CONVERTED TO REAL CARD NAMES')
            foreach ($e in $flavorFixes) {
                $lines.Add(("  {0}  ->  {1}" -f $e.OriginalName,$e.Name))
            }
            $lines.Add('')
        }

        if ($otherFixes.Count -gt 0) {
            $lines.Add('AUTO-CORRECTED FOR COCKATRICE')
            foreach ($e in $otherFixes) {
                $lines.Add(("  {0}  ->  {1}" -f $e.OriginalName,$e.Name))
            }
            $lines.Add('')
        }
    }

    if ($invalid.Count -gt 0) {
        $lines.Add('UNRESOLVED / NOT FOUND IN COCKATRICE')
        foreach ($e in $invalid) {
            $extra = if ($e.Suggestion) { "  Suggested: $($e.Suggestion)" } else { '' }
            $lines.Add(("  {0} {1}{2}" -f $e.Qty,$e.Name,$extra))
        }
        $lines.Add('')
    }
    else {
        $lines.Add('VALIDATION: PASS - every parsed card exists in Cockatrice.')
        $lines.Add('')
    }

    $lines.Add('MAINBOARD PREVIEW')
    foreach ($e in $main) {
        $mark = if ($e.Valid) {'OK'} else {'??'}
        $lines.Add(("  [{0}] {1} {2}" -f $mark,$e.Qty,$e.Name))
    }

    if ($side.Count -gt 0) {
        $lines.Add('')
        $lines.Add('SIDEBOARD PREVIEW')
        foreach ($e in $side) {
            $mark = if ($e.Valid) {'OK'} else {'??'}
            $lines.Add(("  [{0}] {1} {2}" -f $mark,$e.Qty,$e.Name))
        }
    }

    if ($Ignored.Count -gt 0) {
        $lines.Add('')
        $lines.Add('IGNORED TEXT')
        foreach ($x in ($Ignored | Select-Object -First 15)) {
            $lines.Add("  " + (Escape-Display $x))
        }
        if ($Ignored.Count -gt 15) { $lines.Add("  ... plus $($Ignored.Count-15) more") }
    }

    $txtResults.Lines = $lines.ToArray()

    $Script:Analysis = [pscustomobject]@{
        Entries = $Entries
        Merged = $merged
        Invalid = $invalid
        MainQty = $mainQty
        CommanderQty = $cmdQty
        SideQty = $sideQty
        DeckQty = $deckQty
        TotalQty = $totalQty
        Source = $SourceName
    }

    $btnSave.Enabled = ($merged.Count -gt 0 -and ($invalid.Count -eq 0 -or $chkInvalid.Checked))
    $btnModifyDeck.Enabled = ($merged.Count -gt 0)
    $btnExportText.Enabled = ($merged.Count -gt 0)
    $status.Text = "Parsed $totalQty cards; $($invalid.Count) unresolved."

        Invoke-AutoCommanderChooser -Entries $entries
}

function Run-Analysis {
    if ($Script:IsBusyLoading) { return }

    $Script:IsBusyLoading = $true

    try {
        $dest = $cmbDest.Text.Trim()
        if ([string]::IsNullOrWhiteSpace($dest)) {
            throw 'Choose a Cockatrice decks folder first.'
        }

        $dataRoot = Get-DataRootFromDeckFolder $dest
        if (-not $dataRoot) {
            throw @"
The selected save folder does not appear to be a Cockatrice decks folder.

Expected something like:
C:\Users\...\CockatricePortable\data\decks
or
C:\Users\...\AppData\Local\Cockatrice\Cockatrice\decks
"@
        }

        Load-CardIndex -DataRoot $dataRoot -StatusLabel $status

        $text = $txtInput.Text.Trim()
        if ([string]::IsNullOrWhiteSpace($text)) {
            $status.Text = 'Nothing to load - paste a deck URL/list, load a .COD, or choose New Deck.'
            return
        }

        $entries = @()
        $ignored = @()
        $sourceName = 'Pasted text'
        $remote = $null

        if ($text -match '^https?://\S+$') {
            $status.Text = 'Downloading public deck...'
            [System.Windows.Forms.Application]::DoEvents()

            $remote = Import-DeckUrl $text
            $entries = @($remote.Entries)
            $sourceName = $remote.Source

            if ($remote.Name) {
                $Script:ImportedDeckName = $remote.Name
                if ([string]::IsNullOrWhiteSpace($txtName.Text)) {
                    $txtName.Text = $remote.Name
                }
            }

            if ($remote.Format) {
                $Script:ImportedFormat = $remote.Format
                if ($cmbFormat.Text -eq 'Commander' -or [string]::IsNullOrWhiteSpace($cmbFormat.Text)) {
                    $cmbFormat.Text = $remote.Format
                }
            }
        }
        else {
            $parsed = Parse-PastedText -Text $text -IncludeMaybe $chkMaybe.Checked
            $entries = @($parsed.Entries)
            $ignored = @($parsed.Ignored)

            if ($parsed.Source) {
                $sourceName = [string]$parsed.Source
            }

            if ($parsed.SuggestedCommanders -and
                @($parsed.SuggestedCommanders).Count -gt 0 -and
                $Script:SelectedCommanderNames.Count -eq 0) {

                $Script:SelectedCommanderNames = @($parsed.SuggestedCommanders)
            }
        }

        if ($entries.Count -eq 0) {
            throw 'No deck cards could be parsed from the input.'
        }

        Validate-Entries $entries

        # Preserve any commander information imported directly from a supported site
        # unless the user has already made an explicit selection.
        $detectedCommanders = @(
            $entries |
                Where-Object Zone -eq 'commander' |
                Select-Object -ExpandProperty Name -Unique
        )

        if ($Script:SelectedCommanderNames.Count -eq 0 -and $detectedCommanders.Count -gt 0) {
            $Script:SelectedCommanderNames = @($detectedCommanders)
        }

        # Archidekt can expose deckFormat as a numeric ID (for example "3").
        # If the import actually contains a commander, normalize that numeric
        # value to the user-facing Commander format instead of displaying the ID.
        if ($detectedCommanders.Count -gt 0 -and $cmbFormat.Text -match '^\d+$') {
            $cmbFormat.Text = 'Commander'
            $Script:ImportedFormat = 'Commander'
        }

        $entries = @(Apply-SelectedCommanders `
            -Entries $entries `
            -CommanderNames @($Script:SelectedCommanderNames))

        Validate-Entries $entries

        $txtCommander.Text = if ($Script:SelectedCommanderNames.Count -gt 0) {
            $Script:SelectedCommanderNames -join '; '
        } else {
            '(None)'
        }

        Update-Preview -Entries $entries -SourceName $sourceName -Ignored $ignored

        # Match Cockatrice .COD behavior: a successful web/pasted import opens
        # directly in Edit Deck instead of stopping on the confirmation screen.
        if ($Script:Analysis -and $Script:Analysis.Merged.Count -gt 0) {
            Enter-DeckEditor
            Update-DeckStatsPanel
            $status.Text = "Loaded $sourceName deck into editor."
        }
    }
    catch {
        $btnSave.Enabled = $false
        $status.Text = 'Import failed - see Smart Checker / error log.'
        Show-DetailedError -ErrorRecord $_ -Context 'Load Deck / Validate deck'
    }
    finally {
        $Script:IsBusyLoading = $false
    }
}

$btnPaste.Add_Click({
    try {
        # One-click paste/import. If clipboard text is available, use it;
        # otherwise process whatever is already in the input box.
        if ([System.Windows.Forms.Clipboard]::ContainsText()) {
            $clip = [System.Windows.Forms.Clipboard]::GetText()
            if (-not [string]::IsNullOrWhiteSpace($clip)) {
                $txtInput.Text = $clip
            }
        }

        if ([string]::IsNullOrWhiteSpace($txtInput.Text)) {
            $status.Text = 'Clipboard/input does not contain a deck list or URL.'
            return
        }

        Run-Analysis
    }
    catch {
        Show-DetailedError -ErrorRecord $_ -Context 'Paste Deck / Link'
    }
})

$btnClear.Add_Click({
    if ($Script:EditorMode) {
        $deckEditorPanel.Visible = $false
        $txtInput.Visible = $true
        $leftButtons.Visible = $true
        $leftTitle.Text = 'Moxfield / Archidekt URL or pasted deck list'
        $Script:EditorMode = $false
    }

    $txtInput.Clear()
    $txtResults.Clear()
    $gridDeckEditor.Rows.Clear()
    $Script:OriginalImportText = ''
    $Script:LoadedCodPath = $null
    $Script:OriginalLoadedSnapshot = $null
    $Script:Analysis = $null
    $Script:SelectedCommanderNames = @()
    $Script:CommanderMode = 'Regular Commander'
    $Script:PrimaryCommander = ''
    $Script:SecondaryCommander = ''
    $Script:CompanionCard = ''
    $txtCommander.Text = '(None)'
    $btnModifyDeck.Enabled = $false
    $btnOverwriteOriginal.Enabled = $false
    $btnExportText.Enabled = $false
    $btnSave.Enabled = $false
    $btnOpenSaved.Enabled = $false
    $status.Text = 'Ready.'
})

$btnLoad.Add_Click({ Run-Analysis })

$btnNewDeck.Add_Click({
    try {
        Start-NewDeck
    }
    catch {
        Show-DetailedError -ErrorRecord $_ -Context 'New Deck'
    }
})


$btnLoadCod.Add_Click({
    try {
        $dlg = New-Object System.Windows.Forms.OpenFileDialog
        $dlg.Title = 'Load Cockatrice Deck'
        $dlg.Filter = 'Cockatrice Deck (*.cod)|*.cod|All files (*.*)|*.*'
        $dlg.Multiselect = $false

        # Preserve the known Cockatrice save folder before a loaded .cod file
        # potentially changes $cmbDest to Downloads/Desktop/etc.
        $previousDest = $cmbDest.Text.Trim()

        $dest = $previousDest
        if ($dest -and (Test-Path -LiteralPath $dest -PathType Container)) {
            $dlg.InitialDirectory = $dest
        }

        if ($dlg.ShowDialog($form) -ne [System.Windows.Forms.DialogResult]::OK) {
            return
        }

        $loaded = Import-CockatriceCod -Path $dlg.FileName

        $folder = Split-Path -Parent $loaded.Path
        $cmbDest.Text = $folder
        $txtName.Text = $loaded.Name
        $cmbFormat.Text = $loaded.Format
        $txtComments.Text = $loaded.Comments

        $Script:SelectedTags = @($loaded.Tags)
        $txtTags.Text = if ($Script:SelectedTags.Count) {
            $Script:SelectedTags -join '; '
        } else { '(None)' }

        $entries = @($loaded.Entries)

        $Script:SelectedCommanderNames = @(
            $entries |
                Where-Object Zone -eq 'commander' |
                Select-Object -ExpandProperty Name -Unique
        )

        $Script:PrimaryCommander = if ($Script:SelectedCommanderNames.Count -gt 0) { [string]$Script:SelectedCommanderNames[0] } else { '' }
        $Script:SecondaryCommander = if ($Script:SelectedCommanderNames.Count -gt 1) { [string]$Script:SelectedCommanderNames[1] } else { '' }
        $Script:CompanionCard = ''
        $Script:CommanderMode = if ($Script:SecondaryCommander) { 'Partner' } else { 'Regular Commander' }
        Update-CommanderSummaryText

        # Prefer the loaded file's folder when it is a real Cockatrice decks
        # folder. Otherwise use the previously selected Cockatrice destination,
        # then fall back to auto-detected installed/portable roots.
        $dataRoot = Get-DataRootFromDeckFolder $folder

        if (-not $dataRoot -and $previousDest) {
            $dataRoot = Get-DataRootFromDeckFolder $previousDest
        }

        if (-not $dataRoot) {
            $detectedRoots = @(Get-DetectedDataRoots)
            if ($detectedRoots.Count -gt 0) {
                $dataRoot = [string]$detectedRoots[0]
            }
        }

        if (-not $dataRoot) {
            throw "Could not locate Cockatrice cards.xml for validation.`r`n`r`nSelect your Cockatrice decks folder in Save Location and try again."
        }

        Load-CardIndex -DataRoot $dataRoot -StatusLabel $status

        Validate-Entries $entries
        Update-Preview -Entries $entries -SourceName 'Cockatrice .COD' -Ignored @()

        $Script:LoadedCodPath = $loaded.Path
        $Script:LastSavedPath = $loaded.Path
        $Script:OriginalImportText = ''
        $Script:OriginalLoadedSnapshot = Get-AnalysisSnapshot

        $btnOverwriteOriginal.Enabled = $true
        $btnOpenSaved.Enabled = $true
        $btnExportText.Enabled = $true
        $btnModifyDeck.Enabled = $true

        $txtInput.Clear()
        Enter-DeckEditor
        $status.Text = "Loaded Cockatrice deck: $($loaded.Path)"
    }
    catch {
        $status.Text = 'Cockatrice deck load failed.'
        Show-DetailedError -ErrorRecord $_ -Context 'Load Cockatrice .COD'
    }
})

$btnAnalyze.Add_Click({ Run-Analysis })

$chkInvalid.Add_CheckedChanged({
    if ($Script:Analysis) {
        $btnSave.Enabled = ($Script:Analysis.Merged.Count -gt 0 -and
            ($Script:Analysis.Invalid.Count -eq 0 -or $chkInvalid.Checked))
    }
})




$btnModifyDeck.Add_Click({
    try {
        Enter-DeckEditor
    }
    catch {
        Show-DetailedError -ErrorRecord $_ -Context 'Modify Deck'
    }
})

$btnEditorAdd.Add_Click({
    try {
        $idx = $gridDeckEditor.Rows.Add(1, '', 'main', 'Other', $false, 'New card - enter a Cockatrice card name')
        $gridDeckEditor.CurrentCell = $gridDeckEditor.Rows[$idx].Cells['CardName']
        $gridDeckEditor.BeginEdit($true)
    }
    catch {
        Show-DetailedError -ErrorRecord $_ -Context 'Add card'
    }
})

$btnEditorRemove.Add_Click({
    try {
        $rows = @($gridDeckEditor.SelectedRows | Sort-Object Index -Descending)
        foreach ($row in $rows) {
            if (-not $row.IsNewRow) {
                $gridDeckEditor.Rows.RemoveAt($row.Index)
            }
        }
    }
    catch {
        Show-DetailedError -ErrorRecord $_ -Context 'Remove card'
    }
})





$txtDeckFilter.Add_TextChanged({
    Apply-DeckFilter
})

$btnClearFilter.Add_Click({
    $txtDeckFilter.Clear()
    Apply-DeckFilter
})

$btnBrowseCards.Add_Click({
    try {
        Show-CardDatabaseBrowser
    }
    catch {
        Show-DetailedError -ErrorRecord $_ -Context 'Browse Card Database'
    }
})

$btnLocalAdd.Add_Click({
    try {
        Add-LocalCockatriceCard
    }
    catch {
        Show-DetailedError -ErrorRecord $_ -Context 'Add Cockatrice card'
    }
})

$txtLocalCardSearch.Add_KeyDown({
    param($sender,$e)

    if ($e.KeyCode -eq [System.Windows.Forms.Keys]::Enter) {
        try {
            Add-LocalCockatriceCard
        }
        catch {
            Show-DetailedError -ErrorRecord $_ -Context 'Add Cockatrice card'
        }

        $e.SuppressKeyPress = $true
    }
})

$btnScrySearchHelp.Add_Click({ Show-ScryfallSearchBasics -Owner $form })

$btnScryfallSearch.Add_Click({
    try {
        $query = $txtScryfallSearch.Text.Trim()

        if ([string]::IsNullOrWhiteSpace($query)) {
            Populate-ScryfallResults -Cards @()
            $status.Text = 'Enter a Scryfall search, then press Enter or click Search.'
            return
        }

        $status.Text = 'Searching Scryfall...'
        [System.Windows.Forms.Application]::DoEvents()

        $cards = @(Invoke-ScryfallCardSearch -Query $query)

        if ($cards.Count -gt 0) {
            Populate-ScryfallResults -Cards $cards
            $status.Text = "Scryfall returned $($cards.Count) cards. Choose a result, choose a zone, then click Add Selected to Deck."
            return
        }

        # No match: show autocomplete suggestions instead of an error popup.
        $suggestions = @(Get-ScryfallNameSuggestions -Query $query)

        $cmbScryResults.Items.Clear()
        $Script:ScryfallSearchResults = @()
        $btnScryAdd.Enabled = $false

        if ($suggestions.Count -gt 0) {
            foreach ($suggestion in $suggestions) {
                [void]$cmbScryResults.Items.Add("Suggestion: $suggestion")
            }

            $cmbScryResults.SelectedIndex = 0
            $status.Text = "No cards matched '$query'. Suggestions are shown - click one to search that name."
        }
        else {
            $status.Text = "No Scryfall results found for '$query'. Try a card name or broader Scryfall syntax."
        }
    }
    catch {
        $status.Text = 'Scryfall search failed - see Smart Checker for details.'
        Show-DetailedError -ErrorRecord $_ -Context 'Scryfall search'
    }
})


$cmbHoverDelay.Add_SelectedIndexChanged({
    try {
        $text = [string]$cmbHoverDelay.SelectedItem
        if ($text -match '^(\d+)\s*ms$') {
            $value = [int]$Matches[1]
            if ($value -ge 100 -and $value -le 500) {
                $Script:HoverPreviewDelay = $value
                Save-Settings $cmbDest.Text
                $status.Text = "Rollover preview delay set to $value ms."
            }
        }
    }
    catch {}
})

$gridDeckEditor.Add_CellMouseEnter({
    param($sender,$e)

    try {
        if ($e.RowIndex -lt 0 -or $e.ColumnIndex -lt 0) {
            Hide-HoverCardPreview
            return
        }

        $columnName = [string]$gridDeckEditor.Columns[$e.ColumnIndex].Name
        if ($columnName -ne 'CardName') {
            Hide-HoverCardPreview
            return
        }

        $row = $gridDeckEditor.Rows[$e.RowIndex]
        $name = [string]$row.Cells['CardName'].Value
        $uuid = ''

        if ($row.Tag) {
            try { $uuid = [string]$row.Tag.PrintingUUID } catch {}
        }

        Queue-HoverCardPreview -CardName $name -PrintingUUID $uuid
    }
    catch {
        Hide-HoverCardPreview
    }
})

$gridDeckEditor.Add_CellMouseLeave({
    param($sender,$e)
    Hide-HoverCardPreview
})

$gridDeckEditor.Add_MouseLeave({
    Hide-HoverCardPreview
})

$txtLocalCardSearch.Add_MouseHover({
    try {
        $name = Resolve-CardNameSmart -InputName $txtLocalCardSearch.Text
        if ($name) {
            Queue-HoverCardPreview -CardName $name
        }
    }
    catch {}
})

$txtLocalCardSearch.Add_MouseLeave({
    Hide-HoverCardPreview
})

$cmbScryResults.Add_MouseHover({
    try {
        $card = Get-SelectedScryfallCard
        if ($card) {
            Queue-HoverCardPreview -CardName ([string]$card.name) -PrintingUUID ([string]$card.id)
        }
    }
    catch {}
})

$cmbScryResults.Add_MouseLeave({
    Hide-HoverCardPreview
})

$txtScryfallSearch.Add_KeyDown({
    param($sender,$e)
    if ($e.KeyCode -eq [System.Windows.Forms.Keys]::Enter) {
        $status.Text = 'Searching Scryfall...'
        $btnScryfallSearch.PerformClick()
        $e.SuppressKeyPress = $true
    }
})


$cmbScryResults.Add_DoubleClick({
    try {
        if ($Script:ScryfallSearchResults -and $Script:ScryfallSearchResults.Count -gt 0) {
            return
        }

        if ($cmbScryResults.SelectedIndex -lt 0) { return }

        $text = [string]$cmbScryResults.SelectedItem
        if ($text -match '^Suggestion:\s*(.+)$') {
            $txtScryfallSearch.Text = $Matches[1]
            $btnScryfallSearch.PerformClick()
        }
    }
    catch {}
})

$cmbScryResults.Add_SelectedIndexChanged({
    try {
        $card = Get-SelectedScryfallCard

        if ($card) {
            $btnScryAdd.Enabled = $true
            return
        }

        $btnScryAdd.Enabled = $false

        if ($cmbScryResults.SelectedIndex -ge 0) {
            $text = [string]$cmbScryResults.SelectedItem
            if ($text -match '^Suggestion:\s*(.+)$') {
                $txtScryfallSearch.Text = $Matches[1]
                $status.Text = "Suggestion selected. Press Enter or double-click the suggestion to search."
            }
        }
    }
    catch {}
})

$btnScryAdd.Add_Click({
    try {
        $card = Get-SelectedScryfallCard

        if (-not $card) {
            throw 'Choose a Scryfall result from the result list first.'
        }

        $result = Add-ScryfallCardToDeck -Card $card
        if (-not $result) { return }

        # Commit the editor rows back into Analysis immediately so the card is
        # not only visible in the grid but also part of Save/Export/Recheck.
        Apply-DeckEditorChanges -Silent
        Update-DeckStatsPanel
        Save-DeckAutosave

        Refresh-DeckEditorGrid -Entries $Script:Analysis.Entries

        # Re-select the newly added/incremented card after refresh.
        foreach ($row in $gridDeckEditor.Rows) {
            if ($row.IsNewRow) { continue }
            if ([string]$row.Cells['CardName'].Value -ieq $result.Name -and
                [string]$row.Cells['Zone'].Value -ieq $result.Zone) {
                $gridDeckEditor.ClearSelection()
                $row.Selected = $true
                break
            }
        }

        $status.Text = "Scryfall: added $($result.Name) to $($result.Zone)."
    }
    catch {
        Show-DetailedError -ErrorRecord $_ -Context 'Add Scryfall card'
    }
})

$btnEditorRestore.Add_Click({
    try {
        Restore-OriginalLoadedDeck
    }
    catch {
        Show-DetailedError -ErrorRecord $_ -Context 'Restore original deck'
    }
})





$btnEditorPreview.Add_Click({
    try {
        Choose-ArtForSelectedEditorRow
    }
    catch {
        Write-PerformanceLog -Stage 'Choose card art exception' -Details $_.Exception.Message
        Show-DetailedError -ErrorRecord $_ -Context 'Choose card art'
    }
})

$ctxSetCommander.Add_Click({
    foreach ($row in @($gridDeckEditor.SelectedRows)) {
        $row.Cells['Zone'].Value = 'commander'
    }
})

$ctxMoveMain.Add_Click({
    foreach ($row in @($gridDeckEditor.SelectedRows)) {
        $row.Cells['Zone'].Value = 'main'
    }
})

$ctxMoveSide.Add_Click({
    foreach ($row in @($gridDeckEditor.SelectedRows)) {
        $row.Cells['Zone'].Value = 'side'
    }
})

$ctxPreview.Add_Click({
    try {
        Choose-ArtForSelectedEditorRow
    }
    catch {
        Show-DetailedError -ErrorRecord $_ -Context 'Choose card art'
    }
})

$ctxRemove.Add_Click({
    $rows = @($gridDeckEditor.SelectedRows | Sort-Object Index -Descending)
    foreach ($row in $rows) {
        if (-not $row.IsNewRow) { $gridDeckEditor.Rows.RemoveAt($row.Index) }
    }
})

$btnEditorApply.Add_Click({
    try {
        if ($cmbFormat.Text -eq 'Commander') {
            $deckStatus = Get-DeckCommanderStatus -Entries (Get-DeckEditorEntries)

            $issues = New-Object System.Collections.Generic.List[string]

            if ($deckStatus.DeckQty -ne 100) {
                $issues.Add("Commander deck count is $($deckStatus.DeckQty)/100.")
            }

            if (@($deckStatus.Duplicates).Count -gt 0) {
                $issues.Add("Non-basic duplicates:`r`n  " + ((@($deckStatus.Duplicates) | Select-Object -First 12) -join "`r`n  "))
            }

            if ($issues.Count -gt 0) {
                $answer = [System.Windows.Forms.MessageBox]::Show(
                    ($issues -join "`r`n`r`n") + "`r`n`r`nContinue anyway?",
                    'Commander Deck Check',
                    [System.Windows.Forms.MessageBoxButtons]::YesNo,
                    [System.Windows.Forms.MessageBoxIcon]::Warning
                )

                if ($answer -ne [System.Windows.Forms.DialogResult]::Yes) {
                    $status.Text = 'Validation cancelled by Commander deck check.'
                    return
                }
            }
        }

        $offColor = @(Get-OffColorEditorCards)

        if ($offColor.Count -gt 0) {
            $shown = ($offColor | Select-Object -First 12) -join "`r`n  "
            $more = if ($offColor.Count -gt 12) { "`r`n  ...and $($offColor.Count - 12) more" } else { '' }

            $answer = [System.Windows.Forms.MessageBox]::Show(
                "The following cards are outside the selected commander's color identity:`r`n
  $shown$more`r`n`r`nKeep them and continue validation?",
                'Commander Color Identity Warning',
                [System.Windows.Forms.MessageBoxButtons]::YesNo,
                [System.Windows.Forms.MessageBoxIcon]::Warning
            )

            if ($answer -ne [System.Windows.Forms.DialogResult]::Yes) {
                $status.Text = 'Validation cancelled because of color identity conflicts.'
                return
            }

            foreach ($name in $offColor) {
                $Script:AllowOffColorCards[$name.ToLowerInvariant()] = $true
            }
        }

        Apply-DeckEditorChanges
    }
    catch {
        Show-DetailedError -ErrorRecord $_ -Context 'Apply / Validate modified deck'
    }
})

$btnEditorBack.Add_Click({
    try {
        if ($Script:EditorMode) {
            $answer = [System.Windows.Forms.MessageBox]::Show(
                "Apply the current deck edits before returning to the import source?",
                'Modify Deck',
                [System.Windows.Forms.MessageBoxButtons]::YesNoCancel,
                [System.Windows.Forms.MessageBoxIcon]::Question
            )

            if ($answer -eq [System.Windows.Forms.DialogResult]::Cancel) { return }
            if ($answer -eq [System.Windows.Forms.DialogResult]::Yes) {
                Apply-DeckEditorChanges -Silent
            }

            Exit-DeckEditor
        }
    }
    catch {
        Show-DetailedError -ErrorRecord $_ -Context 'Return from deck editor'
    }
})


$gridDeckEditor.Add_SelectionChanged({
    try {
        if ($Script:EditorMode -and $gridDeckEditor.SelectedRows.Count -gt 0) {
            $name = [string]$gridDeckEditor.SelectedRows[0].Cells['CardName'].Value
            if (-not [string]::IsNullOrWhiteSpace($name)) {
                Update-LiveCardPreview -CardName $name
            }
        }
    }
    catch {}
})

$gridDeckEditor.Add_CellDoubleClick({
    param($sender,$e)
    if ($e.RowIndex -ge 0 -and $e.ColumnIndex -eq $gridDeckEditor.Columns['CardName'].Index) {
        $gridDeckEditor.BeginEdit($true)
    }
})

$gridDeckEditor.Add_CellEndEdit({
    param($sender,$e)
    try {
        if (-not $Script:EditorMode -or $e.RowIndex -lt 0) { return }

        $columnName = [string]$gridDeckEditor.Columns[$e.ColumnIndex].Name
        if ($columnName -in @('Qty','CardName','Zone')) {
            # Commit the edited value before recalculating live quantities.
            $gridDeckEditor.EndEdit()
            Queue-DeckStatsRefresh
            Save-DeckAutosave
        }
    }
    catch {}
})


$btnExportText.Add_Click({
    try {
        if ($Script:EditorMode) {
            Apply-DeckEditorChanges -Silent
        }

        if (-not $Script:Analysis -or -not $Script:Analysis.Entries) {
            throw 'Load or import a deck before exporting text.'
        }

        $text = Convert-EntriesToPlainText -Entries $Script:Analysis.Entries

        $dlg = New-Object System.Windows.Forms.SaveFileDialog
        $dlg.Title = 'Export Deck as Text'
        $dlg.Filter = 'Text file (*.txt)|*.txt|All files (*.*)|*.*'
        $dlg.FileName = (Get-SafeFileName $txtName.Text) + '.txt'

        if ($dlg.ShowDialog($form) -eq [System.Windows.Forms.DialogResult]::OK) {
            [System.IO.File]::WriteAllText($dlg.FileName, $text, [System.Text.Encoding]::UTF8)
            $status.Text = "Exported text: $($dlg.FileName)"
        }
    }
    catch {
        Show-DetailedError -ErrorRecord $_ -Context 'Export deck text'
    }
})

$btnCopyError.Add_Click({
    try {
        if (-not [string]::IsNullOrWhiteSpace($txtResults.Text)) {
            [System.Windows.Forms.Clipboard]::SetText($txtResults.Text)
            $status.Text = 'Smart Checker / error details copied to clipboard.'
        }
    }
    catch {
        Show-DetailedError -ErrorRecord $_ -Context 'Copy Error'
    }
})




$top.Add_Resize({
    Update-CommanderHelpPosition
})


$btnSmartCommander.Add_Click({
    try {
        if ($Script:EditorMode) {
            Apply-DeckEditorChanges -Silent
        }

        $picked = $null

        if ($Script:Analysis -and $Script:Analysis.Entries -and @($Script:Analysis.Entries).Count -gt 0) {
            $picked = Show-DeckCommanderChooser -Entries $Script:Analysis.Entries
        }
        else {
            $picked = Show-SmartCommanderPicker
        }

        if (-not $picked) { return }

        Apply-SmartCommanderSelection -Picked $picked -Entries $Script:Analysis.Entries
    }
    catch {
        Show-DetailedError -ErrorRecord $_ -Context 'Smart Commander'
    }
})

$btnCommanderFullHelp.Add_Click({
    try {
        Show-CommanderFullHelp
    }
    catch {
        Show-DetailedError -ErrorRecord $_ -Context 'Commander Help'
    }
})

$btnSelectCommander.Add_Click({
    try {
        if ($Script:EditorMode) {
            Apply-DeckEditorChanges -Silent
        }

        if (-not $Script:Analysis -or -not $Script:Analysis.Entries) {
            [System.Windows.Forms.MessageBox]::Show(
                'Load or import the deck first, then configure Commander Setup.',
                'Commander Setup',
                [System.Windows.Forms.MessageBoxButtons]::OK,
                [System.Windows.Forms.MessageBoxIcon]::Information
            ) | Out-Null
            return
        }

        $setup = Show-CommanderSetup `
            -Entries $Script:Analysis.Entries `
            -CurrentPrimary $Script:PrimaryCommander `
            -CurrentSecondary $Script:SecondaryCommander `
            -CurrentCompanion $Script:CompanionCard `
            -CurrentMode $Script:CommanderMode

        if ($null -eq $setup) { return }

        $Script:CommanderMode = $setup.Mode
        $Script:PrimaryCommander = $setup.Primary
        $Script:SecondaryCommander = $setup.Secondary
        $Script:CompanionCard = $setup.Companion

        $Script:SelectedCommanderNames = @(
            @($Script:PrimaryCommander, $Script:SecondaryCommander) |
                Where-Object { -not [string]::IsNullOrWhiteSpace($_) }
        )

        Update-CommanderSummaryText

        $updated = @(Apply-SelectedCommanders `
            -Entries $Script:Analysis.Entries `
            -CommanderNames @($Script:SelectedCommanderNames))

        Validate-Entries $updated
        Update-Preview -Entries $updated -SourceName $Script:Analysis.Source -Ignored @()

        if ($Script:EditorMode) {
            Refresh-DeckEditorGrid -Entries $Script:Analysis.Entries
        }

        $status.Text = "Commander setup: $($Script:CommanderMode)"
    }
    catch {
        Show-DetailedError -ErrorRecord $_ -Context 'Commander Setup'
    }
})

$btnTags.Add_Click({
    try {
        $dataRoot = $null
        $dest = $cmbDest.Text.Trim()
        if ($dest) { $dataRoot = Get-DataRootFromDeckFolder $dest }

        $entriesForTags = if ($Script:Analysis) { $Script:Analysis.Entries } else { $null }

        $picked = Show-TagManager `
            -CurrentTags @($Script:SelectedTags) `
            -Entries $entriesForTags `
            -DataRoot $dataRoot

        if ($null -ne $picked) {
            $Script:SelectedTags = @($picked)

            if ($Script:SelectedTags.Count -eq 0) {
                $txtTags.Text = '(None)'
            }
            else {
                $txtTags.Text = ($Script:SelectedTags -join '; ')
            }
        }
    }
    catch {
        Show-DetailedError -ErrorRecord $_ -Context 'Manage Tags'
    }
})

$btnBrowse.Add_Click({
    $dlg = New-Object System.Windows.Forms.FolderBrowserDialog
    $dlg.Description = 'Choose the Cockatrice decks folder'
    $dlg.ShowNewFolderButton = $true

    if ($cmbDest.Text -and (Test-Path -LiteralPath $cmbDest.Text -PathType Container)) {
        $dlg.SelectedPath = $cmbDest.Text
    }

    if ($dlg.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) {
        $cmbDest.Text = $dlg.SelectedPath
        Save-Settings $dlg.SelectedPath
        $Script:CardIndex = $null
        $Script:CardIndexRoot = $null
        $Script:SortedCardNames = $null
        $Script:CardTypeIndex = New-Object 'System.Collections.Generic.Dictionary[string,byte]' ([System.StringComparer]::OrdinalIgnoreCase)
        $btnSave.Enabled = $false
        $status.Text = 'Save location changed. Recheck the deck.'
    }
})

$btnOpenFolder.Add_Click({
    try {
        $folder = $cmbDest.Text.Trim()
        if (-not (Test-Path -LiteralPath $folder -PathType Container)) {
            New-Item -ItemType Directory -Path $folder -Force | Out-Null
        }
        Start-Process explorer.exe -ArgumentList ('"' + $folder + '"')
    }
    catch { Msg-Error $_.Exception.Message }
})

$btnSave.Add_Click({
    try {
        if ($Script:EditorMode) {
            Apply-DeckEditorChanges -Silent
        }

        if (-not $Script:Analysis) {
            throw 'Analyze the deck before saving.'
        }

        if ($Script:Analysis.Invalid.Count -gt 0 -and -not $chkInvalid.Checked) {
            throw 'There are unresolved card names. Fix them or explicitly enable Allow unresolved names.'
        }

        $deckName = $txtName.Text.Trim()
        if ([string]::IsNullOrWhiteSpace($deckName)) {
            $deckName = 'Imported Deck'
            $txtName.Text = $deckName
        }

        $folder = $cmbDest.Text.Trim()
        if ([string]::IsNullOrWhiteSpace($folder)) {
            throw 'Choose a Cockatrice decks folder.'
        }

        if (-not (Test-Path -LiteralPath $folder -PathType Container)) {
            New-Item -ItemType Directory -Path $folder -Force | Out-Null
        }

        $dataRoot = Get-DataRootFromDeckFolder $folder
        if (-not $dataRoot) {
            throw 'The selected save location is not a valid Cockatrice decks folder.'
        }

        Save-Settings $folder

        $fileName = (Get-SafeFileName $deckName) + '.cod'
        $path = Join-Path $folder $fileName

        if (Test-Path -LiteralPath $path -PathType Leaf) {
            $answer = [System.Windows.Forms.MessageBox]::Show(
                "This deck already exists:`r`n`r`n$path`r`n`r`nReplace it?",
                'Confirm Replace',
                [System.Windows.Forms.MessageBoxButtons]::YesNo,
                [System.Windows.Forms.MessageBoxIcon]::Question
            )

            if ($answer -ne [System.Windows.Forms.DialogResult]::Yes) { return }

            $backup = $path + '.bak'
            Copy-Item -LiteralPath $path -Destination $backup -Force
        }

        # Rebuild a clean editable copy, then apply the selected commander(s).
        $saveEntries = @($Script:Analysis.Entries | ForEach-Object {
            [pscustomobject]@{
                Qty=[int]$_.Qty
                Name=[string]$_.Name
                Zone=[string]$_.Zone
                Source=[string]$_.Source
                Valid=[bool]$_.Valid
                Suggestion=[string]$_.Suggestion
                PrintingSet=if ($_.PSObject.Properties['PrintingSet']) { [string]$_.PrintingSet } else { '' }
                PrintingCollector=if ($_.PSObject.Properties['PrintingCollector']) { [string]$_.PrintingCollector } else { '' }
                PrintingUUID=if ($_.PSObject.Properties['PrintingUUID']) { [string]$_.PrintingUUID } else { '' }
            }
        })

        $saveEntries = @(Apply-SelectedCommanders `
            -Entries $saveEntries `
            -CommanderNames @($Script:SelectedCommanderNames))

        Validate-Entries $saveEntries

        $tags = @($Script:SelectedTags)

        Write-Cod `
            -Path $path `
            -DeckName $deckName `
            -Format $cmbFormat.Text.Trim() `
            -Comments $txtComments.Text `
            -Tags $tags `
            -Entries $saveEntries `
            -DataRoot $dataRoot

        $check = Verify-Cod -Path $path -ExpectedEntries $saveEntries

        # Verify the additional Cockatrice deck metadata too.
        [xml]$savedMeta = Get-Content -LiteralPath $path -Raw
        $metadataProblems = New-Object System.Collections.Generic.List[string]

        if ([string]$savedMeta.cockatrice_deck.deckname -ne $deckName) {
            $metadataProblems.Add('Deck name did not round-trip correctly.')
        }

        $expectedFormat = $cmbFormat.Text.Trim().ToLowerInvariant()
        if ([string]$savedMeta.cockatrice_deck.format -ne $expectedFormat) {
            $metadataProblems.Add('Format did not round-trip correctly.')
        }

        $expectedTags = @($Script:SelectedTags)
        $savedTags = @($savedMeta.cockatrice_deck.tags.tag | ForEach-Object { [string]$_ })
        foreach ($tag in $expectedTags) {
            if ($savedTags -notcontains $tag) {
                $metadataProblems.Add("Missing saved tag: $tag")
            }
        }

        foreach ($printingProblem in @(Verify-CodPrintingMetadata -Path $path -ExpectedEntries $saveEntries)) {
            $metadataProblems.Add([string]$printingProblem)
        }

        if (-not $check.Pass -or $metadataProblems.Count -gt 0) {
            $problemText = (@($check.Problems) + @($metadataProblems) | Select-Object -First 20) -join "`r`n"
            throw @"
The .COD file was created but FAILED the post-save completeness/metadata check.

Expected total: $($check.ExpectedTotal)
Saved total   : $($check.ActualTotal)

$problemText
"@
        }

        $Script:LastSavedPath = $path
        $btnOpenSaved.Enabled = $true
        $status.Text = "Saved and verified: $path"

        Msg-Info @"
Deck saved successfully.

File:
$path

Smart verification:
PASS

Expected cards: $($check.ExpectedTotal)
Saved cards   : $($check.ActualTotal)

Every parsed card and quantity was found again in the saved .cod file.
Deck name / format / tags were also verified.`r`nTag mode supports Smart Suggest, manual selection, custom tags, or None.

Selected printing metadata is preserved and verified for mainboard, sideboard,
and commander cards (set code / collector number / UUID).
"@
    }
    catch {
        $status.Text = 'Save failed - see Smart Checker / error log.'
        Show-DetailedError -ErrorRecord $_ -Context 'Save / verify .COD'
    }
})


$btnOverwriteOriginal.Add_Click({
    try {
        if (-not $Script:LoadedCodPath) {
            throw 'No original Cockatrice .cod has been loaded.'
        }

        if ($Script:EditorMode) {
            Apply-DeckEditorChanges -Silent
        }

        $answer = [System.Windows.Forms.MessageBox]::Show(
            "Overwrite the original Cockatrice deck?`r`n`r`n$($Script:LoadedCodPath)`r`n`r`nA .bak copy will be created first.",
            'Overwrite Original',
            [System.Windows.Forms.MessageBoxButtons]::YesNo,
            [System.Windows.Forms.MessageBoxIcon]::Warning
        )
        if ($answer -ne [System.Windows.Forms.DialogResult]::Yes) { return }

        $originalPath = $Script:LoadedCodPath
        $backup = $originalPath + '.bak'
        Copy-Item -LiteralPath $originalPath -Destination $backup -Force

        $folder = Split-Path -Parent $originalPath
        $dataRoot = Get-DataRootFromDeckFolder $folder
        if (-not $dataRoot) { throw 'Original deck is not inside a recognized Cockatrice decks folder.' }

        $saveEntries = @($Script:Analysis.Entries | ForEach-Object {
            [pscustomobject]@{
                Qty=[int]$_.Qty
                Name=[string]$_.Name
                Zone=[string]$_.Zone
                Source=[string]$_.Source
                Valid=[bool]$_.Valid
                Suggestion=[string]$_.Suggestion
                PrintingSet=if ($_.PSObject.Properties['PrintingSet']) { [string]$_.PrintingSet } else { '' }
                PrintingCollector=if ($_.PSObject.Properties['PrintingCollector']) { [string]$_.PrintingCollector } else { '' }
                PrintingUUID=if ($_.PSObject.Properties['PrintingUUID']) { [string]$_.PrintingUUID } else { '' }
            }
        })

        $saveEntries = @(Apply-SelectedCommanders -Entries $saveEntries -CommanderNames @($Script:SelectedCommanderNames))
        Validate-Entries $saveEntries

        Write-Cod `
            -Path $originalPath `
            -DeckName $txtName.Text.Trim() `
            -Format $cmbFormat.Text.Trim() `
            -Comments $txtComments.Text `
            -Tags @($Script:SelectedTags) `
            -Entries $saveEntries `
            -DataRoot $dataRoot

        $check = Verify-Cod -Path $originalPath -ExpectedEntries $saveEntries
        $printingProblems = @(Verify-CodPrintingMetadata -Path $originalPath -ExpectedEntries $saveEntries)
        if (-not $check.Pass -or $printingProblems.Count -gt 0) {
            $allProblems = @($check.Problems) + @($printingProblems)
            throw "Overwrite completed but verification failed.`r`n" + (($allProblems | Select-Object -First 20) -join "`r`n")
        }

        $Script:LastSavedPath = $originalPath
        $status.Text = "Original deck overwritten and verified: $originalPath"
        Msg-Info "Original deck overwritten and verified.`r`n`r`nBackup:`r`n$backup"
    }
    catch {
        Show-DetailedError -ErrorRecord $_ -Context 'Overwrite original .COD'
    }
})

$btnOpenSaved.Add_Click({
    try {
        if ($Script:LastSavedPath -and (Test-Path -LiteralPath $Script:LastSavedPath -PathType Leaf)) {
            Start-Process -FilePath $Script:LastSavedPath
        }
    }
    catch { Msg-Error $_.Exception.Message }
})

# Ctrl+Enter = load/check; while Modify Deck is open it applies the edits.
$form.KeyPreview = $true
$form.Add_KeyDown({
    if ($_.Control -and $_.KeyCode -eq [System.Windows.Forms.Keys]::Enter) {
        if ($Script:EditorMode) {
            try { Apply-DeckEditorChanges } catch { Show-DetailedError -ErrorRecord $_ -Context 'Apply modified deck' }
        }
        else {
            Run-Analysis
        }
        $_.SuppressKeyPress = $true
    }
})


# Apply the requested 60/40 workspace split only after Windows has completed
# the form's initial DPI scaling and Dock layout.  A one-shot timer is used
# because SplitContainer can overwrite SplitterDistance during first layout.
$startupSplitTimer = New-Object System.Windows.Forms.Timer
$startupSplitTimer.Interval = 200

$startupSplitTimer.Add_Tick({
    try {
        $startupSplitTimer.Stop()

        $usableWidth = $split.ClientSize.Width - $split.SplitterWidth

        if ($usableWidth -gt 400) {
            $target = [int][Math]::Round($usableWidth * 0.60)

            # Keep both panels inside their legal bounds.
            $minimumLeft = [Math]::Max(100, $split.Panel1MinSize)
            $minimumRight = [Math]::Max(100, $split.Panel2MinSize)

            if ($target -lt $minimumLeft) {
                $target = $minimumLeft
            }

            if (($usableWidth - $target) -lt $minimumRight) {
                $target = $usableWidth - $minimumRight
            }

            $split.SplitterDistance = $target
        }
    }
    catch {
        # Layout preference should never prevent the importer from opening.
    }
})

$form.Add_Shown({
    $startupSplitTimer.Start()
})


$form.Add_Resize({
    if ($Script:EditorMode) {
        Set-EditorPreviewSplit
    }
})




$autosaveTimer = New-Object System.Windows.Forms.Timer
$autosaveTimer.Interval = 15000
$autosaveTimer.Add_Tick({
    if ($Script:EditorMode) {
        Save-DeckAutosave
    }
})
$autosaveTimer.Start()

$form.Add_Shown({
    $form.BeginInvoke([System.Windows.Forms.MethodInvoker]{
        Set-DarkThemeRecursive -Control $form
        Update-CommanderHelpPosition
        Update-CommanderColorIdentityDisplay
        Update-DeckStatsPanel
        Try-RestoreAutosave
    }) | Out-Null
})

[void]$form.ShowDialog()